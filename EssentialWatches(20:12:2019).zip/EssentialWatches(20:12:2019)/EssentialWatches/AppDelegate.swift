//
//  AppDelegate.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import UserNotifications
import JNKeychain
import ZVProgressHUD
import IQKeyboardManager
import Alamofire
import Firebase


@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate
{
    var window: UIWindow?
    var objSidePanelController  = JASidePanelController()
    var objCurrentNavigationController  = UINavigationController()
    let baseVC:BaseViewController = BaseViewController()
    var objSideMenuVC:SideMenuViewController = SideMenuViewController()
    var imgSplash:UIImageView!
    var isReceivedNotification = false
    var isReceivedNotificationForSideMenu = false
    var dictLaunchOptions = NSDictionary()
    var arrBrands = Array<Brand>()
    var arrBrandList = Array<BrandList>()
    var indexNumberofBrand = -1
    var indexNumberofModel = -1
    var indexNumberofVariation = -1
    var strProductName = ""
    
    
    
    static var appDelegate: AppDelegate? = nil
    var navigationController: UINavigationController?
    var tabBarController : TabBarController!

   
    
        class func sharedInstance() -> AppDelegate {
             if appDelegate == nil {
                 appDelegate = (UIApplication.shared.delegate as! AppDelegate)
             }
             return appDelegate!
         }
    //------------------------------------------------------------------------------------------------------------------
    // MARK: -  Application Methods
    //------------------------------------------------------------------------------------------------------------------
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    {
        print(NSDate())
        let info = launchOptions?[UIApplication.LaunchOptionsKey.remoteNotification]
        
        if (info != nil) {
            isReceivedNotification = true
            isReceivedNotificationForSideMenu = true
        }

        self.addGoogleAnalytics()
        
        IQKeyboardManager.shared().isEnabled = true
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")

        if (reachabilityManager?.isReachable)!{
            self.getBrands()
        }else{
           // self.displayAlertForNoIntenret()
            return true
        }
        
        //self.setTwoWaySiderAsRootController()
        
        // iOS 10 support
        
        if #available(iOS 10, *) {
            UNUserNotificationCenter.current().requestAuthorization(options:[.badge, .alert, .sound]){ (granted, error) in }
            application.registerForRemoteNotifications()
        }
        else if #available(iOS 9, *) {  // iOS 9 support
            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
            UIApplication.shared.registerForRemoteNotifications()
        }
//        else if #available(iOS 8, *) { // iOS 8 support
//            UIApplication.shared.registerUserNotificationSettings(UIUserNotificationSettings(types: [.badge, .sound, .alert], categories: nil))
//            UIApplication.shared.registerForRemoteNotifications()
//        }
        
        if launchOptions?[UIApplication.LaunchOptionsKey.remoteNotification] != nil {
            UIApplication.shared.applicationIconBadgeNumber = 0
        }
        
        let image: UIImage = UIImage(named: "Splash")!
        imgSplash = UIImageView.init(image:image)
        imgSplash!.frame = CGRect(x: 0, y: 0, width: (self.window?.frame.size.width)!, height: (self.window?.frame.size.height)!)
        imgSplash.contentMode = .scaleToFill
        self.window?.rootViewController?.view.addSubview(imgSplash)
        self.window?.rootViewController?.view.bringSubviewToFront(imgSplash)
        return true
    }
    
    //------------------------------------------------------------------------------------------------------------------
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        // Convert token to string
        let deviceTokenString = deviceToken.reduce("", {$0 + String(format: "%02X", $1)})
        // Print it to console
        print("APNs device token: \(deviceTokenString)")
        
        UserDefaults.standard.set(deviceTokenString, forKey: "devicetoken")
        //let uniqueIdentifier = UIDevice.current.identifierForVendor?.uuidString
        let uniqueIdentifier = self.getDeviceIdentifierFromKeychain()
        UserDefaults.standard.set(uniqueIdentifier, forKey: "deviceuid")
        UserDefaults.standard.synchronize()
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")

        if (reachabilityManager?.isReachable)!{
        ServerRequest.sendServerRequestforPostMethod(dictParam: ["deviceId":uniqueIdentifier,"deviceToken":deviceTokenString, KConstant.kMethod : "iphone_registerdevice.php","deviceType":"0","version":"2.2.6"], completion: { (response,isSuccess) in
            if isSuccess{
//                print(response)
                //let dict : NSDictionary =  response as! NSDictionary
            }else{
            }
            
        })
        }else{
            self.displayAlertForNoIntenret()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // Push notification received
    func application(_ application: UIApplication, didReceiveRemoteNotification data: [AnyHashable : Any]) {
        isReceivedNotificationForSideMenu = true
//        print("Push notification received: \(data)")
        let dict : NSDictionary = data["aps"] as! NSDictionary
        baseVC.displayAlertWithCompletion(message: dict["alert"] as! String) {
            var objNotificationViewController = NotificationViewController()
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            objNotificationViewController = storyboard.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
            self.objCurrentNavigationController.pushViewController(objNotificationViewController, animated: false)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("APNs registration failed: \(error)")
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func application(_ application: UIApplication, willFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        print("willFinishLaunchingWithOptions")
        if #available(iOS 10.0, *) {
            UNUserNotificationCenter.current().delegate = self
        } else {
            // Fallback on earlier versions
        }
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func saveValueInUserDefault(dict:NSDictionary) {
        UserDefaults.standard.set(dict, forKey: KConstant.kUserDetail)
        UserDefaults.standard.synchronize()
    }
    func getDeviceIdentifierFromKeychain() -> String {
        // try to get value from keychain
        var deviceUDID = self.keychain_valueForKey("keychainDeviceUDID") as? String
        if deviceUDID == nil {
            deviceUDID = UIDevice.current.identifierForVendor!.uuidString
            // save new value in keychain
            self.keychain_setObject(deviceUDID! as AnyObject, forKey: "keychainDeviceUDID")
        }
        return deviceUDID!
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func displayAlertForNoIntenret()
    {
        let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
            alert.dismiss(animated: true, completion: nil)
        })
        self.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }

    // ------------------------------------------------------------------------------------------------------------------

    func addGoogleAnalytics()
    {
        
        FirebaseApp.configure()

//        guard let gai = GAI.sharedInstance() else {
//            assert(false, "Google Analytics not configured correctly")
//            return
//            }
//        
//        gai.tracker(withTrackingId: "UA-111474583-1")
//        // Optional: automatically report uncaught exceptions.
//        gai.trackUncaughtExceptions = true
//        
//        // Optional: set Logger to VERBOSE for debug information.
//        // Remove before app release.
//        gai.logger.logLevel = .verbose;
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Keychain
    // ------------------------------------------------------------------------------------------------------------------
    
    func keychain_setObject(_ object: AnyObject, forKey: String) {
        let result = JNKeychain.saveValue(object, forKey: forKey)
        if !result {
            print("keychain saving: smth went wrong")
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func keychain_deleteObjectForKey(_ key: String) -> Bool {
        let result = JNKeychain.deleteValue(forKey: key)
        return result
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func keychain_valueForKey(_ key: String) -> AnyObject? {
        let value = JNKeychain.loadValue(forKey: key)
        return value as AnyObject?
    }
    

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  Web Service Calling Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func getBrands()
    {
        let dict1 = [KConstant.kMethod : "brand_list.php"]
        ServerRequest.sendServerRequestWithDict(dictParam: dict1) { (response, isSuccess) in
            if isSuccess {
                self.arrBrands = response as! Array<Brand>
                //print("Suuccess\(self.arrBrands)")
            }else{
                print("failure\(response)")
            }
            self.appVersionApi()
        }
    }

    // ------------------------------------------------------------------------------------------------------------------

    func appVersionApi()
    {
        // self.progressShow(true) //ProgressHUD.show()
        ServerRequest.sendServerRequestforPostMethod(dictParam:["deviceType":"0","version":"2.2.6", KConstant.kMethod : "appversion_api.php"]) { (response, isSuccess) in
            if isSuccess
            {
//            print(response)
                let dict : NSDictionary =  response as! NSDictionary
                if dict["status"] as! Int == 0
                {
                    self.baseVC.displayAlertWithCompletion(message: dict["iosMessage"] as! String, completion: {
                        
                        if let url = URL(string: "itms-apps://itunes.apple.com/app/id967166613"),
                        UIApplication.shared.canOpenURL(url)
                        {
                            if #available(iOS 10.0, *) {
                                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                            } else {
                                UIApplication.shared.openURL(url)
                            }
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.0001) {
                            exit(0)
                        }
                    })
                }else{
                    self.imgSplash.removeFromSuperview()
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let objViewController : ViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                    //let navigationController = UINavigationController(rootViewController: self.objViewController) as UINavigationController
                    self.window?.rootViewController = objViewController
                  //self.setTwoWaySiderAsRootController()
                }
            }
        }
    }
    // ------------------------------------------------------------------------------------------------------------------
    // Called when APNs failed to register the device for push notifications
    // ------------------------------------------------------------------------------------------------------------------
    
    func setTwoWaySiderAsRootController()
    {
        //       if self.objSidePanelController == nil {
        //           self.objSidePanelController = JASidePanelController()
        //       }
        self.objSidePanelController = JASidePanelController()
        self.objSidePanelController .shouldDelegateAutorotateToVisiblePanel = true
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let objHomeViewController :  TabBarController = storyboard.instantiateViewController(withIdentifier: "TabBarController") as! TabBarController
//        objHomeViewController.tabBarController?.tabBar.isHidden = false
        objSideMenuVC =  storyboard.instantiateViewController(withIdentifier: "SideMenuViewController") as! SideMenuViewController
        let navigationController = UINavigationController(rootViewController: objHomeViewController) as UINavigationController
        navigationController.isNavigationBarHidden = true
        self.objSidePanelController.centerPanel = navigationController
        self.objSidePanelController.leftPanel = objSideMenuVC
        self.objSidePanelController.showCenterPanel(animated: false)
        self.window?.rootViewController = self.objSidePanelController
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    //    func application(_ application: UIApplication,
    //                     supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
    //        return self.shouldRotate ? .allButUpsideDown : .portrait
    //    }
}

