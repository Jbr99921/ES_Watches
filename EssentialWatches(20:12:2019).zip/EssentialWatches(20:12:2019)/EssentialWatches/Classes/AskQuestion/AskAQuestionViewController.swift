//
//  AskAQuestionViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import SwiftyJSON
import ZVProgressHUD
import Alamofire
import Firebase

class AskAQuestionViewController: BaseViewController, UITextViewDelegate,UITextFieldDelegate
{
    @IBOutlet weak var scrollview: TPKeyboardAvoidingScrollView!
    
    @IBOutlet weak var textFieldBrand: ECW_TextField!
    @IBOutlet weak var textFieldFullName: ECW_TextField!
    @IBOutlet weak var textFieldEmail: ECW_TextField!
    @IBOutlet weak var textFieldPhone: ECW_TextField!
    @IBOutlet weak var textViewComments: UITextView!
    
    @IBOutlet weak var buttonBrand: UIButton!
    
    @IBOutlet weak var viewInfo: UIView!
    @IBOutlet weak var imageViewWatch: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelBrandTitle: UILabel!
    @IBOutlet weak var labelSubText: UILabel!
    @IBOutlet weak var layoutconstraintViewInfoHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutconstraintFullNameTopSpace: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintLabelBrand: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintTextFieldBrand: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintConditionImageViewLeading: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintConditionImageViewTrailing: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintInfoViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintInfoViewTopHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintInfoViewImageViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintViewTopNameHeight: NSLayoutConstraint!
    
    var dictOption  = [String : AnyObject]()
    var arrBrands = Array<Brand>()
    var arrPickerData = ["010"]

    var strOption = ""
    var strTitle = ""
    var strItemID = ""
    var strModelNumber = ""
    var strBrandName = ""
    var strBrandParam = ""
    
    var isFromMultiple : Bool = false
    var isFromSearch : Bool = false
    var isFromInfo : Bool = false
    var objWatchList : WatchList? = nil
    var objSearch : Search? = nil
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setTitleLabel(title: strTitle)
        self.textViewComments.layer.borderColor = UIColor.lightGray.cgColor
        self.textViewComments.layer.borderWidth = 0.5
        self.getBrands()
    }

    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool)
    {
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: strTitle+" Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
        

        let str = strTitle.replacingOccurrences(of: " ", with: "_")
        Analytics.logEvent("\(str)_Screen", parameters: [
            "name": "\(strTitle) Screen" as NSObject,
            ])
        
        if isFromInfo {
            layoutconstraintFullNameTopSpace.constant = 10
            viewInfo.isHidden = true
            textFieldBrand.isHidden = false
            buttonBrand.isHidden = false
            layoutconstraintViewInfoHeight.constant = 0
        }else{
            layoutConstraintTextFieldBrand.constant = 0
            layoutConstraintLabelBrand.constant = 0
            layoutconstraintFullNameTopSpace.constant = -10
            viewInfo.isHidden = false
            textFieldBrand.isHidden = true
            buttonBrand.isHidden = true
        }
        
        if isFromSearch
        {
            let url = URL(string: (objSearch?.Image)!)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//            imageViewWatch.af_setImage(withURL: url, placeholderImage: placeholderImage)
            imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

            labelName.text = (objSearch?.BrandName)! + "\n" + (objSearch?.Name)!
            labelSubText.text = objSearch?.SubText
            strBrandParam =  (objSearch?.BrandName)!

        }
        else if isFromMultiple
        {
            let url = URL(string: (objWatchList?.Image)!)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//            imageViewWatch.af_setImage(withURL: url, placeholderImage: placeholderImage)
            imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

            labelName.text = self.strBrandName  + "\n" + (objWatchList?.Name)!
           //labelSubText.text = objWatchList?.SubText
            labelSubText.text = objWatchList?.Subtext
            strBrandParam = self.strBrandName
        }
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
            textFieldFullName.text =  "\(dictTemp?.value(forKey:KConstant.kFirstName) ?? "")" + " " + "\(dictTemp?.value(forKey:KConstant.kLastName) ?? "")"
            textFieldPhone.text = dictTemp?.value(forKey:KConstant.kMobileNum) as? String
            textFieldEmail.text = dictTemp?.value(forKey:KConstant.kEmail) as? String
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    override func viewDidLayoutSubviews() {
//     layoutConstraintInfoViewHeight.constant =  70
        if KConstant.IS_IPHONE5 {
            self.scrollview.contentSize = CGSize(width: self.scrollview.frame.size.width, height: 600)
        }else{
            self.scrollview.contentSize = CGSize(width: self.scrollview.frame.size.width, height: 550)
        }
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------

    func getBrands()
    {
       var arrTemp = ["010"]
       for i in 0 ..< KConstant.APP.arrBrands.count {
           let objBrand = KConstant.APP.arrBrands[i] as Brand
           arrTemp.append(objBrand.BrandName)
       }
       arrTemp.remove(at: 0)
       self.arrPickerData = arrTemp
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func resignTextFields()
    {
        textFieldBrand.resignFirstResponder()
        textFieldEmail.resignFirstResponder()
        textFieldFullName.resignFirstResponder()
        textFieldPhone.resignFirstResponder()
        textViewComments.resignFirstResponder()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonBrandClicked(_ sender: Any)
    {
        if  self.arrPickerData.count > 1
        {
            self.resignTextFields()
//            let picker: SBPickerSelector = SBPickerSelector()
//            picker.pickerData =  arrPickerData//picker content
//            picker.delegate = self
//            picker.pickerType = .text
//            picker.doneButtonTitle = "Done"
//            picker.cancelButtonTitle = "Cancel"
//            picker.showPicker(from: self.view, in: self)
            
            SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:arrPickerData, defaultDate: Date()).cancel {
                print("cancel, will be autodismissed")
                }.set { values in
                        
                     if let values = values as? [Brand]
                     {
                            let objBrand : Brand = values[0]
                        self.textFieldBrand.text = objBrand.BrandName
                        self.strBrandParam = objBrand.BrandName

                        
                    }

            }.present(into: self)
            
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonSubmitClicked(_ sender: Any)
    {
        self.resignTextFields()
        
        let  strFullName = textFieldFullName.text!
        let  strEmail = textFieldEmail.text!
        let  strPhone = textFieldPhone.text!
        let  strComments = textViewComments.text!
        
        if textFieldFullName.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter fullname.")
            return
        }
        
        if textFieldEmail.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter email.")
            return
        }
        
        if self.validateEmail(strEmail: textFieldEmail.text!) == false{
            self.displayAlertWithOk(message: "Please enter valid email.")
            return
        }
        
        if textFieldPhone.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter mobile number.")
            return
        }
        
        if textViewComments.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter your comments.")
            return
        }

        let fullName: String = textFieldFullName.text!
        let fullNameArr = fullName.components(separatedBy: " ")
        let firstName: String = fullNameArr[0]
        let lastName: String? = fullNameArr.count > 1 ? fullNameArr[1] : nil
        let dict:NSDictionary = [KConstant.kFirstName: firstName, KConstant.kLastName: lastName ?? "", KConstant.kMobileNum : textFieldPhone.text ?? "", KConstant.kEmail : textFieldEmail.text ?? ""]
        KConstant.APP.saveValueInUserDefault(dict: dict)
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")

        if !(reachabilityManager?.isReachable)!
        {
             self.displayAlertForNoIntenret()
        }else{
             self.progressShow(true) //ProgressHUD.show()
        }

        if isFromInfo
        {
            let dictParams = [KConstant.kMethod : "askquestion_out.php","type":strOption,"fullname":strFullName,"phone":strPhone,"email":strEmail,"brand":strBrandParam,"comment":strComments,"devicetype":"ios"]
            
            ServerRequest.sendPostRequestWithDict(dictParam: dictParams) { (response, isSuccess) in
                let dictRes = response as! NSDictionary
                let msg = dictRes["message"] as! String
                if isSuccess
                {
                    self.displayAlertWithWithPopViewController(message:msg)
                }else{
                    self.displayAlertWithOk(message: msg)
                }
                self.progressShow(false) // ProgressHUD.dismiss()
            }
        }
        else
        {
            var strModelNumTemp = ""
            var strItemIDTemp = ""
            
            if isFromSearch
            {
                strModelNumTemp = (objSearch?.ModelNumber)!
                strItemIDTemp = (objSearch?.ItemID)!
            }else  if isFromMultiple
            {
                strModelNumTemp = (objWatchList?.ModelNumber)!
                strItemIDTemp = (objWatchList?.ItemID)!
            }
            else if dictOption.count > 0
            {
                let  strCheck = dictOption["nFlag"] as! String
                
                if strCheck == "1"
                {
                    let objLatestWatch : LatestWatch = dictOption["object"] as!  LatestWatch
                    let  objLatestWatchProduct : LatestWatchProduct = objLatestWatch.Product as LatestWatchProduct
                    strItemIDTemp = objLatestWatchProduct.ItemID
                    strModelNumTemp = objLatestWatch.ModelNumber
                }
                else
                {
                    let objFeatureWatch : FeaturedWatch = dictOption["object"] as!  FeaturedWatch
                    let  objLatestWatchProduct : LatestWatchProduct = objFeatureWatch.Product as LatestWatchProduct
                    strItemIDTemp = objLatestWatchProduct.ItemID
                    strModelNumTemp = objFeatureWatch.ModelNumber
                }
            }

            let dictParams = [KConstant.kMethod : "askquestion.php","type":strOption,"itemid": strItemIDTemp,"fullname":strFullName,"phone":strPhone,"email":strEmail,"brand":strBrandParam,"model":strModelNumTemp,"comment":strComments,"devicetype":"ios"]
                ServerRequest.sendPostRequestWithDict(dictParam: dictParams) { (response, isSuccess) in
                    let dictRes = response as! NSDictionary
                    let msg = dictRes["message"] as! String
                    if isSuccess
                    {
                        self.displayAlertWithWithPopViewController(message:msg)
                    }else{
                        self.displayAlertWithOk(message: msg)
                    }
                    self.progressShow(false) // ProgressHUD.dismiss()
                }
        }
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITextField Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------

   func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if  textFieldFullName.isFirstResponder {
            textFieldEmail.becomeFirstResponder()
        }else  if  textFieldEmail.isFirstResponder {
            textFieldPhone.becomeFirstResponder()
        }else  if  textFieldPhone.isFirstResponder {
            textViewComments.becomeFirstResponder()
        }else  if  textViewComments.isFirstResponder {
            textField.resignFirstResponder()
        }
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - SBPickerSelector Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------

//    func pickerSelector(_ selector: SBPickerSelector, selectedValues values: [String], atIndexes idxs: [NSNumber]){
//        let m = idxs[0] as! Int // m is an `Int64`
//        let objBrand : Brand = KConstant.APP.arrBrands[m] as Brand
//        textFieldBrand.text = objBrand.BrandName
//        strBrandParam = objBrand.BrandName
//    }
//
//    // ------------------------------------------------------------------------------------------------------------------
//
//    func pickerSelector(_ selector: SBPickerSelector, cancelPicker cancel: Bool){
//        textFieldBrand.text = ""
//    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
}
