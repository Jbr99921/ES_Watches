//
//  WebViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 21/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire
import Firebase
import WebKit


//import JustHUD

class WebViewController: BaseViewController,WKUIDelegate{
    var strOption = ""
    var strTitle = ""
    var strURL = ""
    var isVideo = false

  
    
    
    @IBOutlet weak var webview: WKWebView!
  
    
     // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        webview.uiDelegate = self
//        webview?.navigationDelegate = self
//        webview.delegate = self
         
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewWillAppear(_ animated: Bool)
    {
    
      //  webview.scalesPageToFit = false
        
        self.tabBarController?.tabBar.isHidden = true
        self.tabBarController?.tabBar.layer.zPosition = -1
        self.tabBarController?.tabBar.isTranslucent = true
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        if !isVideo
        {
            
             self.progressShow(true) //ProgressHUD.show()
            self.setTitleLabel(title: strTitle)
            let urlTemp = URL(string: self.strURL)
            webview.load( URLRequest(url: urlTemp!) )
        }else{
             self.progressShow(true) //ProgressHUD.show()
            self.setTitleLabel(title: strTitle+" Video")
            if self.strURL.contains("watch?v=") {
                self.strURL = self.strURL.replacingOccurrences(of: "watch?v=", with: "", options: .literal, range: nil)
            }
            let fileArray = self.strURL.components(separatedBy: "/")
            self.loadYoutube(videoID: fileArray.last!)
        }
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Play Video Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    /* // AUTO LOAD
    func loadYoutube(videoID:String)
    {
            let youTubeVideoHTML: String = "<!DOCTYPE html><html><head><style>body{margin:0px 0px 0px 0px;}</style></head> <body> <div id=\"player\"></div> <script>var tag = document.createElement('script'); tag.src = \"http://www.youtube.com/player_api\"; var firstScriptTag = document.getElementsByTagName('script')[0]; firstScriptTag.parentNode.insertBefore(tag, firstScriptTag); var player; function onYouTubePlayerAPIReady() { player = new YT.Player('player', { width:'%0.0f',height:'%0.0f', videoId:'%@', playerVars: {'autoplay': 1}, events: { 'onReady': onPlayerReady, } }); } function onPlayerReady(event) { event.target.playVideo(); } </script> </body></html>"
        
            let str : String = "<!DOCTYPE html><html><iframe id='player'  type='text/html' width='320' height='568' src='http://www.youtube.com/embed/M7lc1UVf-VE?enablejsapi=1&autoplay=1&origin=http://example.com  frameborder='0'></iframe></body></html>"
            let html: String = String(format: youTubeVideoHTML, self.view.frame.size.width, self.view.frame.size.height, videoID)
             webview.loadHTMLString(str, baseURL: nil)
    }
 */

    // ------------------------------------------------------------------------------------------------------------------

   
    
    func loadYoutube(videoID:String)
    {
        let youTubeVideoHTML: String = "<!DOCTYPE html><html><head><style>body{margin:0px 0px 0px 0px;}</style></head> <body> <div id=\"player\"></div> <script> var tag = document.createElement('script'); tag.src = \"http://www.youtube.com/player_api\"; var firstScriptTag = document.getElementsByTagName('script')[0]; firstScriptTag.parentNode.insertBefore(tag, firstScriptTag); var player; function onYouTubePlayerAPIReady() { player = new YT.Player('player', { width:'%0.0f', height:'%0.0f', videoId:'%@', events: { 'onReady': onPlayerReady, } }); } function onPlayerReady(event) { event.target.playVideo(); } </script> </body> </html>"
//        if #available(iOS 11.0, *) {
            let heightZ = (UIScreen.main.bounds.height - 150)
            let html: String = String(format: youTubeVideoHTML, UIScreen.main.bounds.width, heightZ, videoID)
            webview.loadHTMLString(html, baseURL: nil)
//        } else {
//            // Fallback on earlier versions
//            let heightZ = (UIScreen.main.bounds.height - 150)
//            let html: String = String(format: youTubeVideoHTML, UIScreen.main.bounds.width, heightZ, videoID)
//            webview.loadHTMLString(html, baseURL: nil)
//        }
        
        
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIWebView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func webViewDidStartLoad(_ webView: WKWebView){
//        if isVideo {
//            let appDelegate = UIApplication.shared.delegate as! AppDelegate
//            appDelegate.shouldRotate = true
//        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func webView(_ webView: WKWebView, shouldStartLoadWith request: URLRequest, navigationType: WKNavigationType) -> Bool{
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func webViewDidFinishLoad(_ webView: WKWebView){
        self.progressShow(false) // ProgressHUD.dismiss()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func webView(_ webView: WKWebView, didFailLoadWithError error: Error){
        self.progressShow(false) // ProgressHUD.dismiss()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

}
