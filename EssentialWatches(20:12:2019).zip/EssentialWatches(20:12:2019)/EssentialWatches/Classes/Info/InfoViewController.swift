//
//  InfoViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import MessageUI
import Firebase

class InfoViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate,MFMailComposeViewControllerDelegate {
    
    var arrProducts = ["Contact Details","Trade in Info","Contact Us","About Us","Testimonial","E-Bay Store","Ask a Question","FAQ","Privacy Policy","Refund Policy","Version"]
    
    //    var nRowHeight = 0 as CGFloat
    var isExpanded : Bool = true
    
    @IBOutlet weak var tableViewProducts: UITableView!
    @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setTitleLabel(title: "Info")
        
        self.setIsRequiedMenuYes()
        
        if !MFMailComposeViewController.canSendMail() {
            return
        }
        if DeviceUtility.isIphoneXType{
            layoutConstraintTopViewTopSpace.constant =  25
        }else{
            layoutConstraintTopViewTopSpace.constant =  5
        }

        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        

        Analytics.logEvent("Info_Screen", parameters: [
            "name": "Info Screen" as NSObject,
            ])
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Info Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
    func buttonCellClicked(sender : Any) {
        tableViewProducts.reloadData()
    }
    
    
    @IBAction func buttonEmailClicked(_ sender: Any) {
            let composeVC = MFMailComposeViewController()
            composeVC.mailComposeDelegate = self
            // Configure the fields of the interface.
            composeVC.setToRecipients(["contact@essentialwatches.com"])
            composeVC.setSubject("")
            composeVC.setMessageBody("", isHTML: false)
            // Present the view controller modally.
            self.present(composeVC, animated: true, completion: nil)
    }
    
    
    @IBAction override func buttonPhoneClicked(_ sender: Any) {
        if let url = URL(string: "tel://+1-3106017264"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }

    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        var strMessage = ""
        switch result
        {
            case .cancelled:
                strMessage = "Mail Cancelled"
            case .failed:
                strMessage = "Mail Failed"
            case .sent:
                strMessage = "Mail Sent"
            default:
                break
        }
        controller.dismiss(animated: true, completion: nil)
        let alert = UIAlertController(title: KConstant.kAPPName, message:strMessage, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
        })
        self.present(alert, animated: true, completion: nil)

//        KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)

    }
    


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return arrProducts.count
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        if indexPath.section == 0{
            return 292
        }else{
            return 48
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.00001
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 10
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : InfoCell = tableView.dequeueReusableCell(withIdentifier: "InfoCell", for: indexPath ) as! InfoCell
        cell.labelTitle.text = arrProducts[indexPath.section]
        cell.buttonCell.tag = indexPath.section
        cell.buttonCell.addTarget(self, action: #selector(buttonClicked(sender:)), for: .touchUpInside)
        cell.selectionStyle = .none
        
        if  indexPath.section == 0{
            cell.imageViewArrow.image = UIImage(named:  "")
            cell.viewExpanded.isHidden = false
        }else{
            cell.imageViewArrow.image = UIImage(named:  "right_icon")
            cell.viewExpanded.isHidden = true
        }
        
        if indexPath.section == 10 {
            cell.imageViewArrow.image = UIImage(named:  "")
            cell.imageViewArrow.isHidden = true
            cell.labelVersion.isHidden = false
        }else{
            cell.labelVersion.isHidden = true
            cell.imageViewArrow.isHidden = false
        }
        
        var fontSize = 11
        
        if KConstant.IS_IPHONE5 {
            fontSize = 10
            cell.labelEmail.font = UIFont(name: KConstant.kFontOpenSenseLight, size: CGFloat(11))
        }else{
            cell.labelEmail.font = UIFont(name: KConstant.kFontOpenSenseLight, size: CGFloat(12))
        }
        cell.labelInfo.font = UIFont(name: KConstant.kFontOpenSenseLight, size: CGFloat(fontSize))
        cell.labelInfoAddress.font = UIFont(name: KConstant.kFontOpenSenseLight, size: CGFloat(fontSize))
        cell.labelInfoPhone.font = UIFont(name: KConstant.kFontOpenSenseLight, size: CGFloat(fontSize))
        cell.labelEmail.font = UIFont(name: KConstant.kFontOpenSenseLight, size: CGFloat(12))
        cell.labelVersion.text = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as? String
        return cell
    }
    
    
    
    @objc func buttonClicked(sender: UIButton)
    {
        var strOption =  ""
        var strTitle =  ""
        
        if sender.tag == 0 {
            return
        }
        
        if sender.tag == 10 {
            return
        }
            
            
        if sender.tag == 2 || sender.tag == 6
        {
            if sender.tag == 2{
                strOption = "Contactus"
                strTitle = "Contact Us"
            }else if sender.tag == 6{
                strOption = "AskQuestion"
                strTitle = "Ask a Question"
            }
            let objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
            objAskAQuestionViewController.strOption = strOption
            objAskAQuestionViewController.strTitle = strTitle
            objAskAQuestionViewController.isFromInfo = true
            self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
        }
        else
        {
            var  strURL  = ""
            
            if sender.tag == 1{
                strOption = "tradeininfo"
                strTitle = "Trade In Info"
                strURL = "https://www.essential-watches.com/tradein_iphone.php"
            }else  if sender.tag == 3{
                strOption = "about"
                strTitle = "About Us"
                strURL = "https://www.essential-watches.com/about_us.php"
            }else  if sender.tag == 4{
                strOption = "testimonial"
                strTitle = "Testimonial"
                strURL = "https://www.essential-watches.com/testimonials_iphone.php"
            }else  if sender.tag == 5{
                strOption = "eBay store"
                strTitle = "eBay Store"
                strURL = "http://stores.ebay.com/Essential-Watches"
            }else  if sender.tag == 7{
                strOption = "FAQ"
                strTitle = "FAQ"
                strURL = "https://www.essential-watches.com/faq_iphone.php"
            }else  if sender.tag == 8{
                strOption = "Privacy Policy"
                strTitle = "Privacy Policy"
                strURL = "https://www.essential-watches.com/privacy_iphone.php"
            }else  if sender.tag == 9{
                strOption = "Refund Policy"
                strTitle = "Refund Policy"
                strURL = "https://www.essential-watches.com/refund_iphone.php"
            }
            let objWebViewController = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
            objWebViewController.strOption = strOption
            objWebViewController.strTitle = strTitle
            objWebViewController.strURL = strURL
            self.navigationController?.pushViewController(objWebViewController, animated: true)
            //1. type - HaveUsSearch, AddNameToWaitList, SellWatchToUs, HaveSomethingSimilar, AskQuestion,Contact us,Purchase
        }

    }
}
