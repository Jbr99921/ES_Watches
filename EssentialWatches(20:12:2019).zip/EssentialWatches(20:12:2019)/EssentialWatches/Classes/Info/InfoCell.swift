//
//  InfoCell.swift
//  EssentialWatches
//
//  Created by Vikram on 09/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class InfoCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelVersion: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var buttonArrow: UIButton!
    @IBOutlet weak var imageViewArrow: UIImageView!
    @IBOutlet weak var viewBottom: UIView!
    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var buttonCell: UIButton!
    @IBOutlet weak var viewExpanded: UIView!
    
    @IBOutlet weak var labelInfo: UILabel!
    
    @IBOutlet weak var labelInfoAddress: UILabel!
    @IBOutlet weak var labelInfoPhone: UILabel!
    @IBOutlet weak var labelEmail: UILabel!

    
//    @IBOutlet weak var layoutConstraintLabelInfoHeight: NSLayoutConstraint!
//    @IBOutlet weak var layoutConstraintlInfoViewHeight: NSLayoutConstraint!
    
    var onButtonTapped : (() -> Void)? = nil

    override func awakeFromNib() {
        super.awakeFromNib()
    }
 
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
