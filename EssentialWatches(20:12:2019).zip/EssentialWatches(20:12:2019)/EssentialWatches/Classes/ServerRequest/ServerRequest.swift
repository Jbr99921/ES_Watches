

//
//  ServerRequest.swift
//  EssentialWatches
//
//  Created by Vikram on 11/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import Alamofire
import Unbox
import SwiftyJSON

class ServerRequest: NSObject
{
    static let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")

    static let sharedInstance: ServerRequest = {
        let instance = ServerRequest()
        // setup code
        return instance
    }()
    
    // ------------------------------------------------------------------------------------------------------------------

    
    
    class  func sendServerRequestWithDict(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

        print("sendServerRequestWithDict \n\n\n\n\n *************************************************")
//        print(url)
//        print(dictParam)
        print("*************************************************\n\n\n\n\n")
     

        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }

        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[Brand]>) in
            print(response.result.value)
            switch response.result
            {
                case .success(let searchResult):
                    completion(searchResult ,true)
                case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    

        class  func sendBrandRequestForBrandList(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
        {

            let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]!
            let url = KConstant.kServerURL + dictParam[KConstant.kMethod]! + strAppend
            
//            let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

            print("sendServerRequestWithDict \n\n\n\n\n *************************************************")
    //        print(url)
    //        print(dictParam)
            print("*************************************************\n\n\n\n\n")
         

            if !(reachabilityManager?.isReachable)!{
                let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                    alert.dismiss(animated: true, completion: nil)
                })
                KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
                return
            }

            Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[BrandList]>) in
                print(response.result.value)
                switch response.result
                {
                    case .success(let searchResult):
                        completion(searchResult ,true)
                    case .failure(let error):
                    print("error: \(error)")
                    completion(error,false)
                }
            }
        }
    
    /*
    class  func sendServerRequestWithDictForPopularBrands1<T>(_ obj: T, completion:@escaping (_ response : Any, _ result  : Bool) ->())
    {
    
    }
 */
    
    class  func sendServerRequestWithDictForPopularBrands(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]!
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]! + strAppend
/*
        print("\n\n\n\n\n ************************ sendServerRequestWithDictForPopularBrands **************************************************************************")
        print(url)
        print("*************************************************************************************************************************\n\n\n\n\n")
   */
        
        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[Brand]>) in

            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }

    
    class  func sendServerRequestWithDictLatestWatch(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
 
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        print(url)
        
        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[LatestWatch]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    
    class  func sendServerRequestWithDictFeaturetWatch(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        print(url)
        
        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[FeaturedWatch]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    
    
    class  func sendServerRequestWithDictForAllLatestWatches(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]! + "&deviceid=" + dictParam["deviceid"]!
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]! + strAppend
        print(url)
        
        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[LatestWatch]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    class  func sendServerRequestWithDictForAllFeaturedWatches(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]!
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]! + strAppend
        print(url)
        
        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[FeaturedWatch]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    
    class  func sendServerRequestWithDictForModels(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
//        print("\n\n\n\n\n*************************************************************************************************************************")
//        print(url)
//        print(dictTempParams)
//        print("*************************************************************************************************************************\n\n\n\n\n")
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[Model]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    class  func sendServerRequestWithDictForSubModels(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
 //       print("\n\n\n\n\n*************************************************************************************************************************")
   //     print(url)
     //   print(dictTempParams)
  //      print("*************************************************************************************************************************\n\n\n\n\n")
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[SubModel]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    
    
    class  func sendServerRequestWithDictForYoutubeVideos(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]!

        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]! + strAppend
//        print(url)
        
        Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[YoutubeVideo]>) in
            switch response.result
        {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    class  func sendServerRequestforPostMethod(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam

        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseJSON { (response: DataResponse<Any>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
 
    /*
    class  func sendServerRequestWithDictForYoutubeVideos(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        print(url)
        //?start=0&end=10
        
        dictParam.removeValue(forKey: KConstant.kMethod)
        
        Alamofire.request(url, method: .post, parameters: dictParam, encoding:URLEncoding.default, headers: requestHeader()).responseObject { (response: DataResponse<YoutubeVideo>) in
   
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
 */
    
    class  func sendServerRequestSubVariation(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
        {
            if !(reachabilityManager?.isReachable)!{
                let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                    alert.dismiss(animated: true, completion: nil)
                })
                KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
                return
            }
            
            let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

            var dictTempParams = dictParam
            dictTempParams.removeValue(forKey: KConstant.kMethod)
            
    //        print("\n\n\n\n\n*************************************************************************************************************************")
    //        print(url)
    //        print(dictTempParams)
    //        print("*************************************************************************************************************************\n\n\n\n\n")

            Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[Model]>) in
                switch response.result
                {
                case .success(let searchResult):
                    completion(searchResult ,true)
                case .failure(let error):
                    print("error: \(error)")
                    completion(error,false)
                }
            }
        }
    
    class  func sendServerRequestVariation(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
        {
            if !(reachabilityManager?.isReachable)!{
                let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                    alert.dismiss(animated: true, completion: nil)
                })
                KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
                return
            }
            
            let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

            var dictTempParams = dictParam
            dictTempParams.removeValue(forKey: KConstant.kMethod)
            
    //        print("\n\n\n\n\n*************************************************************************************************************************")
    //        print(url)
    //        print(dictTempParams)
    //        print("*************************************************************************************************************************\n\n\n\n\n")

            Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[Model]>) in
                switch response.result
                {
                case .success(let searchResult):
                    completion(searchResult ,true)
                case .failure(let error):
                    print("error: \(error)")
                    completion(error,false)
                }
            }
        }
    
    class  func sendServerRequestWithPostMethod(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
//        print("\n\n\n\n\n*************************************************************************************************************************")
//        print(url)
//        print(dictTempParams)
//        print("*************************************************************************************************************************\n\n\n\n\n")

        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[WatchModel]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    class  func sendServerRequestWithPostMethodForRowModels(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)

        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[WatchModelRow]>) in
            print("Result ")
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    class  func sendServerRequesToSubmitForm(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding: JSONEncoding.default, headers: requestHeader())
            .responseJSON { response in
                switch response.result
                {
                case .success(let searchResult):
                    completion(searchResult ,true)
                case .failure(let error):
                    print("error: \(error)")
                    completion(error,false)
                }
        }
    }
    
    
   class func sendServerRequestWithPostMethodForImageUpload(dictParam : Dictionary<String, String>, image : UIImage, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)

        Alamofire.upload(multipartFormData: { (multipartFormData) in
            multipartFormData.append(image.jpegData(compressionQuality: 1)!, withName: "imageupload", fileName: "iOSForm.png", mimeType: "image/jpeg")
            for (key, value) in dictTempParams {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
            }
        }, to:url)
        { (result) in
            
            switch result
            {
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (progress) in
                    //Print progress
                })
                
                upload.responseJSON { response in
                    //print response.result
                }
                
            case .failure(let encodingError): break
                //print encodingError.description
            }
        }

        
        
        /*
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[WatchModel]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
        */
    }
    
   class   func sendServerRequestWithPostMethodForRecentWatches(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)

        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[RecentWatch]>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
        class  func sendServerRequestWithPostMethodForDateRange(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
        {
            if !(reachabilityManager?.isReachable)!{
                let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                    alert.dismiss(animated: true, completion: nil)
                })
                KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
                return
            }
            
            let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

            var dictTempParams = dictParam
            dictTempParams.removeValue(forKey: KConstant.kMethod)
            
            Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers:requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[DateRangeModel]>) in
                print(response.result.value)
                switch response.result
                {
                case .success(let searchResult):
                completion(searchResult ,true)
                case .failure(let error):
                print("error: \(error)")
                completion(error,false)
                }
            }
        }
    
    class  func sendServerRequestWithPostMethodForWatchList(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!

        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers:requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[WatchHeader]>) in
            print(response.result.value)
            
//            if (response.result.value)!.isEmpty{
//                let alert = UIAlertController(title: KConstant.kAPPName, message:"Sorry Data not Found.", preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
//                    alert.dismiss(animated: true, completion: nil)
//                    })
//
//            }else{
            switch response.result
            {
            case .success(let searchResult):
            completion(searchResult ,true)
            case .failure(let error):
            print("error: \(error)")
            completion(error,false)
            }
        }
    }
    
    class  func sendPostRequestForSimilarProducts(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        var dictTempParams = dictParam

        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[SimilarWatch]>) in
        
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    
    
    class  func sendServerRequestWithDictSearch(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }

        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)
        
        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseArray(keyPath:"list") { (response: DataResponse<[Search]>) in
            switch response.result
            {
                
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    class  func sendServerRequestWithDictForProductInfo(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)

        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding:URLEncoding.default, headers: requestHeader()).responseObject(keyPath:"list") { (response: DataResponse<Search>) in
            print(response.result.value)
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
    
    
    
    class  func sendPostRequestWithDict(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        let url = KConstant.kServerURL + dictParam[KConstant.kMethod]!
        
        var dictTempParams = dictParam
        dictTempParams.removeValue(forKey: KConstant.kMethod)

        Alamofire.request(url, method: .post, parameters: dictTempParams, encoding: URLEncoding.default, headers: requestHeader())
            .responseJSON { response in
                if let result = response.result.value {
                    let JSON = result as! NSDictionary
                    print(JSON)
                    let nResult : Int =  JSON["result"] as! Int
                    if  nResult == 1
                    {
                        completion(JSON,true)
                    }else{
                        completion(JSON,false)
                    }
                    print(JSON)
                }
        }
    }
    
    
    class  func sendServerRequestforGetMethod(dictParam : Dictionary<String, String>,APIName :  String,  completion:@escaping (_ response : Any, _ result  : Bool) ->() )
    {
        
        if !(reachabilityManager?.isReachable)!{
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
            return
        }
        
        
        //        let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]!
        let url = KConstant.kServerURL + APIName
        print(url)
        
        Alamofire.request(url, method: .get, parameters: dictParam, encoding: URLEncoding.default, headers: requestHeader()).responseJSON { (response:DataResponse<Any>) in
            switch response.result
            {
            case .success(let searchResult):
                completion(searchResult ,true)
            case .failure(let error):
                print("error: \(error)")
                completion(error,false)
            }
        }
    }
    
       class  func sendeServerRequestForVideos(dictParam : Dictionary<String, String>, completion:@escaping (_ response : Any, _ result  : Bool) ->() )
        {
            if !(reachabilityManager?.isReachable)!{
                let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                    alert.dismiss(animated: true, completion: nil)
                })
                KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
                return
            }
            
            let strAppend : String =  "?start=" + dictParam["start"]! + "&end=" + dictParam["end"]!
            let url = KConstant.kServerURL + dictParam[KConstant.kMethod]! + strAppend
            Alamofire.request(url, method: .get, headers: requestHeader()).responseArray(keyPath:"list") { (response : DataResponse<[WatchVideoList]>) in
                switch response.result
            {
                case .success(let searchResult):
                    completion(searchResult ,true)
                case .failure(let error):
                    print("error: \(error)")
                    completion(error,false)
                }
            }
        }
  }
