//
//  FormFooterView.swift
//  EssentialWatches
//
//  Created by Vikram on 17/10/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class FormFooterView: UIView {

    @IBOutlet weak var textViewComments: UITextView!
    @IBOutlet weak var buttonSubmit: UIButton!

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
