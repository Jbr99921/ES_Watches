//
//  FormsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 17/10/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire
import Firebase


class FormsViewController: BaseViewController, UITextViewDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIScrollViewDelegate {

    var nIndex = 0
    var nConditionTag = 0
    var nBrandTag = 0
    
    var strFormType = ""
    var strConditionIndex = ""
    var strConditionIndexInterest = ""
    
    var strBrandParam = ""
    var strBrandParamInterest = ""
    var isFromHome = false
    var isTextViewEntered = false
    
  
    var isStatusSelectionRequired: Bool!
    
    //````````
    
    var imageData = NSData()
    
    @IBOutlet weak var textFieldFirstName: ECW_TextField!
    @IBOutlet weak var textFieldLastName: ECW_TextField!
    @IBOutlet weak var textFieldEmail: ECW_TextField!
    @IBOutlet weak var textFieldPhone: ECW_TextField!
    
    
    @IBOutlet weak var textFieldBrand: ECW_TextField!
    @IBOutlet weak var textFieldModel: ECW_TextField!
    @IBOutlet weak var textFieldCondition: ECW_TextField!
    @IBOutlet weak var textFieldType: ECW_TextField!
    @IBOutlet weak var textFieldDial: ECW_TextField!
    @IBOutlet weak var textFieldEstValue: ECW_TextField!

    @IBOutlet weak var buttonImageWatch: UIButton!
    
    @IBOutlet weak var textFieldBrandInterest: ECW_TextField!
    @IBOutlet weak var textFieldModelInterest: ECW_TextField!
    @IBOutlet weak var textFieldConditionInterest: ECW_TextField!
    @IBOutlet weak var textFieldTypeInterest: ECW_TextField!
    @IBOutlet weak var textFieldDialInterest: ECW_TextField!
    @IBOutlet weak var textFieldEstValueInterest: ECW_TextField!
    @IBOutlet weak var txtNotes: UITextView!

    @IBOutlet weak var txtFullName: ECW_TextField!
    @IBOutlet weak var lblNamePrice: UILabel!
    
    @IBOutlet weak var imageViewWatch: UIImageView!

    @IBOutlet weak var viewInterest: UIView!
    @IBOutlet weak var scrollViewRequestTrade: TPKeyboardAvoidingScrollView!
    
   
    @IBOutlet weak var layoutConstraintViewInterestHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintSubmitButtonTopSpace: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintSellTradeTopSpace: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintViewInfoTopSpace: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!
       
    
    
    @IBOutlet var btnSales: UIButton!
    @IBOutlet var btnTrade: UIButton!
    @IBOutlet var viewStatus: UIView!
    
    
    @IBOutlet weak var statusViewHeight: NSLayoutConstraint!
    

    var arrBrands = Array<Brand>()

    var arrPickerData = ["010"]
    var arrCondition = ["Box only","Papers only","Box and Papers","Neither"]

    var isHiddenKeyboard : Bool = false

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if !self.isFromHome{
            self.setIsRequiedMenuYes()
            
            if DeviceUtility.isIphoneXType{
                     layoutConstraintViewInfoTopSpace.constant =  25
                 }else{
                     layoutConstraintViewInfoTopSpace.constant =  5
                 }
        }
        
        layoutConstraintViewInterestHeight.constant = 0
        viewInterest.isHidden = true

        txtNotes.delegate = self
        self.txtNotes.layer.borderColor = UIColor.lightGray.cgColor
        self.txtNotes.layer.borderWidth = 0.5

        self.viewHeader.buttonLogo.isHidden = true
        //``````````````
        isHiddenKeyboard = false
        let center = NotificationCenter.default
        center.addObserver(self,selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
      
        self.getBrands()
        
        self.scrollViewRequestTrade.delegate = self
        textFieldFirstName.becomeFirstResponder()
        
        if DeviceUtility.isIphoneXType {
            layoutConstraintTopViewTopSpace.constant = (viewHeader.frame.origin.y + viewHeader.frame.size.height + 5)
        }else{
             layoutConstraintTopViewTopSpace.constant = (viewHeader.frame.origin.y + viewHeader.frame.size.height + 5)
        }
        
        //Bhavesh `````````
        self.btnSales.isSelected = true
        self.btnTrade.isSelected = false
        
        self.btnSales.setTitle("Sell", for: .normal)
        self.btnTrade.setTitle("Trade", for: .normal)
        
        self.btnTrade.addTarget(self, action: #selector(self.btnTradeClick(_:)), for: .touchUpInside)
        self.btnSales.addTarget(self, action: #selector(self.btnSalesClick(_:)), for: .touchUpInside)
        //`````````````````
        
     
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        //Bhavesh 2-Dec```````````
        
        
             var strTitle = "Sell & Trade"
        
             if self.isStatusSelectionRequired == false{
                     self.statusViewHeight.constant = 0
                     self.viewStatus.isHidden = true
             }else{
                     self.statusViewHeight.constant = 50
                     nIndex = 6
                     self.viewStatus.isHidden = false
             }
             //````````````````````
        
        if nIndex ==  6{
            if self.isStatusSelectionRequired == false{
                strTitle =  "Sell Your Watch"
            }
            self.setTitleLabel(title: "Sell Your Watch")
            strFormType = "1"
            layoutConstraintViewInterestHeight.constant = 0
//            layoutConstraintSubmitButtonTopSpace.constant = 430
            Analytics.logEvent("Sell_Your_Watch_Screen", parameters: [
                "name": "\(strTitle) Screen" as NSObject,
                ])
        }else  if nIndex ==  7{
            if self.isStatusSelectionRequired == false{
               strTitle =  "Trade-In Your Watch"
            }
            strFormType = "2"
            layoutConstraintViewInterestHeight.constant = 500
//            layoutConstraintSubmitButtonTopSpace.constant = 940
            viewInterest.isHidden = false
            Analytics.logEvent("Trade-In_Your_Watch_Screen", parameters: [
                "name": "\(strTitle) Screen" as NSObject,
                ])
        }else  if nIndex ==  8{
            strFormType = "3"
            strTitle =  "Get Your Watch Authenticated"
            layoutConstraintViewInterestHeight.constant = 500
//            layoutConstraintSubmitButtonTopSpace.constant = 430
            Analytics.logEvent("Get_Your_Watch_Authenticated_Screen", parameters: [
                "name": "\(strTitle) Screen" as NSObject,
                ])
        }else  if nIndex ==  9{
            strFormType = "4"
            strTitle =  "Certified Appraisal"
            layoutConstraintViewInterestHeight.constant = 500
//            layoutConstraintSubmitButtonTopSpace.constant = 430
            Analytics.logEvent("Certified_Appraisal_Screen", parameters: [
                "name": "\(strTitle) Screen" as NSObject,
                ])
        }
        
        self.setTitleLabel(title: strTitle)
        super.viewWillAppear(animated);
//
//        Analytics.logEvent("\(strTitle)Screen", parameters: [
//            "name": "\(strTitle) Screen" as NSObject,
//            ])
        

        
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: strTitle+" Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
            textFieldFirstName.text = dictTemp?.value(forKey:KConstant.kFirstName) as? String
            textFieldLastName.text = dictTemp?.value(forKey:KConstant.kLastName) as? String
            textFieldPhone.text = dictTemp?.value(forKey:KConstant.kMobileNum) as? String
            textFieldEmail.text = dictTemp?.value(forKey:KConstant.kEmail) as? String
        }
    }

    // ------------------------------------------------------------------------------------------------------------------

    override  func viewDidLayoutSubviews() {
        
        if KConstant.IS_IPHONE5
        {
            if nIndex ==  7{
                self.scrollViewRequestTrade.contentSize = CGSize(width: self.scrollViewRequestTrade.frame.size.width, height: 1600)
            }else{
                self.scrollViewRequestTrade.contentSize = CGSize(width: self.scrollViewRequestTrade.frame.size.width, height: 1150)
            }
        }
        else
        {
            if nIndex ==  7
            {
                    self.scrollViewRequestTrade.contentSize = CGSize(width: self.scrollViewRequestTrade.frame.size.width, height: 1750)
            }else{
                var nHeight = 1260 as CGFloat
                if KConstant.IS_IPHONE_X{
                    nHeight = 1300
                }
                self.scrollViewRequestTrade.contentSize = CGSize(width: self.scrollViewRequestTrade.frame.size.width, height: nHeight)
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func getBrands()
    {
        var arrTemp = ["010"]
        for i in 0 ..< KConstant.APP.arrBrands.count {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            arrTemp.append(objBrand.BrandName)
        }
        arrTemp.remove(at: 0)
        self.arrPickerData = arrTemp
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func resignTextFields(){
        textFieldFirstName.resignFirstResponder()
        textFieldLastName.resignFirstResponder()
        textFieldEmail.resignFirstResponder()
        textFieldPhone.resignFirstResponder()
        textFieldBrand.resignFirstResponder()
        textFieldModel.resignFirstResponder()
        textFieldCondition.resignFirstResponder()
        textFieldType.resignFirstResponder()
        textFieldDial.resignFirstResponder()
        textFieldEstValue.resignFirstResponder()
        textFieldBrandInterest.resignFirstResponder()
        textFieldModelInterest.resignFirstResponder()
        textFieldConditionInterest.resignFirstResponder()
        textFieldTypeInterest.resignFirstResponder()
        textFieldDialInterest.resignFirstResponder()
        textFieldEstValueInterest.resignFirstResponder()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func showActionSheet() {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (alert:UIAlertAction!) -> Void in
            self.camera()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { (alert:UIAlertAction!) -> Void in
            self.photoLibrary()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
    }

    // ------------------------------------------------------------------------------------------------------------------

    func photoLibrary()
    {
        let myPickerController = UIImagePickerController()
        myPickerController.delegate = self;
        myPickerController.sourceType = .photoLibrary
        self.present(myPickerController, animated: true, completion: nil)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func camera()
    {
        let myPickerController = UIImagePickerController()
        myPickerController.delegate = self;
        myPickerController.sourceType =  .camera
        self.present(myPickerController, animated: true, completion: nil)
        
    }
    
    func submitForm()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
//             self.progressShow(true) //ProgressHUD.show()

            self.progressShow(true)
        }
          let dictParams = ["firstname": textFieldFirstName.text!,
                              "lastname": textFieldLastName.text!,
                              "email": textFieldEmail.text!,
                              "phonenumber": textFieldPhone.text!,
                              "brand": strBrandParam,
                              "model": textFieldModel.text!,
                              "watchcondition": strConditionIndex,
                              "typeofmetal": textFieldType.text!,
                              "dialdescription": textFieldDial.text!,
                              "estimatedvalue": textFieldEstValue.text!,
                              "brandIn": strBrandParamInterest,
                              "modelIn": textFieldModelInterest.text!,
                              "watchconditionIn": strConditionIndexInterest,
                              "typeofmetalIn": textFieldTypeInterest.text!,
                              "dialdescriptionIn": textFieldDialInterest.text!,
                              "estimatedvalueIn": textFieldEstValueInterest.text!,
                              "type": strFormType,
                              "devicetype": "0"] as [String : Any] //as! [String: Any]
//        print(dictParams)

        var image = self.imageViewWatch.image!
        
        let data1 = image.pngData()
        let data2 = UIImage(named: KConstant.kImagePlaceholderName)!.pngData()
        
        if data1 == data2{
            image =  UIImage(named: "noimage")!
        }
        
        
        Alamofire.upload(multipartFormData: { multipartFormData in multipartFormData.append((image).jpegData(compressionQuality: 0)!, withName: "imageupload", fileName: "ImageSeller.jpeg", mimeType: "image/jpeg")
            
            for (key, value) in dictParams {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
            }
            for (key, value) in dictParams {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
            }
        }, to: "https://www.essential-watches.com/API/seller_watch_api.php",
           encodingCompletion: { encodingResult in
            
            switch encodingResult
            {
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    let alert = UIAlertController(title: KConstant.kAPPName, message:"Your request has been sent, we will contact you soon", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                        self.resignTextFields()
                        if !self.isFromHome{
                            KConstant.APP.setTwoWaySiderAsRootController()
                        }else{
                            self.navigationController?.popViewController(animated: true)
                        }
                    })
                    self.present(alert, animated: true, completion: nil)
                    //self.displayAlertWithWithPopViewController(message: "Your request has been sent, we will contact you soon")
//                     self.progressShow(false) // ProgressHUD.dismiss()

                    self.progressShow(false)
                }
            case .failure(let error):
                print(error)
            }
        })
 
//
//                ServerRequest.sendServerRequestWithPostMethodForImageUpload(dictParam: dictParams, image: imageViewWatch.image!) {  (response, isSuccess)  in
//                    print("\n\n\n\nasd================================ ",response)
//                    print("================================ \n\n\n")
//                }
    }

    // ------------------------------------------------------------------------------------------------------------------

    /*
    // MARK: - Action Methods
    */

    // ------------------------------------------------------------------------------------------------------------------
    
    //Bhavesh ````````````````
    
    @objc func btnSalesClick(_ sender: UIButton){
        
        sender.isSelected  = true
        self.btnTrade.isSelected = false
        strFormType = "1"
        nIndex = 6
    }
    
    @objc func btnTradeClick(_ sender: UIButton){
        sender.isSelected  = true
        self.btnSales.isSelected = false
        strFormType = "2"
        nIndex = 7
    }
    
    //````````````

    @IBAction func buttonSubmitClicked(_ sender: Any) {
       
        self.resignTextFields()
        
        if textFieldFirstName.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter First Name.")
            return
        }
        
        if textFieldLastName.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Last Name.")
            return
        }
        
        if textFieldEmail.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Email.")
            return
        }
        
        if self.validateEmail(strEmail: textFieldEmail.text!) == false{
            self.displayAlertWithOk(message: "Please Enter Valid Email")
            return
        }
        
        if textFieldPhone.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Phone Number.")
            return
        }

        if textFieldBrand.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Select Brand of Watch.")
            return
        }
        
        if textFieldModel.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Model of Watch.")
            return
        }
        
        if textFieldCondition.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Select Watch Condition.")
            return
        }
        
        if textFieldType.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Type of Metal.")
            return
        }

        if textFieldDial.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Dial Description.")
            return
        }
        
        if textFieldEstValue.text?.count == 0 {
            self.displayAlertWithOk(message: "Please Enter Estimated Value.")
            return
        }

   
        //
        if nIndex == 6 {
            if textFieldBrandInterest.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Select Brand of Watch.")
                return
            }
            
            if textFieldModelInterest.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Enter Model of Watch.")
                return
            }
            
            if textFieldConditionInterest.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Select Watch Condition.")
                return
            }
            
            if textFieldTypeInterest.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Enter Type of Metal.")
                return
            }
            
            if textFieldDialInterest.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Enter Dial Description.")
                return
            }
            
            if textFieldEstValueInterest.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Enter Estimated Value.")
                return
            }
            
            if txtNotes.text?.count == 0 {
                self.displayAlertWithOk(message: "Please Enter Notes.")
                return
            }
        }
       
        let dict:NSDictionary = [KConstant.kFirstName: textFieldFirstName.text ?? "", KConstant.kLastName: textFieldLastName.text ?? "", KConstant.kMobileNum : textFieldPhone.text ?? "", KConstant.kEmail : textFieldEmail.text ?? ""]
        KConstant.APP.saveValueInUserDefault(dict: dict)
        self.submitForm()
    }
    
    // ------------------------------------------------------------------------------------------------------------------


    @IBAction func buttonBrandClicked(_ sender: Any)
    {
        self.resignTextFields()

         nBrandTag = (sender as AnyObject).tag
          self.resignTextFields()
//          let picker: SBPickerSelector = SBPickerSelector()
//          picker.pickerData =  arrPickerData//picker content
//            picker.tag = 0
//          picker.delegate = self
//          picker.pickerType = .text
//          picker.doneButtonTitle = "Done"
//          picker.cancelButtonTitle = "Cancel"
//          picker.showPicker(from: self.view, in: self)
        
        SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:self.arrPickerData, defaultDate: Date()).cancel {
            
            }.set { values in
                if let values = values as? [Brand]
                {
                    let objBrand : Brand =  values[0] as Brand
                    if  self.nBrandTag == 101 {
                        self.textFieldBrand.text = objBrand.BrandName
                        self.strBrandParam = objBrand.BrandID
                     }else{
                        self.strBrandParamInterest = objBrand.BrandID
                        self.textFieldBrand.text = objBrand.BrandName
                     }
                }

        }.present(into: self)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonConditionClicked(_ sender: Any) {
        self.resignTextFields()

        nConditionTag = (sender as AnyObject).tag

        self.resignTextFields()
//        let picker: SBPickerSelector = SBPickerSelector()
//        picker.pickerData =  arrCondition//picker content
//        picker.delegate = self
//        picker.tag = 1
//        picker.pickerType = .text
//        picker.doneButtonTitle = "Done"
//        picker.cancelButtonTitle = "Cancel"
//        picker.showPicker(from: self.view, in: self)
        
        SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:self.arrCondition, defaultDate: Date()).cancel {
            
            }.set { values in
                if let values = values as? [String]
                {
                    if  self.nConditionTag == 201
                     {
                           // strConditionIndex = String(format: "%d", m)
                        self.textFieldCondition.text = values[0]
                    }else{
                           // strConditionIndexInterest = String(format: "%d", m)
                        self.textFieldConditionInterest.text = values[0]
                    }
                }

        }.present(into: self)
        
    }

    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonUploadClicked(_ sender: Any) {
        self.resignTextFields()
        self.showActionSheet()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonImageClicked(_ sender: Any) {
        self.resignTextFields()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
   override func backButtonClicked()
    {
        self.resignTextFields()
        if !isRequiedHome {
            self.navigationController?.popViewController(animated: true)
        }else{
            KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func keyboardWillHide(notification: NSNotification)
    {
        isHiddenKeyboard = true
    }
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - SBPickerSelector Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
//    func pickerSelector(_ selector: SBPickerSelector, selectedValues values: [String], atIndexes idxs: [NSNumber])
//    {
//        let m = idxs[0] as! Int // m is an `Int64`
//        print(idxs.count)
//        print(idxs[0])
//
//        if selector.tag == 0
//        {
//            let objBrand : Brand =  KConstant.APP.arrBrands[m] as Brand
//            if  nBrandTag == 101 {
//                textFieldBrand.text = arrPickerData[m]
//                strBrandParam = objBrand.BrandID
//            }else{
//                strBrandParamInterest = objBrand.BrandID
//                textFieldBrandInterest.text = arrPickerData[m]
//            }
//        }
//        else if selector.tag == 1
//        {
//            if  nConditionTag == 201 {
//                strConditionIndex = String(format: "%d", m)
//                textFieldCondition.text = arrCondition[m]
//            }else{
//                strConditionIndexInterest = String(format: "%d", m)
//                textFieldConditionInterest.text = arrCondition[m]
//            }
//        }
//    }
    
    // ------------------------------------------------------------------------------------------------------------------
//
//    func pickerSelector(_ selector: SBPickerSelector, cancelPicker cancel: Bool){
//        textFieldBrand.text = ""
//    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        if scrollView.contentOffset.x>0 {
            scrollView.contentOffset.x = 0
            self.view.updateConstraints()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIImagePickerController Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
        imageViewWatch.image = info["UIImagePickerControllerOriginalImage"] as? UIImage
//         imageDat: NSData = UIImagePNGRepresentation(imageViewWatch.image)! as NSData
        imageData = imageViewWatch.image!.pngData()! as NSData
        self.dismiss(animated: true, completion: nil)
    }
    // ------------------------------------------------------------------------------------------------------------------

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        self.dismiss(animated: true, completion: nil)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITextField Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {

        if  textField == textFieldFirstName{
                textFieldLastName.becomeFirstResponder()
        }else  if  textField == textFieldLastName{
            textFieldEmail.becomeFirstResponder()
        }else  if  textField == textFieldEmail{
            textFieldPhone.becomeFirstResponder()
        }else  if  textField == textFieldPhone{
            textField.resignFirstResponder()
        }else if  textField == textFieldModel{
            textFieldType.becomeFirstResponder()
        }else  if  textField == textFieldType{
            textFieldDial.becomeFirstResponder()
        }else  if  textField == textFieldDial{
            textFieldEstValue.becomeFirstResponder()
        }else  if  textField == textFieldEstValue{
            if nIndex ==  6{
                textFieldModelInterest.becomeFirstResponder()
            }else{
                txtNotes.becomeFirstResponder()
            }
        }
        
        if nIndex ==  6
        {
            if  textField == textFieldModelInterest{
                textFieldTypeInterest.becomeFirstResponder()
            }else  if  textField == textFieldTypeInterest{
                textFieldDialInterest.becomeFirstResponder()
            }else  if  textField == textFieldDialInterest{
                textFieldEstValueInterest.becomeFirstResponder()
            }else  if  textField == textFieldEstValueInterest{
                txtNotes.becomeFirstResponder()
            }
        }
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == textFieldFirstName {
              isHiddenKeyboard = false
        }else{
            isHiddenKeyboard = true
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
}
