//
// TabBarController.swift
// Sonictone
//
// Created by MSP on 16/08/18.
// Copyright © 2018 MSP. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController,UITabBarControllerDelegate {
    var menuButton:UIButton!
    var imgHome: UIImageView!
    var imgNewArrval: UIImageView!
    var imgBrand: UIImageView!
    var imgSellAndTrade: UIImageView!
    var imgVideo: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//        AppDelegate.sharedInstance().objCurrentNavigationController.isNavigationBarHidden = true
//        AppDelegate.sharedInstance().navigationController.isNavigationBarHidden = true
//        (AppDelegate.sharedInstance() as AnyObject).navigationController.isNavigationBarHidden = true
    
        setUserTabBar()
        
    }
    
    //Mark Set TabBarView
    func setUserTabBar(){
                
//        tabBar.isTranslucent = false
        self.tabBar.isTranslucent = false
        
        let homevc :HomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        
        let arrival : NewArrivalViewController = self.storyboard?.instantiateViewController(withIdentifier: "NewArrivalViewController") as! NewArrivalViewController
        
        let brand : BrandViewController = self.storyboard?.instantiateViewController(withIdentifier: "BrandViewController") as! BrandViewController
        
        let sellAndTrade : FormsViewController = self.storyboard?.instantiateViewController(withIdentifier: "FormsViewController") as! FormsViewController
        
        let videos : VideoListViewController = self.storyboard?.instantiateViewController(withIdentifier: "VideoListViewController") as! VideoListViewController
        
//        UITabBar.appearance().tintColor = UIColor.white // Foe selected tab

//        if #available(iOS 10.0, *) {
//            UITabBar.appearance().unselectedItemTintColor = UIColor.white
//        } else {
//            // Fallback on earlier versions
//        }
        UITabBar.appearance().barTintColor = KConstant.kColorThemeYellow
        
        let nav1 = UINavigationController(rootViewController: homevc)
        let nav2 = UINavigationController(rootViewController: arrival)
        let nav3 = UINavigationController(rootViewController: brand)
        let nav4 = UINavigationController(rootViewController: sellAndTrade)
        let nav5 = UINavigationController(rootViewController: videos)
        
        //=========tabimg selected===========
        let imgHomeTab :UIImage=UIImage(named:"TabHome_Selected")!
        // imgHome.multiplyImageByConstantColor(image: imgHome, color: UIColor.init(hexColorString:"#000000"))
        imgHomeTab.withRenderingMode(.alwaysOriginal)
        
        let imgNewArrivalTab:UIImage=UIImage(named: "TabNewarrival_Selected")!
        // imgBank.multiplyImageByConstantColor(image: imgBank, color: UIColor.init(hexColorString:"#000000"))
        imgNewArrivalTab.withRenderingMode(.alwaysOriginal)
        
        let imgBrandTab :UIImage=UIImage(named: "TabBrands_Unselected")!
        // imgMobileEmail.multiplyImageByConstantColor(image: imgMobileEmail, color: UIColor.init(hexColorString:"#000000"))
        imgBrandTab.withRenderingMode(.alwaysOriginal)
        
        let imgSellandTradeTab : UIImage=UIImage(named:"TabSelltrade_Selected")!
        // imgInbox.multiplyImageByConstantColor(image: imgInbox, color:UIColor.init(hexColorString:"#000000"))
        imgSellandTradeTab.withRenderingMode(.alwaysOriginal)
        self.delegate=self
        
        let imgVideosTab : UIImage=UIImage(named:"tabVideos_Selected")!
        // imgInbox.multiplyImageByConstantColor(image: imgInbox, color:UIColor.init(hexColorString:"#000000"))
        imgVideosTab.withRenderingMode(.alwaysOriginal)
        self.delegate=self
        
        
        //=========tabimg selected===========
        let icon1 = UITabBarItem(title: "Home", image: UIImage(named: "TabHome_Unselected")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "TabHome_Selected"))
//            UITabBarItem(title: nil, image: UIImage(named: "TabHome_Unselected"), selectedImage: UIImage(named: "TabHome_Selected"))
        nav1.tabBarItem=icon1
        nav1.tabBarItem.tag = 0
        nav1.tabBarItem.imageInsets = UIEdgeInsets(top: 4, left: 0, bottom: -4, right: 0)
        nav1.title = "Home"
        
        let icon2 = UITabBarItem(title: "New Arrivals", image: UIImage(named: "TabNewarrival_Unselected")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "TabNewarrival_Selected"))
//            UITabBarItem(title: nil, image: UIImage(named: "TabNewarrival_Unselected"), selectedImage: UIImage(named: "TabNewarrival_Selected"))
        nav2.tabBarItem=icon2
        nav2.tabBarItem.tag = 1
        nav2.tabBarItem.imageInsets = UIEdgeInsets(top: 4, left: 0, bottom: -4, right: 0)
        nav2.title = "New Arrivals"
        
        let icon3 =  UITabBarItem(title: "Brands", image: UIImage(named: "TabBrands_Unselected")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "TabBrands_Unselected"))
//            UITabBarItem(title: nil, image: UIImage(named: "TabBrands_Unselected"), selectedImage: UIImage(named: "TabBrands_Unselected"))
        nav3.tabBarItem=icon3
        nav3.tabBarItem.tag = 2
        nav3.tabBarItem.imageInsets = UIEdgeInsets(top: 4, left: 0, bottom: -4, right: 0)
        nav3.title = "Brands"
        
        let icon4 =  UITabBarItem(title: "Sell And Trade", image: UIImage(named: "TabSelltrade_Unselected")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "TabSelltrade_Selected"))
//            UITabBarItem(title: nil, image: UIImage(named: "TabSelltrade_Unselected"), selectedImage: UIImage(named: "TabSelltrade_Selected"))
        nav4.tabBarItem = icon4
        nav4.tabBarItem.tag = 3
        nav4.tabBarItem.imageInsets = UIEdgeInsets(top: 4, left: 0, bottom: -4, right: 0)
        nav4.title = "Sell And Trade"
        
        let icon5 = UITabBarItem(title: "Videos", image: UIImage(named: "tabVideos_Unselected")?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), selectedImage: UIImage(named: "tabVideos_Selected"))
//            UITabBarItem(title: nil, image: UIImage(named: "tabVideos_Unselected"), selectedImage: UIImage(named: "tabVideos_Selected"))
        nav5.tabBarItem = icon5
        nav5.tabBarItem.tag = 4
        nav5.tabBarItem.imageInsets = UIEdgeInsets(top: 4, left: 0, bottom: -4, right: 0)
        nav5.title = "Videos"
        
        
        // let tabBar = UITabBar.appearance()
//         tabBar.unselectedItemTintColor = UIColor.white
        
        self.viewControllers=[nav1,nav2,nav3,nav4,nav5]
        
        let homeItem = self.tabBar.subviews[0]
        self.imgHome = homeItem.subviews.first as? UIImageView
        self.imgHome.contentMode = .center
        
        let newArrivalItemView = self.tabBar.subviews[1]
        self.imgNewArrval = newArrivalItemView.subviews.first as? UIImageView
        self.imgNewArrval.contentMode = .center
        
        let brandItemView = self.tabBar.subviews[2]
        self.imgBrand = brandItemView.subviews.first as? UIImageView
        self.imgBrand.contentMode = .center
        
        let sellAndTrandeItemView = self.tabBar.subviews[3]
        self.imgSellAndTrade = sellAndTrandeItemView.subviews.first as? UIImageView
        self.imgSellAndTrade.contentMode = .center
        
        let videoItemView = self.tabBar.subviews[4]
        self.imgVideo = videoItemView.subviews.first as? UIImageView
        self.imgVideo.contentMode = .center
        
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.black], for: .selected)
        
    
        UITabBar.appearance().tintColor = .black
        nav1.isNavigationBarHidden = true
        nav2.isNavigationBarHidden = true
        nav3.isNavigationBarHidden = true
        nav4.isNavigationBarHidden = true
        nav5.isNavigationBarHidden = true
        //        UITabBar.appearance().selectionIndicatorImage = UIImage().makeImageWithColorAndSize(color: colorset.HeaderBGColor, size: CGSize(width: tabBar.frame.width/5, height: tabBar.frame.height))
//
//        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.font: UIFont(], for: .normal)
        
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        
        if item.tag == 0{
            self.imgHome.transform = CGAffineTransform.identity
            
            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
//            bounceAnimation.values = [1.0 ,1.3, 1.0]
            bounceAnimation.values = [1.0 ,1.0, 1.0]
            bounceAnimation.duration = TimeInterval(0.3)
            bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
            self.imgHome.layer.add(bounceAnimation, forKey: "bounceAnimation")
        }
        else if item.tag == 1 {
            self.imgNewArrval.transform = CGAffineTransform.identity
            
            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
            bounceAnimation.values = [1.0 ,1.0, 1.0]
//            bounceAnimation.values = [1.0 ,1.3, 1.0]
            bounceAnimation.duration = TimeInterval(0.3)
            bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
            self.imgNewArrval.layer.add(bounceAnimation, forKey: "bounceAnimation")
        }
        else if item.tag == 2 {
            self.imgBrand.transform = CGAffineTransform.identity
            
            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
//            bounceAnimation.values = [1.0 ,1.3, 1.0]
            bounceAnimation.values = [1.0 ,1.0, 1.0]
            bounceAnimation.duration = TimeInterval(0.3)
            bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
            self.imgBrand.layer.add(bounceAnimation, forKey: "bounceAnimation")
        }
        else if item.tag == 3 {
            self.imgSellAndTrade.transform = CGAffineTransform.identity
            
            let sellAndTrade : FormsViewController = self.storyboard?.instantiateViewController(withIdentifier: "FormsViewController") as! FormsViewController
            sellAndTrade.isStatusSelectionRequired = true
            
            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
            bounceAnimation.values = [1.0 ,1.0, 1.0]
//            bounceAnimation.values = [1.0 ,1.3, 1.0]
            bounceAnimation.duration = TimeInterval(0.3)
            bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
            self.imgSellAndTrade.layer.add(bounceAnimation, forKey: "bounceAnimation")
        }
        else if item.tag == 4
        {
            self.imgVideo.transform = CGAffineTransform.identity
            
            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
            bounceAnimation.values = [1.0 ,1.0, 1.0]
//            bounceAnimation.values = [1.0 ,1.3, 1.0]
            bounceAnimation.duration = TimeInterval(0.3)
            bounceAnimation.calculationMode = CAAnimationCalculationMode.cubic
            self.imgVideo.layer.add(bounceAnimation, forKey: "bounceAnimation")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension UIImage{
    
    func multiplyImageByConstantColor(image:UIImage,color:UIColor){
        
        
        // guard let image = image else {
        // return nil
        // }
        
        let backgroundSize = image.size
        UIGraphicsBeginImageContextWithOptions(backgroundSize, false, UIScreen.main.scale)
        
        let ctx = UIGraphicsGetCurrentContext()!
        
        var backgroundRect=CGRect()
        backgroundRect.size = backgroundSize
        backgroundRect.origin.x = 0
        backgroundRect.origin.y = 0
        
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        color.getRed(&r, green: &g, blue: &b, alpha: &a)
        ctx.setFillColor(red: r, green: g, blue: b, alpha: a)
        ctx.fill(backgroundRect)
        
        var imageRect = CGRect()
        imageRect.size = image.size
        imageRect.origin.x = (backgroundSize.width - image.size.width) / 2
        imageRect.origin.y = (backgroundSize.height - image.size.height) / 2
        
        // Unflip the image
        ctx.translateBy(x: 0, y: backgroundSize.height)
        ctx.scaleBy(x: 1.0, y: -1.0)
        
        ctx.setBlendMode(.destinationIn)
        ctx.draw(image.cgImage!, in: imageRect)
        
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
    }
    
    
    func makeImageWithColorAndSize(color: UIColor, size: CGSize) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        color.setFill()
        UIRectFill(CGRect(x: 0, y: 0, width: size.width, height: size.height))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image ?? UIImage()
    }
    
    
}
