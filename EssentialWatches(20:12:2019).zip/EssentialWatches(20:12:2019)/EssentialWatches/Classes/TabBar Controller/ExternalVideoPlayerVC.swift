//
//  ExternalVideoPlayerVC.swift
//  EssentialWatches
//
//  Created by Bhavesh on 04/12/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import UIKit
import AVKit
import XCDYouTubeKit

class ExternalVideoPlayerVC: BaseViewController {
    
    var videoURL = String()
    var videoName = String()
    var player = AVPlayer()
    var videoPlayerExt = VideoPlayer()
    
    @IBOutlet var playerView: UIView!
    @IBOutlet var screenTopView: NSLayoutConstraint!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setLayout()
     
    }
    
    func setLayout(){
        
//        let url = URL(string: self.videoURL)
//
////        self.playerView.addSubview(self.player.view)
//
//        self.player = AVPlayer(url: url!)
//        self.player.play()
//
        self.viewHeader.buttonLogo.isHidden = true
        self.viewHeader.labelTitle.text = videoName
          
        self.screenTopView.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)
        
                let url = URL(string: self.videoURL)
        
        self.videoPlayerExt.showsPlaybackControls = true
        self.videoPlayerExt.player = AVPlayer(url: url!)

        self.playerView.addSubview(self.videoPlayerExt.view)

        self.videoPlayerExt.view.frame = self.playerView.frame

        self.videoPlayerExt.player?.play()
        
        
//        let url = URL(string: self.videoURL)
//        let player = AVPlayer(url: url!)
//
//        let playerFrame = self.playerView.frame
//        let videoPlayerView = VideoPlayerView(frame: playerFrame)
//        videoPlayerView.player = player
//        self.playerView.addSubview(videoPlayerView)

//        player.play()
        
        
    }

}


//class VideoPlayerView: UIView {
//    var player: AVPlayer? {
//        get {
//            return playerLayer.player
//        }
//
//        set {
//            playerLayer.player = newValue
//        }
//    }
//
//    var playerLayer: AVPlayerLayer {
//        return layer as! AVPlayerLayer
//    }
//
//    override class var layerClass: AnyClass {
//        return AVPlayerLayer.self
//    }
//}


class VideoPlayer: AVPlayerViewController {
    
      var videoURL = String()
      var videoName = String()
//    var isYoutubeVideo = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        if self.isYoutubeVideo == false{
            let url = URL(string: self.videoURL)
            
            self.player = AVPlayer(url: url!)
            self.player!.play()
//        }else{
            
//            XCDYouTubeClient.default().
            
            
//            XCDYouTubeClient.default().getVideoWithIdentifier(self.videoURL) { (video, error) in
//
////                if ((video) != nil){
//                    let vid = video?.streamURLs[XCDYouTubeVideoQuality.medium360]!.youtubeVideoId()
//
//                    let vidURl = URL(string: vid!)
//                    self.player = AVPlayer(url: vidURl!)
//                    self.player!.play()
//                    /*
//                     NSURL *streamURL = streamURLs[XCDYouTubeVideoQualityHTTPLiveStreaming] ?: streamURLs[@(XCDYouTubeVideoQualityHD720)] ?: streamURLs[@(XCDYouTubeVideoQualityMedium360)] ?: streamURLs[@(XCDYouTubeVideoQualitySmall240)];
//                            weakPlayerViewController.player = [AVPlayer playerWithURL:streamURL];
//                            [weakPlayerViewController.player play];
//                     */
//
//
////                }else{
////
////                }
//
//            }
        }
        
        
    }
    



extension URL {

    func youtubeVideoId( ) -> String? {

    let pattern = #"(?<=(youtu\.be\/)|(v=)).+?(?=\?|\&|$)"#
    let testString = absoluteString

    if let matchRange = testString.range(of: pattern, options: .regularExpression) {
        let subStr = testString[matchRange]
        return String(subStr)
    } else {
        return .none
    }
} }
