//
//  BrandsViewController.swift
//  EssentialWatches
//
//  Created by Bhavesh on 30/11/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import UIKit
import Alamofire
import Firebase
import ZVProgressHUD

class BrandViewController: BaseViewController,UITextFieldDelegate,UIScrollViewDelegate {

    @IBOutlet var brandTblView: UITableView!
    @IBOutlet var screenViewTop: NSLayoutConstraint!
    
    
    var isFromHome = false
    var nPageCount = 9
    var arrBrandlistArray = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setLayout()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //Bhavesh 2-Dec
        self.tabBarController?.tabBar.isHidden = false
        self.tabBarController?.tabBar.layer.zPosition = -0
        //``````````````````
    }
    
    
    //Class Layout
    func setLayout(){
        self.brandTblView.delegate = self
        self.brandTblView.dataSource = self
        
        
            if !self.isFromHome {
                self.setIsRequiedMenuYes()
            }
          
          self.getBrands()
          
          let refreshControl: UIRefreshControl = {
              let refreshControl = UIRefreshControl()
              refreshControl.addTarget(self, action:
                  #selector(BrandsViewController.handleRefresh(_:)),
                                       for: UIControl.Event.valueChanged)
              refreshControl.tintColor = UIColor.clear
              return refreshControl
          }()
          self.brandTblView.addSubview(refreshControl)
          
          
            //Bhavesh 30-Nov'2019``````````
            self.viewHeader.buttonLogo.isHidden = true
            self.setIsRequiedMenuYes()
            self.viewHeader.labelTitle.text = "Brands"
        
            self.screenViewTop.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)
            //``````````````
          }
    
    //MARK:- Custom Access Methods
    
    func getBrands()
    {
                   
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
                    self.progressShow(true)
            }
            let dict1 = [KConstant.kMethod : "brand_list.php","start":String(nPageCount-9),"end":String(nPageCount)]
            ServerRequest.sendBrandRequestForBrandList(dictParam: dict1) { (response, isSuccess) in
                if isSuccess {
                    
                    self.arrBrandlistArray.addObjects(from: response as! Array<BrandList>)
//                    KConstant.APP.arrBrandList = response as! Array<BrandList>
                    self.brandTblView.reloadData()
                }else{
                    print("failure\(response)")
                }
                    self.progressShow(false)
            }
    }
    
    
    //Click Events
     func handleRefresh(_ refreshControl: UIRefreshControl)
      {
          nPageCount = 10
          self.arrBrandlistArray.removeAllObjects()
          let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
          if !(reachabilityManager?.isReachable)!
          {
              self.displayAlertForNoIntenret()
              return
          }
//           self.progressShow(true) //ProgressHUD.show()
        self.getBrands()
          
          brandTblView.reloadData()
          refreshControl.endRefreshing()
      }

    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
            // then we are at the top
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
                // self.progressShow(true) //ProgressHUD.show()
            nPageCount = nPageCount + 10
            self.getBrands()
        }
        
//        if (scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height {
//            self.brandTblView.tableFooterView?.isHidden = true
//              // call method to add data to tableView
//          }
    }
    
    
}

extension BrandViewController: UITableViewDelegate,UITableViewDataSource{
    
//     func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
//        let lastSectionIndex = tableView.numberOfSections - 1
//        let lastRowIndex = tableView.numberOfRows(inSection: lastSectionIndex) - 1
//        if indexPath.section ==  lastSectionIndex && indexPath.row == lastRowIndex {
//           // print("this is the last cell")
//            let spinner = UIView()
//            let imgView = UIImageView(frame: CGRect(x: ((tableView.bounds.width / 2)-15), y: 0, width: 30, height: 30))
//             let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
//               imgView.image = gifImage
//            imgView.contentMode = .scaleAspectFit
//            spinner.addSubview(imgView)
////            spinner.startAnimating()
//            spinner.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: tableView.bounds.width, height: CGFloat(40))
//
//            self.brandTblView.tableFooterView = spinner
//            self.brandTblView.tableFooterView!.isHidden = false
//        }
//    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
      
        let objBrand : BrandList = self.arrBrandlistArray[indexPath.item] as! BrandList
            let dict = ["object":objBrand,"nFlag":"0"] as [String : Any]
            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ModelsViewController") as! ModelsViewController
            objModelsViewController.dictOption = dict as [String : AnyObject]
            objModelsViewController.isFromHome =  true
//        objModelsViewController.isFromBrandTab = true
            self.navigationController?.pushViewController(objModelsViewController, animated: true)

        }
    

    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20.0
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 30))
         headerView.backgroundColor = UIColor.init(red: 242, green: 242, blue: 242, alpha: 1)
        let lblTitle = UILabel(frame: CGRect(x: 10, y: 0, width: 150, height: 15))
        lblTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 15)
        lblTitle.backgroundColor = UIColor.init(red: 242, green: 242, blue: 242, alpha: 1)
        lblTitle.text = "List of Brands:"
        lblTitle.textColor = .black
        headerView.addSubview(lblTitle)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.00
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return self.arrBrandlistArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BrandCell") as! BrandWatchesTblCell
    
        let objBrand : BrandList = self.arrBrandlistArray[indexPath.item] as! BrandList
            cell.lblWatchBrandName.text = objBrand.BrandName
            let url = URL(string: objBrand.BrandImage)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            cell.imgViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            cell.lblBrandItemCount.text = objBrand.ItemCount
        
            return cell
    }
    
    
    
    
}

class BrandWatchesTblCell: UITableViewCell {
    
    @IBOutlet var imgViewWatch: UIImageView!
    @IBOutlet var lblWatchBrandName: UILabel!
    @IBOutlet var lblBrandItemCount: UILabel!
    @IBOutlet var bgAlphaView: UIView!
    @IBOutlet var bgBorderView: UIView!
    
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        self.bgAlphaView.backgroundColor = KConstant.kColorThemeYellow
        self.bgAlphaView.alpha = 0.85
        
        lblWatchBrandName.font = UIFont(name: KConstant.kFontOpenSenseBold, size: 15)
        lblBrandItemCount.font = UIFont(name: KConstant.kFontOpenSenseRegular, size: 10)
        
        lblWatchBrandName.textColor = .white
        lblWatchBrandName.textColor = .white
        
        self.bgBorderView.layer.borderWidth = 1
        self.bgBorderView.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    
}


extension UIViewController{
        
    static var imgViewLoader = UIImageView()
    static var viewBackGround = UIView()
    
    func progressShow(_ show: Bool){
        
        if show{           
            
            UIViewController.viewBackGround.removeFromSuperview()
            UIViewController.imgViewLoader = UIImageView(frame: CGRect(x: (UIScreen.main.bounds.width / 2) - 15, y: (UIScreen.main.bounds.height / 2) - 20, width: 40, height: 40))
            
              UIViewController.viewBackGround = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
            
            UIViewController.viewBackGround.backgroundColor = UIColor.black.withAlphaComponent(0.1)
            
            let gifImage = UIImage.gif(name: "funny1")
            
            UIViewController.imgViewLoader.image = gifImage
            UIViewController.imgViewLoader.contentMode = .scaleAspectFit
            UIViewController.viewBackGround.addSubview(UIViewController.imgViewLoader)
            self.view.addSubview(UIViewController.viewBackGround)
        }else{
            UIViewController.viewBackGround.removeFromSuperview()
        }
        
        
    }
    
}
