//
//  NewArrivalViewController.swift
//  EssentialWatches
//
//  Created by Bhavesh on 30/11/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import UIKit
import Alamofire
import ZVProgressHUD
import Firebase

class NewArrivalViewController: BaseViewController {

    @IBOutlet var tblNewArrival: UITableView!
    @IBOutlet var screenViewTop: NSLayoutConstraint!
    
    
    var arrLatestWatches =  NSMutableArray ()
      var arrFeaturedWatches =  NSMutableArray ()
      
      var nPageCountLatest = 9
      var nPageCountFeature = 12

      var strItemID : String = ""
      var refreshControlLatest = UIRefreshControl()
      var nFlag = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setLayout()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //Bhavesh 2-Dec
        self.tabBarController?.tabBar.isHidden = false
        self.tabBarController?.tabBar.layer.zPosition = -0
        //``````````````
    }
    
    
    func setLayout(){
        
        self.tblNewArrival.delegate = self
        self.tblNewArrival.dataSource = self
        self.nFlag = 1
        
        
        getLatestWatches()
        
        
         let refreshControl: UIRefreshControl = {
                   let refreshControl = UIRefreshControl()
                   refreshControl.addTarget(self, action:
                       #selector(NewArrivalViewController.handleRefresh(_:)),
                                            for: UIControl.Event.valueChanged)
                   refreshControl.tintColor = UIColor.clear
                   return refreshControl
               }()
               self.tblNewArrival.addSubview(refreshControl)
        
    
        //Bhavesh 30-Nov'2019``````````
        self.viewHeader.buttonLogo.isHidden = true
        self.setIsRequiedMenuYes()
        self.viewHeader.labelTitle.text = "New Arrivals"
    
        self.screenViewTop.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)
        //``````````````

    }
    
    
    
    
  //Click Events
        @objc func handleRefresh(_ refreshControl: UIRefreshControl)
        {
              nPageCountLatest = 10
              self.arrLatestWatches.removeAllObjects()
              let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
              if !(reachabilityManager?.isReachable)!
              {
                  self.displayAlertForNoIntenret()
                  return
              }
    //           self.progressShow(true) //ProgressHUD.show()
            self.getLatestWatches()
              
            self.tblNewArrival.reloadData()
              refreshControl.endRefreshing()
      }

        func scrollViewDidScroll(_ scrollView: UIScrollView)
        {
            let scrollViewHeight: Float = Float(scrollView.frame.size.height)
            let scrollContentSizeHeight = Float(scrollView.contentSize.height)
            let scrollOffset: Float = Float(scrollView.contentOffset.y)
            
            if scrollOffset == 0 {
                // then we are at the top
            }
            else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
            {
                    // self.progressShow(true) //ProgressHUD.show()
                nPageCountLatest = nPageCountLatest + 10
                self.getLatestWatches()
            }
        }
    
    func getLatestWatches()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }

        self.progressShow(true)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
                       
        let dictParams = [KConstant.kMethod :  "latestwatches_detail.php","deviceid":uniqueIdentifier, "start":String(nPageCountLatest-9),"end":String(nPageCountLatest)]

        ServerRequest.sendServerRequestWithDictForAllLatestWatches(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess
            {
                self.arrLatestWatches.addObjects(from:  response as! Array<LatestWatch>)
                self.tblNewArrival.reloadData()
//                print("Suuccess\(self.arrLatestWatches)")
            }else{
                print("failure\(response)")
            }
//            self.progressShow(false) // ProgressHUD.dismiss()

            self.progressShow(false)
        }
    }
        
        // ------------------------------------------------------------------------------------------------------------------
        
        func getFeaturedWatches()
        {
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }
            
            let dictParams = [KConstant.kMethod :  "featuredwatches_detail.php","start":String(nPageCountFeature-11),"end":String(nPageCountFeature)]
            ServerRequest.sendServerRequestWithDictForAllFeaturedWatches(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess {
                    self.arrFeaturedWatches.addObjects(from:  response as! Array<FeaturedWatch>)
                    self.tblNewArrival.reloadData()
                }else{
                    print("failure\(response)")
                }
//                self.progressShow(false) // ProgressHUD.dismiss()

                self.progressShow(false)
            }
        }
    
    //Bhavesh 2-Dec
    @objc func buttonLikeDislikeClicked(_ sender: UIButton!){
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
//            sender.isSelected = !sender.isSelected
//             self.progressShow(true) //ProgressHUD.show()

            self.progressShow(true)
            if sender.isSelected {
                self.getadd_remove_wish_list(strStatus: "N",dictDetail: dictTemp!, sender: sender)
            }else{
                self.getadd_remove_wish_list(strStatus: "Y",dictDetail: dictTemp!, sender: sender)
            }
        }else{
            NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "callAddRemoveWishlist"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(getProductInfo), name: NSNotification.Name(rawValue: "callAddRemoveWishlist"), object: nil)
            let objMyInfoVC : MyInfoViewController  = self.storyboard?.instantiateViewController(withIdentifier: "MyInfoViewController") as! MyInfoViewController
            objMyInfoVC.isWishlist = true
            if sender.isSelected {
                objMyInfoVC.wishStatus = "N"
            }else{
                objMyInfoVC.wishStatus = "Y"
            }
            objMyInfoVC.strItemId  = strItemID as NSString
            self.navigationController?.pushViewController(objMyInfoVC, animated: true)
        }
    }
    
    //MARK:- APi Call
    
    
    func getadd_remove_wish_list(strStatus: String,dictDetail: NSDictionary, sender: UIButton)
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        
         var objLatestWatch : LatestWatch = self.arrLatestWatches[sender.tag] as! LatestWatch
        
        let dictParams = ["itemid": objLatestWatch.Product.ItemID, "deviceid":uniqueIdentifier,"wish":strStatus,"firstname":dictDetail.value(forKey: KConstant.kFirstName),"lastname":dictDetail.value(forKey: KConstant.kLastName),"email":dictDetail.value(forKey: KConstant.kEmail),"phone":dictDetail.value(forKey: KConstant.kMobileNum)]
        
        ServerRequest.sendServerRequestforGetMethod(dictParam: dictParams as! Dictionary<String, String> , APIName: "add_remove_wish_list.php") { (response, isSuccess) in
            if isSuccess
            {
                let dict : NSDictionary = response as! NSDictionary
                
                if dict["result"] as! Int == 1{
                    sender.isSelected = !sender.isSelected
                    objLatestWatch.is_wish_listed = !objLatestWatch.is_wish_listed
                    if strStatus == "Y"{
                        objLatestWatch.is_wish_listed = true
//                        sender.isSelected = true //setImage(UIImage(named:"fav_Selected"), for: .selected)
                    }else if strStatus == "N"{
                        objLatestWatch.is_wish_listed = false
//                        sender.isSelected = false //setImage(UIImage(named: "fav_Unselected"), for: .normal)
                    }
                    
                    (self.arrLatestWatches[sender.tag]) = objLatestWatch
                    
                    self.tblNewArrival.reloadRows(at: [IndexPath.init(row: sender.tag, section: 0)], with: .top)
                }else{
                    self.displayAlertWithCompletion(message:dict["message"]  as! String, completion: {
                    })
                }
//                self.progressShow(false) // ProgressHUD.dismiss()

                self.progressShow(false)
                
            }else{
//                self.progressShow(false) // ProgressHUD.dismiss()

                self.progressShow(false)
            }
        }
    }
    
    @objc func getProductInfo()
        {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
            let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
            var strEmail = ""
            if (dictTemp != nil) {
                strEmail = (dictTemp?.value(forKey:KConstant.kEmail) as? String)!
            }
            let dictParams = [KConstant.kMethod : "watch_detail.php","email": strEmail,"itemid":strItemID,"deviceid":uniqueIdentifier]
    print(dictParams)
            ServerRequest.sendServerRequestWithDictForProductInfo(dictParam: dictParams) { (response, isSuccess) in
               
                print(response)
                if isSuccess
                {
                    
                    
                    
                }else{
//                    self.progressShow(false) // ProgressHUD.dismiss()

                    self.progressShow(false)
                }
            }
        }

}


extension NewArrivalViewController: UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20.00
     }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 20))
        headerView.backgroundColor = UIColor.init(red: 242, green: 242, blue: 242, alpha: 1)
        let lblTitle = UILabel(frame: CGRect(x: 10, y: 0, width: 150, height: 15))
        lblTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 15)
        lblTitle.backgroundColor = UIColor.init(red: 242, green: 242, blue: 242, alpha: 1)
        lblTitle.text = "New Arrivals:"
        lblTitle.textColor = .black
        headerView.addSubview(lblTitle)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 220.00
    }
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 250.00
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nFlag == 1 {
            return self.arrLatestWatches.count
        }else{
            return self.arrFeaturedWatches.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewArrivesCell") as! NewArrivesTblCell
//                collectionView.dequeueReusableCell(withReuseIdentifier: "BrandsCell", for: indexPath) as! BrandsCell
            
            if nFlag == 1 { // Latest
                let objLatestWatch : LatestWatch = self.arrLatestWatches[indexPath.item] as! LatestWatch
                let objProduct : LatestWatchProduct = objLatestWatch.Product
                cell.lblProductBrand.text = objLatestWatch.BrandName
                cell.lblProductDescription.text = objProduct.Name
                cell.lblPrice.text =  objLatestWatch.WirePrice
                
                //  if (self.objSearch?.wishlisted!) == "0" {
                if objLatestWatch.is_wish_listed{
                    cell.btnLike.isSelected = true
                }else{
                    cell.btnLike.isSelected = false
                }
                
                cell.btnLike.setImage(UIImage(named: "fav_Unselected"), for: .normal)
                cell.btnLike.setImage(UIImage(named:"fav_Selected"), for: .selected)
                cell.btnLike.tag = indexPath.row
                cell.btnLike.addTarget(self, action: #selector(self.buttonLikeDislikeClicked(_:)), for: .touchUpInside)
                let url = URL(string: objProduct.Image)!
                
                cell.lblRegisteredNum.text = "Ref. No: \(objLatestWatch.ModelNumber)"
                
                let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
    //            cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
                cell.imgViewProductImage.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            }
            else
            { // Featured
                let objFeatureWatch : FeaturedWatch = self.arrFeaturedWatches[indexPath.item] as! FeaturedWatch
                cell.lblProductBrand.text = objFeatureWatch.BrandName
                cell.lblProductDescription.text = objFeatureWatch.ModelName
                cell.lblPrice.text = objFeatureWatch.WirePrice
                let url = URL(string: objFeatureWatch.ModelImage)!
                let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
    //         cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)

                cell.imgViewProductImage.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
                cell.imgViewProductImage.contentMode = .scaleAspectFill
                cell.imgViewProductImage.clipsToBounds = true
            }
            
//            if KConstant.IS_IPHONE_6 || KConstant.IS_IPHONE_6P{
//                cell.layoutImageViewHeight.constant = 100
//            }
            
//            self.setAdjustableLabel(label:  cell.labelWirePrice)
            return cell
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
            if nFlag == 1 { // Latest
                let objLatestWatch : LatestWatch = self.arrLatestWatches[indexPath.item] as! LatestWatch
    //            objProductDetailsViewController.objLatestWatch = objLatestWatch
    //            objProductDetailsViewController.strOptionFromLatestOrFeature = "latest"
                objProductDetailsViewController.strItemID = objLatestWatch.Product.ItemID
       //         objProductDetailsViewController.strCategoryName = objLatestWatch.CategoryName
            }else{
                let objFeatureWatch : FeaturedWatch = self.arrFeaturedWatches[indexPath.item] as! FeaturedWatch
    //            objProductDetailsViewController.objFeaturedWatch = objFeatureWatch
    //            objProductDetailsViewController.strTitle = objFeatureWatch.Product.Name
    //            objProductDetailsViewController.strCategoryName = objFeatureWatch.CategoryName
    //            objProductDetailsViewController.strOptionFromLatestOrFeature = "feature"
                objProductDetailsViewController.strItemID = objFeatureWatch.Product.ItemID
            }
            
            objProductDetailsViewController.isRequiedCubeAnimation = false
            self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
        }
    
    
}


class NewArrivesTblCell: UITableViewCell{
    
    @IBOutlet var btnLike: UIButton!
    @IBOutlet var imgViewProductImage: UIImageView!
    @IBOutlet var lblProductBrand: UILabel!
    @IBOutlet var lblProductDescription: UILabel!
    @IBOutlet var lblRegisteredNum: UILabel!
    @IBOutlet var lblPrice: UILabel!
    @IBOutlet var bgAlphaView: UIView!
    @IBOutlet var bgBorderView: UIView!
    
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        self.bgAlphaView.backgroundColor = KConstant.kColorThemeYellow
        self.bgAlphaView.alpha = 0.85
        
        lblProductBrand.font = UIFont(name: KConstant.kFontOpenSenseBold, size: 14)
        lblPrice.font = UIFont(name: KConstant.kFontOpenSenseBold, size: 14)
        lblProductDescription.font = UIFont(name: KConstant.kFontOpenSenseRegular, size: 10)
        lblRegisteredNum.font = UIFont(name: KConstant.kFontOpenSenseItalic, size: 9)
        
        
        lblRegisteredNum.textColor = .black
        lblPrice.textColor = .white
        lblProductDescription.textColor = .white
        lblProductBrand.textColor = .white
        
        self.bgBorderView.layer.borderWidth = 1
        self.bgBorderView.layer.borderColor = UIColor.lightGray.cgColor
    }
    
}
