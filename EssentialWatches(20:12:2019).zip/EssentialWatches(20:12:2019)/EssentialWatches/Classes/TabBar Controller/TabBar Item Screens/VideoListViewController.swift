//
//  VideoListViewController.swift
//  EssentialWatches
//
//  Created by Bhavesh on 30/11/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import UIKit
import AVKit
import Alamofire
import ZVProgressHUD
import Firebase
import AVFoundation

class VideoListViewController: BaseViewController {
    
    //MARK:- Variables
    var arrVideos = NSMutableArray()
    var nPageCount = 10
    
    
    //MARK:- Outlets
    @IBOutlet var tblVideoList: UITableView!
    @IBOutlet var screenViewTop: NSLayoutConstraint!
    
    var TempImage:UIImageView?
    
    //MARK:- Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.getWatchVideoList()
        
        self.setLayout()
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        self.tabBarController?.tabBar.layer.zPosition = -0
        self.getWatchVideoList()
    }
    
    //Class Layout
    func setLayout(){
        self.tblVideoList.delegate = self
        self.tblVideoList.dataSource = self
        
        self.setIsRequiedMenuYes()
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
//         self.progressShow(true) //ProgressHUD.show()
        
        self.progressShow(true)
        self.viewHeader.buttonLogo.isHidden = true
        self.setIsRequiedMenuYes()
        self.viewHeader.labelTitle.text = "Videos"
        self.screenViewTop.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)
        //``````````````
    }
    
    
    
    func handleRefresh(_ refreshControl: UIRefreshControl)
    {
        nPageCount = 10
        self.arrVideos.removeAllObjects()
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        self.progressShow(true)
        self.getWatchVideoList()
        tblVideoList.reloadData()
    }
    func getWatchVideoList()
    {
        //https://essential-watches.com/API/V2/watch_videos.php
        let dictParams = [KConstant.kMethod :  "watch_videos.php","start":String(nPageCount-10),"end":String(nPageCount)]
        
        ServerRequest.sendeServerRequestForVideos(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess {

                self.arrVideos.addObjects(from: response as! Array<WatchVideoList>)
                self.tblVideoList.reloadData()
            }else{
                print("failure\(response)")
            }
            self.progressShow(false)
        }
    }
    
    //MARK:- CLick Events
    
    @objc func btnPlayVideoClicked(_ sender: UIButton){

        let objWatchVideoList : WatchVideoList = self.arrVideos[sender.tag] as! WatchVideoList
         let objWebViewController = self.storyboard?.instantiateViewController(withIdentifier:"VideoPlayer") as! VideoPlayer
        objWebViewController.videoURL = objWatchVideoList.video_url
        objWebViewController.videoName = objWatchVideoList.video_name
        self.navigationController?.present(objWebViewController, animated: true, completion: nil)
    }
    
    
    func generateThumbnail(url: URL) -> UIImage? {
        do {
            let asset = AVURLAsset(url: url)
            let imageGenerator = AVAssetImageGenerator(asset: asset)
            imageGenerator.appliesPreferredTrackTransform = true
            let cgImage = try imageGenerator.copyCGImage(at: .zero, actualTime: nil)
            
            return UIImage(cgImage: cgImage)
        } catch {
            print(error.localizedDescription)
            
            return nil
        }
    }
    
}
extension VideoListViewController: UITableViewDataSource, UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20.00
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 30))
        headerView.backgroundColor = UIColor.init(red: 242, green: 242, blue: 242, alpha: 1)
        let lblTitle = UILabel(frame: CGRect(x: 10, y: 0, width: 150, height: 15))
        lblTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 15)
        lblTitle.backgroundColor = UIColor.init(red: 242, green: 242, blue: 242, alpha: 1)
        lblTitle.text = "List of Videos:"
        lblTitle.textColor = .black
        headerView.addSubview(lblTitle)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.00
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.arrVideos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        let cell = tableView.dequeueReusableCell(withIdentifier: "VideoCell") as! VideoListTblViewCell
        cell.btnPlayVideo.tag = indexPath.row
        cell.btnPlayVideo.addTarget(self, action: #selector(btnPlayVideoClicked(_:)), for: .touchUpInside)
        
        let objWatchVideoList = self.arrVideos[indexPath.item] as! WatchVideoList
        let url = URL(string: objWatchVideoList.video_url)
      
        let thumbImage = generateThumbnail(url: url!)
        if let thumbImg = thumbImage{
          cell.imgProductVideoThumb.image = thumbImg
        }
        else{
            cell.imgProductVideoThumb.image = UIImage(named: "temp.png")!
        }
    
//        let placeholderImage = UIImage(named: "temp.png")!
//               cell.imgProductVideoThumb.kf.setImage(with: generateThumbnail(url: url!) as? Resource, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
               
        return cell
    }
  
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let objWatchVideoList : WatchVideoList = self.arrVideos[indexPath.item] as! WatchVideoList
        let objWebViewController = self.storyboard?.instantiateViewController(withIdentifier: "ExternalVideoPlayerVC") as! ExternalVideoPlayerVC
        //        objWebViewController.tabBarController?.tabBar.isHidden = true
        //        objWebViewController.tabBarController?.tabBar.layer.zPosition = -1
        //                objWebViewController.strOption = "Video"
        //                objWebViewController.strTitle =  objWatchVideoList.video_name
        //                objWebViewController.isVideo = true
        objWebViewController.videoURL = objWatchVideoList.video_url
        self.navigationController?.pushViewController(objWebViewController, animated: true)
    }
}

class VideoListTblViewCell: UITableViewCell
{
    @IBOutlet var imgProductVideoThumb: UIImageView!
    @IBOutlet var btnPlayVideo: UIButton!
    override func draw(_ rect: CGRect) {
        super.draw(rect)
    }
}
