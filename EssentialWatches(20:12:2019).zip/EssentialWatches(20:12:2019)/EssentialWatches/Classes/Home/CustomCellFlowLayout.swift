//
//  CustomCellFlowLayout.swift
//  CollectionView_Demo
//
//  Created by msp on 07/09/17.
//  Copyright © 2017 msp. All rights reserved.
//

import UIKit

class CustomCellFlowLayout: UICollectionViewFlowLayout
{
    override init() {
        super.init()
      SetupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
        SetupLayout()
        fatalError("init(coder:) has not been implemented")
    }
    
//    override var itemSize: CGSize{
//        set {
//            
//        }
//        get {
////            let numberOfColumns: CGFloat = 3
////            let itemWidth = (self.collectionView!.frame.width - (numberOfColumns - 1)) / numberOfColumns
////            return CGSize(width: itemWidth-10, height: 230)
//        }
//    }
    func SetupLayout() -> Void {
        scrollDirection = .vertical
    }
}
