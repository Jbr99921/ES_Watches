//
//  HeaderView.swift
//  CollectionView_Demo
//
//  Created by msp on 07/09/17.
//  Copyright © 2017 msp. All rights reserved.
//

import UIKit

class CollectionViewHeaderView: UICollectionReusableView {
    @IBOutlet var labelTitle: UILabel!
    @IBOutlet var buttonShowAll: UIButton!
    
    @IBOutlet var labelselectAll: UILabel!
    @IBOutlet var imageArrow: UIImageView!
    
    
    
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
