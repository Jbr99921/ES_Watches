//
//  HomeTableViewCell.swift
//  EssentialWatches
//
//  Created by Vikram on 12/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

protocol HomeCellDelegate {
    func reloadPopulerBrands()
    func reloadLatestWatches()
}

class HomeTableViewCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate,UIScrollViewDelegate,UICollectionViewDelegateFlowLayout
{
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var buttonViewMore: UIButton!
    
    @IBOutlet weak var collectionViewHome: UICollectionView?
    
    var arrData = Array<Brand>()
    var arrLatestWatches = Array<LatestWatch>()
    var arrFeaturedWatches = Array<FeaturedWatch>()
    var nFlag:Int = 0
    var nRequiredLoader:Int = 1
    var nRequiredLoaderLatest:Int = 1

    var delegate : HomeCellDelegate?
    
    @IBOutlet weak var layoutConstraintTableViewLeadingSpace: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintTableViewTrailingSpace: NSLayoutConstraint!

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - CollectionView Array Methods
    // ------------------------------------------------------------------------------------------------------------------

    func setCollectionData(_ collectionData: Array<Brand>, withIndex nIndex: Int, isRequiredLoader : Int)
    {
        if KConstant.IS_IPHONE5 {
            self.collectionViewHome?.register(UINib(nibName: "HomeProductCollectionViewCell5", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        }else{
            self.collectionViewHome?.register(UINib(nibName: "HomeProductCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        }
        arrData = collectionData
        nFlag = 0
        nRequiredLoader = isRequiredLoader
        self.collectionViewHome?.tag = 0
      

        
        self.collectionViewHome?.reloadData()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func setCollectionDataForLatestWatches(_ collectionData: Array<LatestWatch>, withIndex nIndex: Int, isForLatest:Bool, isRequiredLoaderLatest : Int)
    {
        if KConstant.IS_IPHONE5 {
            self.collectionViewHome?.register(UINib(nibName: "LatestWatchCollectionViewCell5", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        }else{
            self.collectionViewHome?.register(UINib(nibName: "LatestWatchCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        }
        
        nRequiredLoaderLatest = isRequiredLoaderLatest
        arrLatestWatches = collectionData
        nFlag = 1
        self.collectionViewHome?.tag = 1
        self.collectionViewHome?.reloadData()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func setCollectionDataForFeatureWatches(_ collectionData: Array<FeaturedWatch>, withIndex nIndex: Int, isForLatest:Bool)
    {
        if KConstant.IS_IPHONE5 {
            self.collectionViewHome?.register(UINib(nibName: "LatestWatchCollectionViewCell5", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        }else{
            self.collectionViewHome?.register(UINib(nibName: "LatestWatchCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        }

        arrFeaturedWatches = collectionData
         nFlag = 2
        self.collectionViewHome?.tag = 2
        self.collectionViewHome?.reloadData()
    }
    
    
    // MARK: - UICollectionViewDataSource methods
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView.tag == 0 {
            return self.arrData.count
        }else if collectionView.tag == 1 {
            return self.arrLatestWatches.count
        }else{
            return self.arrFeaturedWatches.count
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
       

        if  KConstant.IS_IPHONE5 {
            return CGSize(width: 94, height: self.frame.size.height - 10)
        }else  if  KConstant.IS_IPHONE_6 {
            return CGSize(width: 113, height: self.frame.size.height)
        }else{
            return CGSize(width: 126, height: self.frame.size.height)
        }
    }
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize
//    {
//
//    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
         if ((self.collectionViewHome?.tag) == 0)
        {
            let cell: HomeProductCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeProductCollectionViewCell", for: indexPath as IndexPath) as! HomeProductCollectionViewCell
            let objBrand : Brand = self.arrData[indexPath.item] as Brand
            cell.labelProduct.text = objBrand.BrandName
            
            //cell.labelProduct.text = self.arrPopularBrands
            if indexPath.section == 0 {
                cell.labelProduct.textAlignment = .center
            }else{
                cell.labelProduct.textAlignment = .left
            }
            
            cell.labelProduct.isHidden = false
            cell.labelProduct.text?.uppercased()
            let url = URL(string: objBrand.BrandImage)!
            let placeholderImage = UIImage(named: "temp.png")!
//         cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
            
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

            cell.layoutConstrainViewBackgroundHeight.constant = 195
            cell.viewBackground .layer.borderColor = UIColor.lightGray.cgColor
            cell.viewBackground .layer.borderWidth = 1.0
            
            return cell
        }
        else
        {
            let cell: HomeProductCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeProductCollectionViewCell", for: indexPath as IndexPath) as! HomeProductCollectionViewCell
            
            
            if ((self.collectionViewHome?.tag) == 1) {

                let objLatestWatch : LatestWatch = self.arrLatestWatches[indexPath.item] as LatestWatch
                
                cell.labelProduct.text = objLatestWatch.BrandName
                cell.labelWatchInfo.text = objLatestWatch.ModelName
                cell.labelWirePrice.text = "Wire Price :" + objLatestWatch.WirePrice
                cell.labelWirePrice.textColor = UIColor.red
                let url = URL(string: objLatestWatch.ModelImage)!
                let placeholderImage = UIImage(named: "temp.png")!
                //cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
                cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            }
            else
            {
                var  arrTemp = Array<FeaturedWatch>()
                arrTemp = self.arrFeaturedWatches
                
                let objFeaturedWatch : FeaturedWatch = arrTemp[indexPath.item] as FeaturedWatch
                cell.labelProduct.text = objFeaturedWatch.BrandName
                cell.labelWatchInfo.text = objFeaturedWatch.ModelName
                cell.labelWirePrice.text = "Wire Price :" + objFeaturedWatch.WirePrice

                let url = URL(string: objFeaturedWatch.ModelImage)!
                let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
                cell.imageViewProduct.contentMode = .scaleAspectFill
//             cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)

                cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

            }
            
            cell.viewBackground .layer.borderColor = UIColor.lightGray.cgColor
            cell.viewBackground .layer.borderWidth = 1.0
            
             cell.labelWirePrice.numberOfLines = 0
             cell.labelWirePrice.adjustsFontSizeToFitWidth = true

            
            cell.layoutConstrainViewBackgroundHeight.constant = 258
            cell.labelProduct.isHidden = false
            cell.labelWatchInfo.isHidden = false
            cell.labelWirePrice.isHidden = false
            return cell
        }
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView
    {
        
        let view1 = UICollectionReusableView()

        switch kind
        {
        case UICollectionView.elementKindSectionHeader:
            assert(false, "Unexpected element kind")
        case UICollectionView.elementKindSectionFooter:
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView", for: indexPath as IndexPath) as! GIFImageCollectionFooterView
            let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
            view.imageViewGIF.image = gifImage
            return view
        default:
            assert(false, "Unexpected element kind")
        }
        
        return view1

    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
    
        if ((self.collectionViewHome?.tag) == 0)
        {
            if nRequiredLoader == 0 || self.arrData.count == 0{
                return CGSize(width: 0, height: 0)
            }
        }else if ((self.collectionViewHome?.tag) == 1) {
            if nRequiredLoaderLatest == 0 || self.arrLatestWatches.count == 0{
                return CGSize(width: 0, height: 0)
            }
        }

        
        if collectionView == self.collectionViewHome{
            return CGSize(width: 60.0, height: collectionView.frame.size.height)
        }
        return CGSize(width: 0, height: 0)
    }

    // ------------------------------------------------------------------------------------------------------------------

    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if ((self.collectionViewHome?.tag) == 0)
        {
            let objBrand : Brand = self.arrData[indexPath.item] as Brand
            let dict = ["object":objBrand,"nFlag":"0"] as [String : Any]
            NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "HomeCellClickNotification"), object: dict)
        }
        else
        {
            if ((self.collectionViewHome?.tag) == 1) {
                let objLatestWatch = self.arrLatestWatches[indexPath.item] as  LatestWatch
                let dict = ["object":objLatestWatch,"nFlag":"1"] as [String : Any]
                NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "HomeCellClickNotification"), object: dict)
            }
            else
            {
                var  arrTemp = Array<FeaturedWatch>()
                arrTemp = self.arrFeaturedWatches
                let objProduct : FeaturedWatch = arrTemp[indexPath.item] as FeaturedWatch
                let dict = ["object":objProduct,"nFlag":"2"] as [String : Any]
                NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "HomeCellClickNotification"), object: dict)
            }
        }
    }

    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        let bottomEdge: Float = Float(scrollView.contentOffset.x + scrollView.frame.size.width)
        if scrollView.contentOffset.x == 0.0 {
            return
        }
        
        if bottomEdge >= Float(scrollView.contentSize.width) {
            if self.collectionViewHome?.tag == 0 {
                delegate?.reloadPopulerBrands()
            }else {
                delegate?.reloadLatestWatches()
            }
        }
    }
    
    
    
}
