//
//  HomeProductCollectionViewCell.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class HomeProductCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageViewProduct: UIImageView!
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var labelProduct: UILabel!
    @IBOutlet weak var labelProductInfo: UILabel!
    
    @IBOutlet weak var labelWatchInfo: UILabel!
    @IBOutlet weak var labelWirePrice: UILabel!
    @IBOutlet weak var viewBackground: UIView!
    
    @IBOutlet weak var layoutConstrainViewBackgroundHeight: NSLayoutConstraint!

        @IBOutlet weak var lblProductName: UILabel!
        @IBOutlet weak var lblPrice: UILabel!
        @IBOutlet weak var lblSpecialPrice: UILabel!
        @IBOutlet weak var lblMiddelPrice: UILabel!
        @IBOutlet weak var imageForBackground: UIImageView!
        @IBOutlet weak var imageviewBackground: UIImageView!
        @IBOutlet weak var layoutConstraint_labelProductHeight: NSLayoutConstraint!
        @IBOutlet weak var layoutConstraint_imageViewTopSpace: NSLayoutConstraint!
        @IBOutlet weak var layoutConstraint_labelSpecialPrice: NSLayoutConstraint!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    
    }
    

}
