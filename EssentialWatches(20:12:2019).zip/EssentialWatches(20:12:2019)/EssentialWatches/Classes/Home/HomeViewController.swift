//
//  HomeViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import AlamofireImage
import Alamofire
import ZVProgressHUD
import PullToMakeFlight
import Firebase

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,UITextFieldDelegate,HomeCellDelegate{
    
    @IBOutlet weak var collectionViewHome: UICollectionView!
    @IBOutlet weak var tableViewHome: UITableView!

    @IBOutlet weak var textFieldSearch: UITextField!
    @IBOutlet weak var viewSearch: UIView!
    @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!

    var collectionViewLayout: CustomCellFlowLayout!
    var screenSize = CGSize()
    var arrPopularBrands =  NSMutableArray ()
    var arrLatestWatches =  NSMutableArray ()
    var arrFeatureWatches = Array<FeaturedWatch>()
    var nPagCount = 10
    var arrMenu = ["SELL YOUR WATCH","GET YOUR WATCH AUTHENTICATED"]
    var arrMenu1 = ["TRADE-IN YOUR WATCH","CERTIFIED APPRIASAL"]
    
    var nPageCount = 9
    var nPageCountRecent = 10

    var isPopularFinished = false
    var isLatestFinished = false
    var nRequiredLoader = 1
    var nRequiredLoaderLatest = 1

    var refreshControl = UIRefreshControl()
    
    var isRefreshAnimating = false
    
// ------------------------------------------------------------------------------------------------------------------
// MARK: - View LifeCycle Methods
// ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        KConstant.APP.objCurrentNavigationController = self.navigationController!
        self.textFieldSearch.delegate = self
        viewSearch.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        viewSearch.layer.borderWidth =  1.0
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")

        if (reachabilityManager?.isReachable)!
        {
            if !KConstant.APP.imgSplash.isDescendant(of:(KConstant.APP.window?.rootViewController?.view)!) {
                 self.progressShow(true) //ProgressHUD.show()
            }
        }else{
            self.displayAlertForNoIntenret()
            return
        }
        
        self.edgesForExtendedLayout = UIRectEdge.init(rawValue: 0)
        
            if DeviceUtility.isIphoneXType{
                layoutConstraintTopViewTopSpace.constant =  28
            }else{
                layoutConstraintTopViewTopSpace.constant =  5
            }

        if (reachabilityManager?.isReachable)!
        {
            self.callHomeAPIs()
        }
     
//        self.setupRefreshControl()
        
//            let refreshControl: UIRefreshControl = {
//            let refreshControl = UIRefreshControl()
//            refreshControl.addTarget(self, action:
//                #selector(HomeViewController.handleRefresh(_:)),for: UIControlEvents.valueChanged)
//            refreshControl.tintColor = UIColor.clear
//            return refreshControl
//        }()
        
      NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "HomeCellClickNotification"), object: nil)

      NotificationCenter.default.addObserver(self, selector: #selector(HomeViewController.handle(withNotification:)), name: NSNotification.Name(rawValue: "HomeCellClickNotification"), object: nil)
        
//        if AppDelegate.sharedInstance().tabBarController.tabBar.isHidden{
//            AppDelegate.sharedInstance().tabBarController.tabBar.isHidden = false
//            AppDelegate.sharedInstance().tabBarController.selectedIndex = 0
//        }
        
//   self.tableViewHome.addSubview(refreshControl)
    }

    // ------------------------------------------------------------------------------------------------------------------

    override  func viewWillAppear(_ animated: Bool)
    {

        //Bhavesh 2-Dec
        
        self.tabBarController?.tabBar.isHidden = false
        self.tabBarController?.tabBar.layer.zPosition = -0
        
        //```````````
        Analytics.logEvent("Home_Screen", parameters: [
            "name": "Home Screen" as NSObject,
            ])
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Home Screen") 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
        
        textFieldSearch.resignFirstResponder()
    
        if KConstant.APP.isReceivedNotification
        {
            var objNotificationViewController = NotificationViewController()
            objNotificationViewController = self.storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
            self.navigationController?.pushViewController(objNotificationViewController, animated: false)
        }
    }

// ------------------------------------------------------------------------------------------------------------------
// MARK: -  NotificationCenter Methods
// ------------------------------------------------------------------------------------------------------------------

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @objc func handle(withNotification notification : NSNotification)
    {
      let dictObject  = notification.object as! Dictionary<String, Any>
//      print(dictObject)
      let  strCheck = dictObject["nFlag"] as! String
     
        if strCheck == "3"
        {
            self.nPageCount = self.nPageCount + 8
            self.getPopularBrands()
        }else  if strCheck == "4" {
            self.nPageCountRecent = self.nPageCountRecent + 10
            self.getLatestWatches()
        }
        else  if strCheck == "0"
        {
            let objBrand = dictObject["object"] as! Brand
//         print(objBrand)
            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ModelsViewController") as! ModelsViewController
            objModelsViewController.dictOption = dictObject as [String : AnyObject]
            objModelsViewController.isFromHome =  true
            self.navigationController?.pushViewController(objModelsViewController, animated: true)
        }
        else
        {
            var strItemID = ""
            var strBrandID = ""
            var strBrandName = ""
            var strModelSlug = ""
            
            if strCheck == "1"
            {
                let objLatestWatch : LatestWatch = dictObject["object"] as!  LatestWatch
                let  objFeaturedWatchProduct : LatestWatchProduct = objLatestWatch.Product as LatestWatchProduct
                strItemID = objFeaturedWatchProduct.ItemID
                strBrandID = objLatestWatch.BrandID
                strBrandName = objLatestWatch.BrandName
                strModelSlug = objLatestWatch.ModelSlug
            }else{
                let objFeaturedWatch : FeaturedWatch = dictObject["object"] as!  FeaturedWatch
                let  objFeaturedWatchProduct : LatestWatchProduct = objFeaturedWatch.Product as LatestWatchProduct
                strItemID = objFeaturedWatchProduct.ItemID
                strBrandID = objFeaturedWatch.BrandID
                strBrandName = objFeaturedWatch.BrandName
            }
            
            let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
            objProductDetailsViewController.strItemID = strItemID
            if strBrandID.characters.count > 0 {
                objProductDetailsViewController.strBrandID = strBrandID
            }
            objProductDetailsViewController.strBrandName = strBrandName
            objProductDetailsViewController.strModelSlug = strModelSlug
            objProductDetailsViewController.isFromMultipleScreen = true
            objProductDetailsViewController.isRequiedCubeAnimation = false
            self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
            
    
            
            
       }
  }

// ------------------------------------------------------------------------------------------------------------------
// MARK: - Custom Methods
// ------------------------------------------------------------------------------------------------------------------

    func getPopularBrands()
    {
        let tempPageCount = self.nPageCount-9 as Int
        

        let dictParams = [KConstant.kMethod : "popular_brand.php","start":String(tempPageCount),"end":String(self.nPageCount)]
 
        ServerRequest.sendServerRequestWithDictForPopularBrands(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess {
                let arrResponse = response as! Array<Brand>
                
                if arrResponse.count == 0{
                    self.nRequiredLoader = 0
                }

                if self.arrPopularBrands.count >= 10
                {
                    if arrResponse.count > 0
                    {
                        for i in 0 ..< arrResponse.count
                        {
                            let objBrandResponse : Brand = arrResponse[i] as Brand
                            let objBrandStored : Brand = self.arrPopularBrands[i] as! Brand
                            if objBrandResponse.BrandID !=  objBrandStored.BrandID {
                                self.arrPopularBrands.add(objBrandResponse)
                            }
                        }
                    }
                }
                else
                {
                    self.arrPopularBrands.addObjects(from: arrResponse)
                }
                ///
                
                self.isPopularFinished = true

                self.tableViewHome.reloadData()

                if self.nPageCount != 8{
                    self.progressShow(false) // ProgressHUD.dismiss()
                }
            }else{
                self.progressShow(false)                 
            }
        }


//        if self.isLatestFinished && self.isPopularFinished{
//            print("I  M FINISHED POPULAR")
//            self.progressShow(false) // ProgressHUD.dismiss()
//        }
    }
    
  // ------------------------------------------------------------------------------------------------------------------

    func getLatestWatches()
    {
         var tempPageCount = self.nPageCountRecent-9 as Int
         
         if self.nPageCountRecent == 10 {
            tempPageCount = 0
         }
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
       let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
            
        
          let dictParams = [KConstant.kMethod : "latestwatches_detail.php","deviceid":uniqueIdentifier,"start":String(tempPageCount),"end":String(self.nPageCountRecent)]
 
            ServerRequest.sendServerRequestWithDictForAllLatestWatches(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess
            {
                let arrResponse = response as! Array<LatestWatch>
                //self.arrLatestWatches.addObjects(from: arrResponse)
                
                if arrResponse.count == 0{
                    self.nRequiredLoaderLatest = 0
                }
                //
                  if self.arrLatestWatches.count >= 10
                  {
                    if arrResponse.count > 0
                    {
                     
                        self.isLatestFinished = true

                            for i in 0 ..< arrResponse.count
                            {
                                let objLatestWatchResponse : LatestWatch = arrResponse[i] as LatestWatch
                                let objLatestWatchStored : LatestWatch = self.arrLatestWatches[i] as! LatestWatch
                            
                                if objLatestWatchResponse.BrandID !=  objLatestWatchStored.BrandID
                                {
                                    self.arrLatestWatches.add(objLatestWatchResponse)
                                }
                            }
                        }
                  }
                  else
                  {
                     self.arrLatestWatches.addObjects(from: arrResponse)
                    self.isLatestFinished = true
                  }
                self.tableViewHome.reloadData()
                
                if self.isPopularFinished && self.isLatestFinished  {
                    self.progressShow(false) // ProgressHUD.dismiss()
                }
                
                if self.nPageCountRecent != 10{
                    self.progressShow(false) // ProgressHUD.dismiss()
                }
                //print("Suuccess\(self.arrLatestWatches)")
            }else{
                print("failure\(response)")
            }

          
                
        }
    }
    
     // ------------------------------------------------------------------------------------------------------------------

    func getFeaturedWatches()
    {
        let dictParams = [KConstant.kMethod :  "featured_watches.php"]

        ServerRequest.sendServerRequestWithDictFeaturetWatch(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess {
                self.progressShow(false) // ProgressHUD.dismiss()
                self.arrFeatureWatches = response as! Array<FeaturedWatch>
                self.tableViewHome.reloadData()
            }else{
                self.progressShow(false) // ProgressHUD.dismiss()
                print("failure\(response)")
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func setAdjustableLabel(label: UILabel) {
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func handleRefresh() {
        
        self.arrLatestWatches.removeAllObjects()
        self.arrPopularBrands.removeAllObjects()
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
             self.progressShow(true) //ProgressHUD.show()
        }

        self.nPageCount = 8
        self.nPageCountRecent = 10
        self.isPopularFinished = false

        self.callHomeAPIs()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func callHomeAPIs()
    {
        self.getPopularBrands()
        completionFunction(param: "a parameter" as AnyObject) { () -> Void in
            //print(self.arrPopularBrands)
            self.getLatestWatches()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func completionFunction(param: AnyObject, completion: ()->Void)
    {
        // Do your stuff
        if param is String
        {
            print("parameter = \(param)")
        }
        
        print("going to execute completion closure")
        completion()
    }

    
    // ------------------------------------------------------------------------------------------------------------------

    func displayAlertForNoIntenret() {
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        
        if !(reachabilityManager?.isReachable)!
        {
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            self.present(alert, animated: true, completion: nil)
            return
        }
    }

    // ------------------------------------------------------------------------------------------------------------------

    func setupRefreshControl()
    {
        self.refreshControl = UIRefreshControl()
        let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")

        let compass_background = UIImageView(image: gifImage)
        compass_background.center = CGPoint(x: self.view.frame.size.width/2, y: 30)
        self.refreshControl.tintColor = UIColor.clear
        self.refreshControl.addSubview(compass_background)

        self.isRefreshAnimating = false;
        self.refreshControl.addTarget(self, action:#selector(HomeViewController.handleRefresh(_:)),for: UIControl.Event.valueChanged)
        self.tableViewHome.addSubview(self.refreshControl)
    }
    
    // ------------------------------------------------------------------------------------------------------------------


    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        self.arrLatestWatches.removeAllObjects()
        self.arrPopularBrands.removeAllObjects()
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
//             self.progressShow(true) //ProgressHUD.show()
        }
        
        self.nPageCount = 8
        self.nPageCountRecent = 10
        self.isPopularFinished = false
        
        self.callHomeAPIs()
   
        let deadlineTime = DispatchTime.now() + .seconds(3/2)
        DispatchQueue.main.asyncAfter(deadline: deadlineTime) {
            refreshControl.endRefreshing()
        }
    }


// MARK: - Custom Action Methods
    

    @IBAction func buttonMenuClicked(_ sender: Any)
    {
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }


    @IBAction func buttonSearchClicked(_ sender: Any) {
        var objSearchViewController = SearchViewController()
        objSearchViewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        objSearchViewController.isFromSideMenu = false
        objSearchViewController.strSearchString = textFieldSearch.text!
        self.navigationController?.pushViewController(objSearchViewController, animated: false)
    }


    @objc func buttonShowAllClicked(_ sender: Any)
    {
        let button = sender
        if (button as AnyObject).tag == 0 {
            let objBrands = self.storyboard?.instantiateViewController(withIdentifier: "BrandsViewController") as! BrandsViewController
            objBrands.isFromHome = true
            objBrands.isViewAllClicked = true
            self.navigationController?.pushViewController(objBrands, animated: true)
        }else  if (button as AnyObject).tag == 1 {
            let objLatestWatchesViewController = self.storyboard?.instantiateViewController(withIdentifier: "LatestWatchesViewController") as! LatestWatchesViewController
            objLatestWatchesViewController.nFlag = 1
            self.navigationController?.pushViewController(objLatestWatchesViewController, animated: true)
        }else{
            let objLatestWatchesViewController = self.storyboard?.instantiateViewController(withIdentifier: "LatestWatchesViewController") as! LatestWatchesViewController
            objLatestWatchesViewController.nFlag = 2
            self.navigationController?.pushViewController(objLatestWatchesViewController, animated: true)
        }
    }


    func buttonSelectClicked(sender:AnyObject) -> Void
    {
        
    }

    
    @IBAction  func buttonPhoneClicked(_ sender: Any)
    {
        if let url = URL(string: "tel://+1-3106017264"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
 

    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    // MARK: - UITableView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if section == 2 || section == 3  {
                return nil
        }
        
       let  viewHeader = HeaderTitleView.instanceFromNib() as! HeaderTitleView
        if section == 0 {
            viewHeader.labelTitle.text = "Select a Brand :"
        }else  if section == 1 {
            viewHeader.labelTitle.text = "Latest Arrivals :"
        }else{
            viewHeader.labelTitle.text = "Featured added to Our Site :"
        }
        
        viewHeader.buttonShowAll.tag = section
        viewHeader.buttonShowAll.addTarget(self, action: #selector(buttonShowAllClicked(_:)), for: .touchUpInside)
        
        return viewHeader
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        if section == 2 {
           return 0
        }
        else if section == 3 {
            return 0
        }
        else
        {
             return 1
        }
       
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func numberOfSections(in tableView: UITableView) -> Int{
        return 4
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if indexPath.section == 0
        {
            if KConstant.IS_IPHONE5 {
                // OLD 158
                return 137
            }
            // old 188
            return 170
        }
        else if indexPath.section == 2 {
            return 0
        }
        else if indexPath.section == 3{

            return 0
        }
        else{
            if KConstant.IS_IPHONE5 {
                // OLD 198
                return 177
            }
            // OLD -- 228
            return 210
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

     func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 2 || section == 3 {
            return 0.0001
        }
        else
        {
            return 0.00001
        }
       
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if section == 2 || section == 3 {
            return 0.0001
        }
        else
        {
            return 38
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.section == 3
        {
            let cell : FooterTableViewCell = tableView.dequeueReusableCell(withIdentifier: "FooterTableViewCell", for: indexPath ) as! FooterTableViewCell
                cell.labelData2.text = arrMenu1[indexPath.row]
                cell.labelData.text = arrMenu[indexPath.row]

            if cell.labelData2.text == "TRADE-IN YOUR WATCH" {
                 cell.buttonForNavigation2.tag = 1
            }
            
            if cell.labelData2.text == "CERTIFIED APPRIASAL" {
                cell.buttonForNavigation2.tag = 3
            }
            
            if cell.labelData.text == "SELL YOUR WATCH" {
                cell.buttonForNavigate.tag = 0
            }
            
            if cell.labelData.text == "GET YOUR WATCH AUTHENTICATED"{
                cell.buttonForNavigate.tag = 2
            }
            
            if KConstant.IS_IPHONE5{
                cell.labelData.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 13)
                cell.labelData2.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 13)
            }
            
            cell.selectionStyle = .none
            
            cell.buttonForNavigation2.addTarget(self, action: #selector(navigateItemAt(sender:)), for: .touchUpInside)
            cell.buttonForNavigate.addTarget(self, action: #selector(navigateItemAt(sender:)), for: .touchUpInside)
            return UITableViewCell()
        }
        else
        {
            
            let cell : HomeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "HomeTableViewCell", for: indexPath ) as! HomeTableViewCell
            cell.collectionViewHome?.tag = indexPath.section
            
            cell.delegate = self

            if indexPath.section == 0 {
                cell.setCollectionData(self.arrPopularBrands as! [Brand], withIndex: indexPath.section, isRequiredLoader:self.nRequiredLoader)
            }else if indexPath.section == 1 {
                cell.setCollectionDataForLatestWatches(self.arrLatestWatches as! [LatestWatch], withIndex: 1, isForLatest: true, isRequiredLoaderLatest: self.nRequiredLoaderLatest)
            }else{
                cell.setCollectionDataForFeatureWatches(self.arrFeatureWatches as [FeaturedWatch], withIndex: 2, isForLatest: false)
            }
            
            if UIDevice.current.systemVersion == "11.0"
            {
                if(KConstant.IS_IPHONE_6){
                    cell.layoutConstraintTableViewLeadingSpace.constant = -8
                    cell.layoutConstraintTableViewTrailingSpace.constant = -8
                }else if(KConstant.IS_IPHONE_6P){
                    cell.layoutConstraintTableViewLeadingSpace.constant = -12
                    cell.layoutConstraintTableViewTrailingSpace.constant = -12
                }else  if(KConstant.IS_IPHONE_X){
                    cell.layoutConstraintTableViewLeadingSpace.constant = -8
                    cell.layoutConstraintTableViewTrailingSpace.constant = -8
                }
            }
            cell.selectionStyle = .none
             return cell
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
    @objc func navigateItemAt(sender: UIButton){
        //...
        var objNotificationViewController = FormsViewController()
        objNotificationViewController = self.storyboard?.instantiateViewController(withIdentifier: "FormsViewController") as! FormsViewController
        
        var a:Int = 0
        
        if sender.tag == 0 {
            a = 6
        }
        else if sender.tag == 1{
            a = 7
        }
        else if sender.tag == 2{
            a = 8
        }
        else if sender.tag == 3 {
            a = 9
        }
        objNotificationViewController.nIndex = a
        objNotificationViewController.isFromHome = true
        self.navigationController?.pushViewController(objNotificationViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
  
    // ------------------------------------------------------------------------------------------------------------------
    func calculateHeight(inString:String) -> CGFloat
    {
        let messageString = inString
       // let attributes = [NSAttributedStringKey : Any]() = [ .font : UIFont.systemFont(ofSize: 15.0)]
        let attributes =  [
            NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont.systemFont(ofSize: 15)
        ]
        
        let attributedString : NSAttributedString = NSAttributedString(string: messageString, attributes: attributes)
        
        let rect : CGRect = attributedString.boundingRect(with: CGSize(width: 222.0, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, context: nil)
        
        let requredSize:CGRect = rect
        return requredSize.height
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------

    func reloadLatestWatches() {
//         self.progressShow(true) //ProgressHUD.show()
        self.nPageCountRecent = self.nPageCountRecent + 10
        self.getLatestWatches()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func reloadPopulerBrands() {
//         self.progressShow(true) //ProgressHUD.show()
        self.nPageCount = self.nPageCount + 8
        self.getPopularBrands()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
}
