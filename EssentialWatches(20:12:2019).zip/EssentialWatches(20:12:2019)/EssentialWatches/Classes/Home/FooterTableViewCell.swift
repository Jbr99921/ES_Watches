//
//  FooterTableViewCell.swift
//  EssentialWatches
//
//  Created by msp on 18/10/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class FooterTableViewCell: UITableViewCell {

    @IBOutlet var labelData: UILabel!
    @IBOutlet var buttonForNavigate: UIButton!
    @IBOutlet var labelData2: UILabel!
    @IBOutlet var buttonForNavigation2: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
