//
//  HeaderTitleView.swift
//  EssentialWatches
//
//  Created by Vikram on 13/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class HeaderTitleView: UIView {

    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var buttonShowAll: UIButton!
    @IBOutlet weak var imageViewArrow: UIImageView!
    @IBOutlet weak var layoutConstraintLabelTitleTopSpace: NSLayoutConstraint!

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        labelTitle.numberOfLines = 0
        labelTitle.adjustsFontSizeToFitWidth = true
    }

    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "HeaderTitleView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }

}
