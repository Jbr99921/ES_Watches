//
//  SearchView.swift
//  EssentialWatches
//
//  Created by Vikram on 09/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class SearchView: UIView {

    @IBOutlet weak var textFieldSearch: UITextField!
    @IBOutlet weak var buttonSearch: UIButton!
    @IBOutlet weak var viewBackground:  UIView!
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        viewBackground.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        viewBackground.layer.borderWidth =  1.0
    }
 

    class func instanceFromNib() -> SearchView {
        return UINib(nibName: "SearchView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! SearchView
    }
}
