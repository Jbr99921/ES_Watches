//
//  PlaceholderLabel.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class PlaceholderLabel: UILabel {

    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.font = UIFont.init(name: KConstant.kFontOpenSenseLight, size: 14)

    }

}
