//
//  YellowBorderButton.swift
//  EssentialWatches
//
//  Created by Vikram on 08/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class YellowBorderButton: UIButton {


    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        self.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        self.layer.borderWidth =  1.0
        self.backgroundColor = UIColor.white
    }
  

}
