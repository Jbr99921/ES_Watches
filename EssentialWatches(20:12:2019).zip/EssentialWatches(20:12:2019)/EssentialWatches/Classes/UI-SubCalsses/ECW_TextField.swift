//
//  ECW_TextField.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class ECW_TextField: UITextField {
    override func draw(_ rect: CGRect) {
        self.font = UIFont(name: KConstant.kFontOpenSenseRegular, size: 15)
        self.textColor = UIColor.black
        self.layer.borderColor = UIColor.lightGray.cgColor
        self.layer.borderWidth = 0.5
        let vPadding: UIView = UIView(frame: CGRect(x: 0, y: 0, width: 7, height: 45))
        vPadding.backgroundColor = UIColor.clear
        self.leftView = vPadding
        self.leftViewMode = .always
    }
}
