//
//  SearchButton.swift
//  EssentialWatches
//
//  Created by Vikram on 28/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class SearchButton: UIButton {

 
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
      
        if KConstant.IS_IPHONE5 {
            self.setImage(UIImage(named: "search_icon_5"), for: .normal)
        }else   if KConstant.IS_IPHONE_6{
            self.setImage(UIImage(named: "search_icon_6"), for: .normal)
        }else   if KConstant.IS_IPHONE_6P{
            self.setImage(UIImage(named: "search_icon_6"), for: .normal)
        }else{
            self.setImage(UIImage(named: "search_icon"), for: .normal)
        }
    }
  

}
