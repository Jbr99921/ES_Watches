//
//  SelectionCell.swift
//  EssentialWatches
//
//  Created by Vikram on 02/11/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class SelectionCell: UICollectionViewCell {
    
    @IBOutlet weak var labelName: UILabel!
}
