//
//  customCellBig.swift
//  GlobalTributes
//
//  Created by MSPSYS061 on 06/02/18.
//  Copyright © 2018 Dan. All rights reserved.
//

import UIKit

class customCellBig: UICollectionViewCell,UIScrollViewDelegate {
    @IBOutlet var imgvb: UIImageView!
    @IBOutlet var imgv_insidescr: UIImageView!
    
    @IBOutlet var scroll_view: UIScrollView!
    @IBOutlet var imgvScroll: ImageScrollView!
    override func awakeFromNib() {
                self.scroll_view.minimumZoomScale = 1
                self.scroll_view.maximumZoomScale = 3.5
        self.scroll_view.delegate = self
    }
    
    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return self.imgv_insidescr
    }
}
