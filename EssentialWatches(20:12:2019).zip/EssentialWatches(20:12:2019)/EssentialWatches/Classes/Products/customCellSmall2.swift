//
//  customCellSmall.swift
//  GlobalTributes
//
//  Created by MSPSYS061 on 06/02/18.
//  Copyright © 2018 Dan. All rights reserved.
//

import UIKit

class customCellSmall2: UICollectionViewCell {
    
    @IBOutlet var viewborder: UIView!
    @IBOutlet var imgvs: UIImageView!
}
