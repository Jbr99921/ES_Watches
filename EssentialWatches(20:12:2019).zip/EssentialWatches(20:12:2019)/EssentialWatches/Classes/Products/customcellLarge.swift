//
//  customcellLarge.swift
//  EssentialWatches
//
//  Created by Apple on 23/07/18.
//  Copyright © 2018 MSP. All rights reserved.
//

import UIKit

class customcellLarge: UICollectionViewCell {
    
    @IBOutlet weak var imgv: UIImageView!
}
