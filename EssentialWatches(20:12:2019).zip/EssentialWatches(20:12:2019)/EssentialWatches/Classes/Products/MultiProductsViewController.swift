//
//  MultiProductsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import HTHorizontalSelectionList
import Alamofire
import Firebase

class MultiProductsViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,UIScrollViewDelegate ,CollectionDelegateSelected
{
   
    var selectedIndex = 0
    var dictOption  = [String : AnyObject]()
    var arrWatchList = NSMutableArray()
    var isFromAnotherScreen:Bool = false
    var arrVariationList = NSMutableArray()
    var arrSubVariationList = NSMutableArray()
    var arrDateRange = NSMutableArray()
    var arrWatchModels = NSMutableArray ()
    var arrWatchSubModels = NSMutableArray()
    var arrBrands = NSMutableArray()
    var arrModels = NSMutableArray()
    var arrVariation = NSMutableArray()
    var showWatchList:Bool = true
    var strSubModelValue = ""
    var strModelSlug = "" as String
    var subModel = "" as? String
    var strSubModelSlug = "" as String
    var strModelSlugTemp = "" as String
    var strModelName = "" as String
    var strModelID = "" as String
    var strBrandID = "" as String
    var strBrandName = "" as String
    var nPageCount = 11
    
    var nInitialIndexBrand = -1
    var nInitialIndexModel = -1
    var nInitialIndexSubModel = -1
    
    var strSelectedBrandID = "" as String
    var strSelectedModel = "" as String
    var strSelectedVariation = "" as String
    
    var isVariationClicked = false
    var isReceivedBrand = false
    var isReceivedModel = false
    var isSubModuleShow = false
    var isBrandTapped = false
    //var isFromSubModel = false
    
    var isRequiredToHideFooter = false
    var strReceivedSubModels = "" as String
    
    var  arrFetched = NSMutableArray()
    var screenWidth = CGFloat()
    var screenHeight = CGFloat()
    
    var view1  = UIView()
    var curIndexPath = NSIndexPath()
    
    var brandIndex : Int = -1
    var modelIndex : Int = -1
    var subModelIndex : Int = -1
    var variationIndex : Int = -1
    var subvariationIndex : Int = -1
    var dateRangeIndex : Int = -1
    
    
    var strSubVariationSlug = ""
     var strDateSlug = ""
    
    //
    //    @IBOutlet weak var viewBrand: HTHorizontalSelectionList!
    //    @IBOutlet weak var viewModel: HTHorizontalSelectionList!
    //    @IBOutlet weak var viewSubModel: HTHorizontalSelectionList!
    //    @IBOutlet weak var viewVariation: HTHorizontalSelectionList!
    
    @IBOutlet weak var tableViewProducts: UITableView!
    @IBOutlet weak var viewHeaderSelection: UIView!
    @IBOutlet weak var labelNotFound:  UILabel!
    @IBOutlet weak var labelVariation: UILabel!
    @IBOutlet weak var labelModel: UILabel!
    @IBOutlet weak var viewtw: UIView!
    
    @IBOutlet var layoutConstraintlabel_Sub_Hight: NSLayoutConstraint!
    
    @IBOutlet var layoutConstraint_sub_view_Hight: NSLayoutConstraint!
    
    @IBOutlet var layoutConstraint_SubView_Top_Hight: NSLayoutConstraint!
    
    @IBOutlet var layoutConstraint_SubView_Bottom_Hight: NSLayoutConstraint!
    
    @IBOutlet var labelSubModel: UILabel!
    
    @IBOutlet var screenViewTop: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintViewSelectionHeight: NSLayoutConstraint!
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.textFieldSearch.delegate = self
        self.labelNotFound.isHidden = true
        self.isFromAnotherScreen = false
        
        
        tableViewProducts.register(UINib(nibName: "Collection", bundle: nil), forCellReuseIdentifier: "Collection")
        
        UserDefaults.standard.setValue(strBrandName, forKey: "Brand")
        UserDefaults.standard.setValue(strModelSlug, forKey: "Model")
        
        
        self.setTitleLabel(title: strModelSlug)
        
        
        self.labelNotFound.isHidden = true
        //        self.tableViewProducts.addSubview(refreshControl)
        
        let screenSize: CGRect = UIScreen.main.bounds
        screenWidth = screenSize.width
        screenHeight = screenSize.height
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
            // ZVProgressHUD.show()
            self.progressShow(true)
            
            self.getModels()
        }
        
        self.showHeaderLogo()
   
    
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewWillAppear(_ animated: Bool)
    {
        
        
        Analytics.logEvent("Model_Watches_Screen", parameters: [
            "name": "Model Watches Screen" as NSObject,
        ])
        
        print(self.strBrandID)
        
        for i in 0 ..< KConstant.APP.arrBrands.count
        {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            if objBrand.BrandID == self.strBrandID
            {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    self.isReceivedBrand = true
                    
                }
                break
            }
        }
        
        
        
        self.screenViewTop.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)
        //self.getModels()
        // tableViewProducts.reloadData()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //self.setUpInitialDesignScreen()
    }
    
   
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
   
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func handleRefresh(_ refreshControl: UIRefreshControl)
    {
        nPageCount = 11
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        //  ZVProgressHUD.show()
        self.progressShow(true)
        self.arrWatchList.removeAllObjects()
 //       self.getWatchList()
        
        tableViewProducts.reloadData()
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getWatchList()
    {
        if strBrandID.characters.count > 0
        {
            var dictParams = ["":""]
            if(strBrandID == "46")
            {
                if(strSubVariationSlug != "")
                {
                    dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"VariationSlug":strSelectedVariation,"SubVariationSlug":strSubVariationSlug,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]
                }
                else
                {
                    dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"VariationSlug":strSelectedVariation,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]
                }
                
            }
            else
            {
                dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSelectedVariation,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]
            }
            ServerRequest.sendServerRequestWithPostMethodForWatchList(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<WatchHeader>
                    
                    if arrResponse.count == 0 || self.nPageCount == 11
                    {
                        var frame = CGRect.zero
                        frame.size.height = .leastNormalMagnitude
                        self.tableViewProducts.tableFooterView = UIView(frame: frame)
                        self.isRequiredToHideFooter = true
                    }else{
                        // ZVProgressHUD.dismiss()
                        self.progressShow(false)
                        let footerView = UIView(frame: CGRect(x: 0, y: 0, width:  self.tableViewProducts.frame.size.width, height: 40))
                        let imageViewGIF = UIImageView(image: nil)
                        let gifImage = UIImage.gif(name: "funny1")
                        imageViewGIF.image = gifImage
                        imageViewGIF.frame = CGRect(x: (self.tableViewProducts.frame.size.width/2)-15, y: 1, width: 35, height: 35)
                        footerView.addSubview(imageViewGIF)
                        self.tableViewProducts.tableFooterView = footerView
                        self.isRequiredToHideFooter = false
                    }
                    
                    self.isFromAnotherScreen = true
                    if self.isVariationClicked
                    {
                        self.arrWatchList.removeAllObjects()
                        self.isVariationClicked = false
                    }
                    //                 self.arrWatchList.removeAllObjects()
                    
                    if(self.nPageCount == 11)
                    {
                        self.arrWatchList.removeAllObjects()
                    }
                    
                    for i in 0 ..< arrResponse.count
                    {
                        let objWatchHeader = arrResponse[i] as WatchHeader
                        if !self.arrWatchList.contains(objWatchHeader){
                            self.arrWatchList.add(objWatchHeader)
                        }
                        else
                        {
                            print("dfjglfkjg")
                        }
                    }
                    
                }else{
                    print("failure\(response)")
                }
                
                
                if self.arrWatchList.count == 0{
                    self.labelNotFound.isHidden = false
                }else{
                    self.labelNotFound.isHidden = true
                }
                
                if self.isBrandTapped
                {
                    self.labelNotFound.text = "Please Choose Model"
                }
                else if self.strSubModelValue == "1" && self.isFromAnotherScreen
                {
                    
                    self.labelNotFound.text = "Please select Sub Model"
                }
                
                //               else{
                //                self.labelNotFound.text = "No item found"
                //                    }
                
                self.tableViewProducts.reloadData()
                
                //  ZVProgressHUD.dismiss()
                self.progressShow(false)
                
            }
        }
         self.tableViewProducts.reloadData()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getModels()
    {
 
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        for i in 0 ..< KConstant.APP.arrBrands.count
        {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            if objBrand.BrandID == self.strBrandID
            {
                brandIndex = i
                break
            }
        }
        
        if strBrandID.characters.count > 0
        {
            var dictParams = NSMutableDictionary()
            dictParams = [KConstant.kMethod : "brand_models.php","id":strBrandID]
            ServerRequest.sendServerRequestWithPostMethodForRowModels(dictParam: dictParams as! Dictionary<String, String>) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<WatchModelRow>
                    
                    self.arrWatchModels.removeAllObjects()
                    for i in 0 ..< arrResponse.count
                    {
                        let objWatchModelRow = arrResponse[i] as WatchModelRow
                        self.arrWatchModels.add(objWatchModelRow)
                    }
                    for i in 0 ..< self.arrWatchModels.count
                    {
                        let objWatchModelRow = self.arrWatchModels[i] as! WatchModelRow
                        if objWatchModelRow.ModelSlug == self.strModelSlug
                        {
                            self.modelIndex = i
                            if objWatchModelRow.is_submodel == "1"
                            {
                                self.getSubModels()
                            }
                            else
                            {
                                self.getVariations()
                            }
                            
                          //  self.getAPICall()
                        }
                      self.tableViewProducts.reloadData()
                    }
                }else{
                    print("failure\(response)")
                }
                
                if !self.arrFetched.contains("1"){
                    self.arrFetched.add("1");
                }
                
                //let objModel = self.arrWatchModels[self.selectedIndex] as! WatchModelRow
                
                if self.strSubModelValue == "1" && self.isFromAnotherScreen//objModel.is_submodel == "1"
                {
                    self.labelNotFound.isHidden = false
                    
                    if(self.strBrandID == "46")
                    {
                        
                        self.labelNotFound.text = "Please select Variations"
                    }
                    else
                    {
                        self.labelNotFound.text = "Please Choose Model Family"
                    }
                }
                else
                {
                    if self.isBrandTapped == true
                    {
                        self.labelNotFound.text = "Please Choose Model"
                        self.labelNotFound.isHidden = false
                        self.arrWatchList.removeAllObjects()
                        self.arrWatchSubModels.removeAllObjects()
                    }else{
                        self.labelNotFound.isHidden = true
                    }
                }
                
                if(self.strSubModelSlug == "" && self.strSelectedVariation == "" && self.strSubVariationSlug == "")
                {
                    self.getWatchList()
                    self.getDateRanges()
                }
                self.tableViewProducts.reloadData()
                
                if self.isBrandTapped{
                    // ZVProgressHUD.dismiss()
                    self.progressShow(false)
                }
              
            }
        }
    }
    // -----------------------------------------------------------------------------------------------------------------
    
    func getDateRanges()
    {
        if strBrandID.characters.count > 0
        {
            var dictParams = ["":""]
            if(strBrandID == "46")
            {
                
                dictParams = [KConstant.kMethod : "date_ranges_used_rolex.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"VariationSlug":strSelectedVariation,"SubVariationSlug":strSubVariationSlug]
                
                ServerRequest.sendServerRequestWithPostMethodForDateRange(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<DateRangeModel>
                    self.arrDateRange.addObjects(from: arrResponse)
                    
                    
                    for i in 0 ..< self.arrDateRange.count
                    {
                        let objVariation = self.arrDateRange[i] as! DateRangeModel
                        
                        if(objVariation.YearName == self.strDateSlug)
                        {
                            self.dateRangeIndex = i
                            self.getWatchList()
                              self.getDateRanges()
                            break
                        }
                    }
                     self.tableViewProducts.reloadData()
                }else{
                    print("failure\(response)")
                    }
                }
            }
        }
       
    }
    // ------------------------------------------------------------------------------------------------------------------
    
    func getVariations()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        if self.isFromAnotherScreen
        {
                   // ZVProgressHUD.show()
                   self.progressShow(true)
        }
               
        
        if strBrandID.characters.count > 0 && strModelSlug.characters.count > 0
        {
            let dictParams = [KConstant.kMethod : "submodel_list.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug]
            
            
            
            ServerRequest.sendServerRequestWithDictForModels(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                
                    let arrResponse = response as! Array<Model>
                    
                    self.arrVariationList.removeAllObjects()
                    self.arrVariationList.addObjects(from: arrResponse)
                    
                    for i in 0 ..< self.arrVariationList.count
                    {
                        let objVariation = self.arrVariationList[i] as! Model
                        
                        if(objVariation.SubModel_Slug == self.strSelectedVariation)
                        {
                            self.variationIndex = i
                            if(objVariation.IsSubModelVariation == "1")
                            {
                                self.getSubVariationModels()
                            }
                            else
                            {
                                  self.arrWatchList.removeAllObjects()
                                  self.getWatchList()
                                self.getDateRanges()
                            }
                            break
                        }
                    }
                    if self.isFromAnotherScreen
                    {
                        //  ZVProgressHUD.dismiss()
                        self.progressShow(false)
                    }
                    
                }else{
                    print("failure\(response)")
                }
              
             //   self.getWatchList()
                self.tableViewProducts.reloadData()
                
                //             self.setSelectionValues()
            }
        }
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func buttonClicked(sender: UIButton) {
        
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        
        let objWatchHeader = self.arrWatchList[(indexPath.section-6)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        
        objAskAQuestionViewController.strOption = "AskQuestion"
        objAskAQuestionViewController.strTitle = "Ask a Question"
        objAskAQuestionViewController.dictOption =  dictOption
        objAskAQuestionViewController.strBrandName =  objWatchHeader.BrandName ?? "BrandName"
        objAskAQuestionViewController.objWatchList =  objWatchList
        objAskAQuestionViewController.isFromMultiple = true
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func buttonBuyNowClicked(sender: UIButton)
    {
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let objWatchHeader = self.arrWatchList[(indexPath.section-6)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        
        if objWatchList.InStock == "1"
        {
            objAskAQuestionViewController.strOption = "Purchase"
            objAskAQuestionViewController.strTitle = "Buy Now"
        }else{
            objAskAQuestionViewController.strOption = "HaveUsSearch"
            objAskAQuestionViewController.strTitle = "Have us search for it"
        }
        objAskAQuestionViewController.strBrandName =  objWatchHeader.BrandName ?? "BrandName"
        objAskAQuestionViewController.objWatchList =  objWatchList
        objAskAQuestionViewController.isFromMultiple = true
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonImageClicked(sender: UIButton)
    {
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let objWatchHeader = self.arrWatchList[(indexPath.section-6)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        KConstant.APP.strProductName = objWatchList.Name
        
        if objWatchList.Image_full.characters.count > 0
        {
            let slider = ZoomableImageSlider(images:  [(objWatchList.Image_full)], currentIndex: 0, placeHolderImage: nil)
            self.present(slider, animated: true, completion: nil)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func didSelectCollection(_ tag: Int, Index: Int)
    {
        var strSelected = ""
        self.labelNotFound.isHidden = true
        self.isVariationClicked = true
        self.isRequiredToHideFooter = true
        
        if tag ==  0
        {
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }
            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ModelsViewController") as! ModelsViewController
            let objBrand = KConstant.APP.arrBrands[Index]
            let dict = ["object":objBrand,"nFlag":"0"] as [String : Any]
            objModelsViewController.dictOption = dict as [String : AnyObject]
            objModelsViewController.isFromHome =  true
            self.navigationController?.pushViewController(objModelsViewController, animated: true)
            return
          
        }
        else if tag ==  1
        {
            
            self.labelNotFound.text = ""
            let objModel = self.arrWatchModels[Index] as! WatchModelRow
            strSelected = objModel.ModelSlug
            strModelSlug = strSelected
          
            strModelName = objModel.ModelName
            strSelectedVariation = ""
            
            modelIndex = Index
            variationIndex = -1
            subModelIndex = -1
         
            self.arrWatchSubModels.removeAllObjects()
            self.arrVariationList.removeAllObjects()
            self.arrSubVariationList.removeAllObjects()
            self.arrDateRange.removeAllObjects()
            self.arrWatchList.removeAllObjects()
            
            self.strSubModelSlug = ""
            self.strSelectedVariation = ""
            self.strSubVariationSlug = ""
            self.strDateSlug = ""
            
            if strModelSlug.characters.count > 0
            {
                // self.tableViewProducts.isHidden =  true
                let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
                if !(reachabilityManager?.isReachable)!
                {
                    self.displayAlertForNoIntenret()
                    return
                }else{
                    //   ZVProgressHUD.show()
                    self.progressShow(true)
                }
                if objModel.is_submodel == "1"{
                    showWatchList = true
                   
                    self.labelNotFound.text = "Please select Variation"
                    self.labelNotFound.isHidden = false
                    self.getSubModels()
                }else{
                    self.labelNotFound.isHidden = true
                    self.getVariations()
                }
            }else{
                self.displayAlertWithOk(message: "Model slug not found")
            }
            tableViewProducts.reloadData()
        }
        else if tag ==  2
        {
          
                      self.labelNotFound.text = ""
                      self.arrVariationList.removeAllObjects()
                      self.arrSubVariationList.removeAllObjects()
                      self.arrDateRange.removeAllObjects()
                     self.arrWatchList.removeAllObjects()
                     
                      self.strSelectedVariation = ""
                      self.strSubVariationSlug = ""
                      self.strDateSlug = ""
            
            if self.arrWatchModels.count > 0
            {
                let objsubModel = self.arrWatchSubModels[Index] as! SubModel
                strSubModelSlug = objsubModel.ModelSlug
                subModelIndex  = Index
                if strSubModelSlug.characters.count > 0
                {
                    //self.tableViewProducts.isHidden =  true
                    let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
                    if !(reachabilityManager?.isReachable)!
                    {
                        self.displayAlertForNoIntenret()
                        return
                    }else{
                        // ZVProgressHUD.show()
                        self.progressShow(true)
                    }
                    if(objsubModel.IsSubVariation == "1")
                    {
                        self.labelNotFound.text = "Please select Variation"
                        self.labelNotFound.isHidden = false
                        self.getVariations()
                    }
                    else
                    {
                        arrWatchList.removeAllObjects()
                        self.labelNotFound.isHidden = true
                        self.getWatchList()
                        self.getDateRanges()
                    }
                }else{
                    self.displayAlertWithOk(message: "Model slug not found")
                }
                tableViewProducts.reloadData()
            }
        }
        else  if tag ==  3
        {
            self.labelNotFound.text = ""
            self.arrSubVariationList.removeAllObjects()
            self.arrDateRange.removeAllObjects()
                                 
            self.strSubVariationSlug = ""
            self.strDateSlug = ""
            
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
               
                self.progressShow(true)
            }
            nPageCount = 11
            let objVariation = self.arrVariationList[Index] as! Model
            variationIndex = Index
            strSelectedVariation = objVariation.SubModel_Slug
          
            if(objVariation.IsSubModelVariation == "1")
            {
                self.labelNotFound.text = "Please select Variation"
                self.labelNotFound.isHidden = false
                self.getSubVariationModels()
              
                tableViewProducts.reloadData()
            }
            else
            {
                self.getWatchList()
                  self.getDateRanges()
                self.labelNotFound.isHidden = true
                tableViewProducts.reloadData()
            }
        }
        else if tag == 4
        {
            self.labelNotFound.text = ""
            self.arrDateRange.removeAllObjects()
            self.strDateSlug = ""
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
               
                self.progressShow(true)
            }
            let objVariation = self.arrSubVariationList[Index] as! Model
            subvariationIndex = Index
            strSubVariationSlug = objVariation.SubModel_Slug
            tableViewProducts.reloadData()
            self.labelNotFound.text = ""
          //  self.getDateRanges()
            self.labelNotFound.isHidden = true
            self.getWatchList()
            self.getDateRanges()
            tableViewProducts.reloadData()
        }else if tag == 5
        {
            self.labelNotFound.text = ""
               self.arrDateRange.removeAllObjects()
            
            //  self.strDateSlug = ""
              let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
              if !(reachabilityManager?.isReachable)!
              {
                  self.displayAlertForNoIntenret()
                  return
              }else{
                 
                  self.progressShow(true)
              }
              let objVariation = self.arrSubVariationList[Index] as! Model
              subvariationIndex = Index
              strSubVariationSlug = objVariation.SubModel_Slug
              tableViewProducts.reloadData()
              self.labelNotFound.text = ""
              self.labelNotFound.isHidden = true
              self.getWatchList()
              self.getDateRanges()
              tableViewProducts.reloadData()
        }
    }
    // ------------------------------------------------------------------------------------------------------------------
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITableView Deleagate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if(arrWatchList.count>0 && section>=6)
        {
            let viewHeader = UIView(frame: CGRect(x: 0, y: -20, width: tableView.frame.size.width, height: 43))
            let labelHeaderTitle = UILabel(frame: CGRect(x: 10, y: 0, width:tableView.frame.size.width-20, height: 43))
            viewHeader.backgroundColor = UIColor.clear
            labelHeaderTitle.numberOfLines = 0
            labelHeaderTitle.adjustsFontSizeToFitWidth = true
            labelHeaderTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 15)
            
            let objWatchHeader = self.arrWatchList[section-6] as! WatchHeader
            labelHeaderTitle.text =  objWatchHeader.CategoryName
            viewHeader.backgroundColor = UIColor.init(red: 0.8667, green: 0.8667, blue: 0.8667, alpha: 1)
            viewHeader.addSubview(labelHeaderTitle)
            return viewHeader
        }
        else
        {
            if(arrWatchSubModels.count == 0 && section == 2)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(KConstant.APP.arrBrands.count == 0 && section == 0)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrWatchModels.count == 0 && section == 1)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrVariationList.count == 0 && section == 3)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrSubVariationList.count == 0 && section == 4)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrDateRange.count == 0 && section == 5)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            
            let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 20))
            let labelHeaderTitle = UILabel(frame: CGRect(x: 10, y: 0, width:tableView.frame.size.width-20, height: 20))
            viewHeader.backgroundColor = UIColor.lightGray.withAlphaComponent(0.1)
            labelHeaderTitle.numberOfLines = 0
            labelHeaderTitle.adjustsFontSizeToFitWidth = true
            labelHeaderTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 12)
            if(section == 0)
            {
                labelHeaderTitle.text =  "Brand"
            }
            else if(section == 1)
            {
                labelHeaderTitle.text =  "Model"
            }
            else if(section == 2)
            {
                labelHeaderTitle.text =  "Variation of the " + strModelSlug
            }
            else if(section == 3)
            {
                labelHeaderTitle.text =  "Variation of the " + strSubModelSlug
            }
            else if(section == 4)
            {
                labelHeaderTitle.text =  "Variation of the " + strSelectedVariation
            }
            else if(section == 5)
            {
                labelHeaderTitle.text =  "Variation "
            }
            labelHeaderTitle.textColor = UIColor.black
            viewHeader.addSubview(labelHeaderTitle)
            
            
            return viewHeader
        }
        return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        //  return UIView.new
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if(section<6)
        {
            
            if(arrWatchSubModels.count == 0 && section == 2)
            {
                return 0.05
            }
            else if(KConstant.APP.arrBrands.count == 0 && section == 0)
            {
                return 0.05
            }
            else if(arrWatchModels.count == 0 && section == 1)
            {
                return 0.05
            }
            else if(arrVariationList.count == 0 && section == 3)
            {
                return 0.05
            }
            else if(arrSubVariationList.count == 0 && section == 4)
            {
                return 0.05
            }
            else if(arrDateRange.count == 0 && section == 5)
            {
                return 0.05
            }
            return 20
        }
        return 44
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        if(arrWatchSubModels.count == 0 && section == 2)
        {
            return 0.05
        }
        else if(KConstant.APP.arrBrands.count == 0 && section == 0)
        {
            return 0.05
        }
        else if(arrWatchModels.count == 0 && section == 1)
        {
            return 0.05
        }
        else if(arrVariationList.count == 0 && section == 3)
        {
            return 0.05
        }
        else if(arrSubVariationList.count == 0 && section == 4)
        {
            return 0.05
        }
        else if(arrDateRange.count == 0 && section == 5)
        {
            return 0.05
        }
        return 5;
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        if(arrWatchSubModels.count == 0 && section == 2)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(KConstant.APP.arrBrands.count == 0 && section == 0)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrWatchModels.count == 0 && section == 1)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrVariationList.count == 0 && section == 3)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrSubVariationList.count == 0 && section == 4)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrDateRange.count == 0 && section == 5)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        let viewFooter = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 5))
        viewFooter.backgroundColor = UIColor.lightGray.withAlphaComponent(0.1)
        return viewFooter
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if(section < 6)
        {
            if(arrWatchSubModels.count == 0 && section == 2)
            {
                return 0
            }
            else if(KConstant.APP.arrBrands.count == 0 && section == 0)
            {
                return 0
            }
            else if(arrWatchModels.count == 0 && section == 1)
            {
                return 0
            }
            else if(arrVariationList.count == 0 && section == 3)
            {
                return 0
            }
            else if(arrSubVariationList.count == 0 && section == 4)
            {
                return 0
            }
            else if(arrDateRange.count == 0 && section == 5)
            {
                return 0
            }
            return 1
        }
        if(self.arrWatchList.count != 0)
        {
            let objWatchList = self.arrWatchList[section-6] as! WatchHeader
            return objWatchList.Product.count
        }
        else
        {
            return 0
        }
        
        // }
        
        //  return 0
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if self.arrWatchList.count > 0 {
            return self.arrWatchList.count+6
        }
        return 6
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        if(indexPath.section < 6)
        {
            if(arrWatchSubModels.count == 0 && indexPath.section == 2)
            {
                return 0
            }
            return 32
        }
        
        if self.arrWatchList.count > 0
        {
            
            let objWatchHeader = self.arrWatchList[indexPath.section-6] as! WatchHeader
            
            let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
            
            let strCondition = "\(objWatchList.condition )" as String
            
            var nHeight = 21 as Int
            
            if strCondition.characters.count > 0 {
                nHeight = 0
            }
            
            return CGFloat(232 - nHeight) // 288
        }
        return 2 // 288
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if(indexPath.section>=6)
        {
        let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        let objWatchHeader = self.arrWatchList[indexPath.section-6] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
        objProductDetailsViewController.strItemID = objWatchList.ItemID
        objProductDetailsViewController.strBrandID = strBrandID
        objProductDetailsViewController.strModelSlug = strModelSlug
        objProductDetailsViewController.strSubModelName = strModelSlug
        objProductDetailsViewController.strSubModelSlug = strSubModelSlug
         objProductDetailsViewController.strSelectedVariation = strSelectedVariation
         objProductDetailsViewController.strSubVariationSlug = strSubVariationSlug
        
        objProductDetailsViewController.strBrandName = strBrandName
        objProductDetailsViewController.isFromMultipleScreen = true
        objProductDetailsViewController.isRequiedCubeAnimation = true
        self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
        KConstant.APP.window?.layer.add(self.pushTransition(), forKey: "kTransitionAnimation")
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: -  UITableView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if(indexPath.section < 6)
        {
            let cell : Collection = tableView.dequeueReusableCell(withIdentifier: "Collection", for: indexPath) as! Collection
            cell.contentView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.1)
            cell.CollectionView.backgroundColor = UIColor.clear
            cell.backgroundColor = UIColor.clear
            cell.CollectionView.tag = indexPath.section
            cell.collectioDelegate = self
            if(indexPath.section == 0)
            {
                cell.arrayData = KConstant.APP.arrBrands as NSArray
                cell.strBrandID = self.strBrandID as NSString
                cell.CollectionView.reloadData()
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.brandIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 1)
            {
                cell.arrayData = arrWatchModels as NSArray
                cell.strModelName = self.strModelSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.modelIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 2)
            {
                cell.arrayData = self.arrWatchSubModels as NSArray
                cell.strSubModelSlag = self.strSubModelSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.subModelIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 3)
            {
                cell.arrayData = arrVariationList as NSArray
                cell.strVariation = strSelectedVariation as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.variationIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 4)
            {
                cell.arrayData =  arrSubVariationList as NSArray
                cell.strSubVariation = strSubVariationSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.subvariationIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 5)
            {
                cell.arrayData = arrDateRange as NSArray
                cell.strDateRange = strDateSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.dateRangeIndex, section: 0), at: .left, animated: true)
            }
            cell.CollectionView.reloadData()
            return cell
        }
        else
        {
            let cell : SearchCell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath ) as! SearchCell
            if self.arrWatchList.count > 0
            {
                
                let objWatchHeader = self.arrWatchList[indexPath.section-6] as! WatchHeader
                
                let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
                
                cell.labelName.text = objWatchList.Name+" "+objWatchList.Subtext
                cell.labelName2.text  = objWatchList.ShortDesc.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
                cell.labelName2.isHidden = true;
                
                cell.labelRef.text =  "Ref - "+objWatchList.ModelNumber
                cell.labelItemID.text = "Item Id - "+objWatchList.ItemID
                cell.labelRetailPrice.text =  "\(objWatchList.Retail_Lable ?? "")"+"\(objWatchList.RetailPrice ?? "")"
                
                cell.labelCase.text =  "Case - " + objWatchList.Case
                cell.labelSize.text =  "Size - " + "\(objWatchList.CaseSize ?? "")"
                cell.labelDial.text =  "Dial - " + objWatchList.Dial
                
                self.setAdjustableLabel(label:  cell.labelCondition)
                
                let url = URL(string: objWatchList.Image)!
                let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
                
                cell.imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
                
                var strCondition = "\(objWatchList.condition )" as String
                
                if strCondition.characters.count > 0
                {
                    cell.labelCondition.text =  "CONDITION - "+strCondition
                    cell.layoutConstraintConditionHeight.constant = 21
                }else{
                    cell.labelCondition.text = ""
                    cell.layoutConstraintConditionHeight.constant = 0
                }
                
                if (cell.labelRetailPrice.text?.characters.count)! == 0 {
                    cell.labelYourPriceOnly.isHidden = false
                }else{
                    cell.labelYourPriceOnly.isHidden = true
                }
                
                cell.buttonAskQuestion.tag = indexPath.row
                cell.buttonAskQuestion.addTarget(self, action: #selector(buttonClicked(sender:)), for: .touchUpInside)
                
                cell.buttonBuyNow.tag = indexPath.row
                cell.buttonBuyNow.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)
                
                cell.buttonImage.isHidden = true
                
                
                if indexPath.section == 0 && indexPath.row == 0
                {
                    cell.viewTopLine.isHidden = true
                }else {
                    cell.viewTopLine.isHidden = false
                }
                
                if objWatchList.InStock == "1"
                {
                    cell.labelYourPrice.text = "Your Price - "+objWatchList.YourPrice
                    cell.buttonBuyNow.setTitle("Buy Now", for: .normal)
                    cell.buttonBuyNow.backgroundColor = KConstant.kColorThemeYellow
                    cell.buttonBuyNow.setTitleColor(UIColor.white, for: .normal)
                }
                else
                {
                    cell.labelYourPrice.text = ""
                    cell.buttonBuyNow.setTitle("Have us find this watch", for: .normal)
                    cell.buttonBuyNow.backgroundColor = UIColor.white
                    cell.buttonBuyNow.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                    cell.buttonBuyNow.setTitleColor(UIColor.black, for: .normal)
                }
                
                //            cell.layoputConstraintViewMainTopSpace.constant = -1
                
                cell.labelYourPriceOnly.text = cell.labelYourPrice.text
                
                cell.buttonBuyNow.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                cell.buttonBuyNow.layer.borderWidth = 1.0
                cell.buttonAskQuestion.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                cell.buttonAskQuestion.layer.borderWidth = 1.0
                cell.layoutConstraintViewBottomTopLineHeight.constant = 1.0
            }
            return cell
        }
        let cell : Collection = tableView.dequeueReusableCell(withIdentifier: "Collection", for: indexPath) as! Collection
        return cell
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITextField Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
            
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
            if nPageCount > 11 {
            nPageCount = nPageCount + 12
            self.getWatchList()
            self.getDateRanges()
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getSubModels()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        if self.isFromAnotherScreen
        {
            // ZVProgressHUD.show()
            self.progressShow(true)
        }
        
        
        if strBrandID.characters.count>0 &&  strModelSlug.characters.count>0
        {
            let dictParams = [KConstant.kMethod : "brand_submodel.php","id":strBrandID,"slug":self.strModelSlug]
            
            print(dictParams)
            
            ServerRequest.sendServerRequestWithDictForSubModels(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<SubModel>
                    
                    self.arrWatchSubModels.addObjects(from: arrResponse)
                    
                    /////********************
                    for i in 0 ..< arrResponse.count
                    {
                        let objWatchSubModel = arrResponse[i] as SubModel
                        
                        if objWatchSubModel.ModelSlug == self.strSubModelSlug
                        {
                            self.subModelIndex = i
                            if(objWatchSubModel.IsSubVariation == "1")
                            {
                                
                                self.getVariations()
                                break
                            }
                        }
                       
                    }
                    
                    //************//**/**//*/*/*/**/*/*/*/*/*/*/*//****************
                    
                    if self.nInitialIndexSubModel != -1
                    {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            
                        }
                    }
                    
                    if self.isFromAnotherScreen
                    {
                        if(self.strBrandID == "46")
                        {
                            
                            self.labelNotFound.text = "Please select Variation"
                            self.labelNotFound.isHidden = false
                        }
                        else
                        {
                            self.labelNotFound.text = "Please Choose Model Family"
                            self.labelNotFound.isHidden = false
                        }
                        
                    }
                    
                    if(self.strBrandID == "46")
                    {
                        // self.getWatchList()
                        self.arrWatchList.removeAllObjects();
                        self.tableViewProducts.reloadData()
                    }
                    else
                    {
                        
                        self.getVariations()
                    }
                        //  ZVProgressHUD.dismiss()
                    self.progressShow(false)
                    
                }else{
                    print("failure\(response)")
                }
            }
        }
    }
    
    func getSubVariationModels()
       {
           
           let dictParams = [KConstant.kMethod : "submodel_variation_list.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"SubVariationSlug":strSelectedVariation]
           
           ServerRequest.sendServerRequestSubVariation(dictParam: dictParams) { (response, isSuccess) in
                       if isSuccess
           {
                           let arrResponse = response as! Array<Model>
                           self.arrSubVariationList.addObjects(from: arrResponse)
            
            
                            for i in 0 ..< self.arrSubVariationList.count
                            {
                                let objVariation = self.arrSubVariationList[i] as! Model
                                
                                if(objVariation.SubModel_Slug == self.strSubVariationSlug)
                                {
                                    self.subvariationIndex = i
                                    self.getWatchList()
                                      self.getDateRanges()

                                    break
                                }
                            }
                           self.tableViewProducts.reloadData()
                       }else{
                           print("failure\(response)")
                       }
                       self.progressShow(false) // ProgressHUD.dismiss()
           }
        
      
           
          
       }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getAPICall()
    {
        if self.strSubModelValue == "1"
        {
            self.getSubModels()
        }
        else
        {
            self.getVariations()
        }
    }
    // ------------------------------------------------------------------------------------------------------------------
}
