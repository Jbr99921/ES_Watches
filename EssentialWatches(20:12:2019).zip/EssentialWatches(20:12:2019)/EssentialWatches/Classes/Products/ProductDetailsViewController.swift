//
//  ProductDetailsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import HTHorizontalSelectionList
import Alamofire
import Firebase

var viewYellowLineTopSpace = -70
var addToWaitListHeight = 150//100



class ProductDetailsViewController: BaseViewController, UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,CollectionDelegateSelected{
    
    
    
    
    
    var strSubModelName:String = ""
    
    var strModelSlug = "" as String
    var strSelectedVariation = ""
    var isFromMultipleScreen : Bool = false
    var isFromMultiple : Bool = false
    var isSelectionListSelect : Bool = false
    
    var isRequiedCubeAnimation : Bool = false
    
    var isLatestFromModel : Bool = false
    var isFromSearch : Bool = false
    var isSubModelSelect : Bool = false
    var strTitle : String = ""
    var strItemID : String = ""
    var strCategoryName : String = ""
    var objProduct : WatchList? = nil
    
    var strSubVariationSlug = ""
    var strDateSlug = ""
    
    
    var objLatestWatch : LatestWatch? = nil
    var objFeaturedWatch : FeaturedWatch? = nil
    var objSearch : Search? = nil
    
    
    
    
    var isVariationClicked = false
    var isReceivedBrand = false
    
    
    var strBrandID = "" as String
    var strBrandName = "" as String
    var nPageCount = 11
    
    var isNextPrevClicked = false
    
    
    var strModelName: NSString!
    var strVariation: NSString!
    
    
    var isRequiredToAnimate : Bool = false
    
    var dictOption  = [String : AnyObject]()
    var arrWatchList = NSMutableArray()
    var arrWatchModels = NSMutableArray ()
    var arrWatchSubModels = NSMutableArray()
    var arrVariationList = NSMutableArray()
    var arrSubVariationList = NSMutableArray()
    var arrDateRange = NSMutableArray()
    var arrayData: NSArray!
    
    var brandIndex : Int = -1
    var modelIndex : Int = -1
    var subModelIndex : Int = -1
    var variationIndex : Int = -1
    var subvariationIndex : Int = -1
    var dateRangeIndex : Int = -1
    
    var strSubModelValue = ""
    var subModel = "" as? String
    var strSubModelSlug = "" as String
    var strModelSlugTemp = "" as String
    var strModelID = "" as String
    
    
    
    var strTemp = ""
    
    var arrSimilarProducts = Array<SimilarWatch>()
    var is_SubModel = "0"
    var isFirst = 0
    var isLoadAll = 1
    var strSubModelSlug1:String = ""
    // @IBOutlet weak var viewHeaderSelection: UIView!
    
    
    //MARK:- Outlets
    
    
    @IBOutlet var viewHeaderSelection: UIView!
    @IBOutlet weak var searchView: UIView!
    
    @IBOutlet weak var heightCollection: NSLayoutConstraint!
    @IBOutlet weak var collection_viewMain: UICollectionView!                               // collection_viewMain
    @IBOutlet weak var buttonAskAQuestion: UIButton!
    
    @IBOutlet weak var collection_viewsmall: UICollectionView!                          // collection_viewsmall
    @IBOutlet var tableViewProducts: UITableView!
    
    @IBOutlet var buttonPrev: UIButton!
    @IBOutlet var buttonNext: UIButton!
    
    
    @IBOutlet var button_Privious: UIButton!
    @IBOutlet var button_Next: UIButton!
    
    
    
    @IBOutlet var lblModel: UILabel!
    
    @IBOutlet var viewFooter: UIView!
    
    
    @IBOutlet weak var lblWatchName: UILabel!
    @IBOutlet weak var lblItemID: UILabel!
    @IBOutlet weak var lblCase: UILabel!
    @IBOutlet weak var lblCaseSize: UILabel!
    @IBOutlet weak var lblDial: UILabel!
    @IBOutlet weak var lblbraceletTitle: UILabel!
    @IBOutlet weak var lblbraceletKey: UILabel!
    @IBOutlet weak var lblbracelet: UILabel!
    @IBOutlet weak var lblRetailPriceTitle: UILabel!
    @IBOutlet weak var lblRetailPrice: UILabel!
    @IBOutlet weak var lblYourPriceTitle: UILabel!
    @IBOutlet weak var lblYourPrice: UILabel!
    @IBOutlet weak var lblWirePriceTitle: UILabel!
    @IBOutlet weak var lblWirePrice: UILabel!
    @IBOutlet weak var lblMovement: UILabel!
    @IBOutlet weak var viewTable: UIView!
    
    @IBOutlet weak var lblModelNum: UILabel!
    @IBOutlet weak var txtViewDescription: UITextView!
    
    @IBOutlet weak var imageWatch: UIImageView!
    
    @IBOutlet weak var labelNotFound:  UILabel!
    
    
    @IBOutlet weak var imageViewCertified1: UIImageView!
    @IBOutlet weak var imageViewCertified2: UIImageView!
    @IBOutlet weak var labelCertified1: UILabel!
    @IBOutlet weak var labelCertified2: UILabel!
    
    @IBOutlet weak var viewImage: UIView!
    @IBOutlet weak var collectionViewProducts: UICollectionView!                            // collectionViewProducts
    @IBOutlet weak var buttonBuyNow: UIButton!
    @IBOutlet weak var buttonRequestTrade: UIButton!
    @IBOutlet weak var buttonQuestion: UIButton!
    @IBOutlet weak var labelCondition: UILabel!
    @IBOutlet weak var labelSorry: UILabel!
    @IBOutlet weak var labelSorryWaitList: UILabel!
    
    @IBOutlet weak var viewAddToWishList: UIView!
    @IBOutlet weak var viewBuyNow: UIView!
    
    @IBOutlet weak var buttonVideo: UIButton!
    @IBOutlet weak var imageViewYoutubeIcon: UIImageView!
    @IBOutlet weak var labelSimilarProduct: UILabel!
    @IBOutlet weak var viewVideo: UIView!
    @IBOutlet weak var viewLineBottom: UIView!
    
    @IBOutlet weak var buttonVideoBuy: UIButton!
    @IBOutlet var btnAddWishList: UIButton!
    @IBOutlet var btnAddWishList1: UIButton!
    
    @IBOutlet weak var imageViewYoutubeIconBuy: UIImageView!
    @IBOutlet weak var labelSimilarProductBuy: UILabel!
    
    @IBOutlet weak var labelReference: UILabel!
    @IBOutlet weak var labelShortDescReference: UILabel!
    
    @IBOutlet weak var viewGesture: UIView!
    
    @IBOutlet weak var layoutConstraintLableShortDescHeight: NSLayoutConstraint!
    //    @IBOutlet weak var viewVideoBuy: UIView!
    
    //@IBOutlet weak var viewLIneVideo: UIView!
    @IBOutlet weak var layoutConstraintViewVideoHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintViewVideoBuyNowHeight: NSLayoutConstraint!
    
    var collectionViewLayout: CustomCellFlowLayout!
    
    //  @IBOutlet weak var layoutConstraintYellowLineTopSpace: NSLayoutConstraint!
    
    @IBOutlet weak var viewHeight: NSLayoutConstraint!
    @IBOutlet weak var viewHeightBuy: NSLayoutConstraint!
    @IBOutlet weak var tableviewHeight: NSLayoutConstraint!
    
    //  @IBOutlet weak var layoutConstraintCollectionViewTopSpace: NSLayoutConstraint!
    //  @IBOutlet weak var layoutConstraintConditionBuyNowHeight: NSLayoutConstraint!
    
    //  @IBOutlet weak var layoutConstraintConditionImageViewLeading: NSLayoutConstraint!
    //  @IBOutlet weak var layoutConstraintConditionImageViewTrailing: NSLayoutConstraint!
    //  @IBOutlet weak var layoutConstraintConditionLabelValueLeading: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintCollectionViewHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintInfoViewHeight: NSLayoutConstraint!
    
    //  @IBOutlet weak var layoutConstraintLabelReHeight: NSLayoutConstraint!
    
    //  @IBOutlet weak var labelYourPriceTitleTopSpace: NSLayoutConstraint!
    //   @IBOutlet weak var labelYourPriceValueTopSpace: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintViewAddToWaitListHeight: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintLabelConditionHeight: NSLayoutConstraint!
    
    //  @IBOutlet weak var layoutConstraintViewNextPrevHeight: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintLabelYourPriceHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintLabelYourPriceValueHeight: NSLayoutConstraint!
    
    
    //  @IBOutlet weak internal var labelYourImageViewCertified2TopSpace: NSLayoutConstraint!
    
    //  @IBOutlet weak var scrViewBottomSpace: NSLayoutConstraint!
    var selectedindex:Int = 0
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        selectedindex=0
        
        
        tableViewProducts.register(UINib(nibName: "Collection", bundle: nil), forCellReuseIdentifier: "Collection")
        
        
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
            self.progressShow(true)
        }
        
        imageWatch.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        imageWatch.layer.borderWidth =  0.6
        
        searchView.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        searchView.layer.borderWidth =  1
        
        labelNotFound.isHidden = true
        self.tableViewProducts.delegate = self
        self.tableViewProducts.dataSource = self
        
        self.setTitleLabel(title: "Watch Details")
        self.callAllApi()
        
        self.viewHeader.buttonLogo.isHidden = true
        self.viewHeader.labelTitle.isHidden = true
        self.viewHeader.imageViewMiddleIcon.isHidden = false
        self.viewHeader.buttonMiddle.isHidden = false
        
        
        self.showHeaderLogo()
        
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func callAllApi()
    {
        if(KConstant.APP.arrBrands.count<=0)
        {
            
        }
        else
        {
            self.progressShow(true)
            self.getProductInfo()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func callSubModelFirst()
    {
        self.getModels();
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLayoutSubviews()
    {
        //self.setUpInitialDesignScreen()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewWillAppear(_ animated: Bool)
    {
        //Bhavesh 2-Dec
        self.tabBarController?.tabBar.isHidden = true
        self.tabBarController?.tabBar.layer.zPosition = -1
        self.tabBarController?.tabBar.isTranslucent = true
        //``````````
        Analytics.logEvent("Watch_Details_Screen", parameters: [
            "name": "Watch Details Screen" as NSObject,
        ])
        
        
        
        
        
        self.setTitleLabel(title: "Watch Details")
        if KConstant.IS_IPHONE5
        {
            viewYellowLineTopSpace = -10
            //       layoutConstraintCollectionViewTopSpace.constant = -30
        }else{
            //      layoutConstraintCollectionViewTopSpace.constant = -20
        }
        
        
        
        for i in 0 ..< KConstant.APP.arrBrands.count
        {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            if objBrand.BrandID == self.strBrandID
            {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.isReceivedBrand = true
                    self.brandIndex = i
                }
                break
            }
        }
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom  Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func showYoutubeIcon(isShow : Bool)
    {
        
        if isShow
        {
            imageViewYoutubeIcon.isHidden = true
            buttonVideo.isHidden = true
            viewVideo.isHidden = true
            
            imageViewYoutubeIconBuy.isHidden = true
            buttonVideoBuy.isHidden = true
            //            viewVideoBuy.isHidden = true
            
            //viewLIneVideo.isHidden = true
            layoutConstraintViewVideoHeight.constant = 0
            layoutConstraintViewVideoBuyNowHeight.constant = 0
            viewHeightBuy.constant = 206 - 60
        }else{
            imageViewYoutubeIcon.isHidden = false
            buttonVideo.isHidden = false
            viewVideo.isHidden = false
            
            imageViewYoutubeIconBuy.isHidden = false
            buttonVideoBuy.isHidden = false
            //         viewVideoBuy.isHidden = false
            //         viewLIneVideo.isHidden = false
            layoutConstraintViewVideoHeight.constant = 34
            layoutConstraintViewVideoBuyNowHeight.constant = 34
            viewHeightBuy.constant = 206
            //     layoutConstraintYellowLineTopSpace.constant = CGFloat(0)
        }
    }
    
    
    func setProductDetailsData()
    {
        self.tableViewProducts.tableFooterView = viewFooter
        
        lblWatchName.text = (objSearch?.Name)! + "\n" + (objSearch?.SubText)!
        self.setAdjustableLabel(label: lblWatchName)
        
        KConstant.APP.strProductName = (objSearch?.Name)!
        strBrandName = (objSearch?.BrandName)!
        strModelSlug = (objSearch?.ModelSlug)!
        strSubModelSlug = (objSearch?.subModelSlug)!
        strSubModelSlug1 = strModelSlug
        
        
        
        if self.objSearch?.arrextraimgs?.count == 0
        {
            self.collection_viewsmall.isHidden=true
            self.collection_viewMain.isHidden=true
            self.heightCollection.constant=0
            self.collection_viewMain.delegate = nil;
            self.collection_viewsmall.delegate = nil;
            self.collection_viewMain.dataSource = nil;
            self.collection_viewsmall.dataSource = nil;
            
            let url = URL(string: (self.objSearch?.Image_full)!)!
            
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            //        imageWatch.af_setImage(withURL: url, placeholderImage: placeholderImage)
            self.imageWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        }
        else{
            self.collection_viewsmall.isHidden=false
            self.collection_viewMain.isHidden=false
            self.heightCollection.constant=100
            self.collection_viewMain.delegate = self;
            self.collection_viewsmall.delegate = self;
            self.collection_viewMain.dataSource = self;
            self.collection_viewsmall.dataSource = self;
            self.collection_viewMain.reloadData()
            self.collection_viewsmall.reloadData()
            
        }
        
        if strSubModelSlug.characters.count > 0 {
            strSubModelName = strSubModelSlug
        }
        self.strSelectedVariation = objSearch?.variationslug ?? "Variationdemo"
        
        strBrandID = (objSearch?.Brandid)!
        
        for i in 0 ..< KConstant.APP.arrBrands.count
        {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            
            if objBrand.BrandName == self.strBrandName
            {
                break
            }
        }
        
        is_SubModel = (objSearch?.is_submodel)!
        
        if(is_SubModel == "1")
        {
            strTemp = (objSearch?.subModelSlug)!
            if self.strBrandID == "46" {
                
            }
        }
        else
        {
            strTemp = (objSearch?.ModelSlug)!
        }
        let url = URL(string: (objSearch?.Image_full)!)!
        
        let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
        
        self.imageWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        
        // strSelectedVariation = strModelSlug
        lblItemID.text = objSearch?.ItemID
        lblMovement.text = objSearch?.Movement
        lblCase.text = objSearch?.Case
        lblCaseSize.text = objSearch?.CaseSize
        lblDial.text = objSearch?.Dial
        var strCondition = "\(objSearch?.condition ?? "")"
        
        if strCondition.characters.count > 0 {
            labelCondition.text =  "CONDITION : "+"\(objSearch?.condition ?? "")"
            layoutConstraintLabelConditionHeight.constant = 21
        }else{
            labelCondition.text = ""
            layoutConstraintLabelConditionHeight.constant = 0
        }
        lblbracelet.text = objSearch?.Bracelet
        self.setAdjustableLabel(label: lblModel)
        self.setAdjustableLabel(label: lblItemID)
        self.setAdjustableLabel(label: lblMovement)
        self.setAdjustableLabel(label: lblCase)
        self.setAdjustableLabel(label: lblCaseSize)
        self.setAdjustableLabel(label: lblDial)
        self.setAdjustableLabel(label: lblbracelet)
        self.setAdjustableLabel(label: labelCondition)
        self.setAdjustableLabel(label: buttonVideo.titleLabel!)
        
        lblRetailPrice.text = objSearch?.RetailPrice
        lblYourPrice.text = objSearch?.YourPrice
        lblWirePrice.text = objSearch?.WirePrice
        
        //// DISPLYAED MODEL NAME INSTEAD OF NUMBER
        lblModelNum.text =  objSearch?.ModelNumber
        
        // Harshida
        //
        
        
        if objSearch?.InStock == "1"
        {
            viewBuyNow.isHidden = false
            viewAddToWishList.isHidden = true
            layoutConstraintLabelYourPriceHeight.constant = 20
            layoutConstraintLabelYourPriceValueHeight.constant = 20
            //      layoutConstraintYellowLineTopSpace.constant = CGFloat(-30)
        }
        else
        {
            viewBuyNow.isHidden = true
            viewAddToWishList.isHidden = false
            
            if KConstant.IS_IPHONE5{
                //           layoutConstraintYellowLineTopSpace.constant = CGFloat(-70)
            }else{
                //          layoutConstraintYellowLineTopSpace.constant = CGFloat(viewYellowLineTopSpace)
                layoutConstraintViewAddToWaitListHeight.constant = CGFloat(addToWaitListHeight)
            }
            layoutConstraintLabelYourPriceHeight.constant = 0
            layoutConstraintLabelYourPriceValueHeight.constant = 0
            
            self.lblRetailPriceTitle.text =  "\(self.objSearch?.Retail_Lable ?? "")"
            self.lblRetailPrice.text =  "\(self.objSearch?.RetailPrice ?? "")"
            //layoutConstraintViewAddToWaitListHeight.cons
        }
        
        
        self.getSimilarProducts(strItemID: (objSearch?.ItemID)!)
        
        if self.objSearch?.Video.characters.count == 0 {
            self.showYoutubeIcon(isShow: true)
        }else{
            self.showYoutubeIcon(isShow: false)
        }
        
        if self.objSearch?.RetailPrice == nil || self.objSearch?.RetailPrice == "" {
            //            labelYourPriceTitleTopSpace.constant = -20
            //            labelYourPriceValueTopSpace.constant = -20
            self.lblRetailPrice.isHidden = true
            self.lblRetailPriceTitle.isHidden = true
        }else{
            //            labelYourPriceTitleTopSpace.constant = 5
            //            labelYourPriceValueTopSpace.constant = 5
            self.lblRetailPrice.isHidden = false
            self.lblRetailPriceTitle.isHidden = false
        }
        
        if (self.objSearch?.wishlisted!) == "0" {
            self.btnAddWishList.setTitle("Add to Favourite", for: .normal)
            btnAddWishList.isSelected = false
            self.btnAddWishList1.setTitle("Add to Favourite", for: .normal)
            btnAddWishList1.isSelected = false
        }else{
            self.btnAddWishList.setTitle("Remove from Favourite", for: .selected)
            btnAddWishList.isSelected = true
            self.btnAddWishList1.setTitle("Remove from Favourite", for: .selected)
            btnAddWishList1.isSelected = true
        }
        
        let strTag = "\(objSearch?.Tag ?? "")"
        
        self.setAdjustableLabel(label: labelSorry)
        self.setAdjustableLabel(label: labelSorryWaitList)
        
        labelSorry.text = strTag
        labelSorryWaitList.text = strTag
        
        self.labelShortDescReference.text = ""
        
        if (self.objSearch?.KnownAs1)!.characters.count > 0 {
            self.labelShortDescReference.text  = String(format: "This watch is also known as: %@.",(self.objSearch?.KnownAs1)!)
        }
        
        if (self.objSearch?.KnownAs1)!.characters.count > 0 &&  (self.objSearch?.KnownAs2)!.characters.count > 0{
            self.labelShortDescReference.text  = String(format: "This watch is also known as: %@ , %@.",(self.objSearch?.KnownAs1)!, (self.objSearch?.KnownAs2)!)
        }
        
        if ((self.objSearch?.KnownAs1)!.characters.count > 0 && (self.objSearch?.KnownAs2)!.characters.count > 0 && (self.objSearch?.KnownAs3)!.characters.count > 0){
            self.labelShortDescReference.text  = String(format: "This watch is also known as: %@ , %@ , %@.",(self.objSearch?.KnownAs1)!, (self.objSearch?.KnownAs2)!, (self.objSearch?.KnownAs3)!)
        }else if self.labelShortDescReference.text?.characters.count == 0{
            self.labelShortDescReference.text = ""
        }
        
        if (self.objSearch?.ShortDesc.characters.count)! > 0
        {
            if ((self.objSearch?.KnownAs1)!.characters.count > 0 && (self.objSearch?.KnownAs2)!.characters.count > 0 && (self.objSearch?.KnownAs3)!.characters.count > 0){
                self.labelShortDescReference.text  = String(format: "This watch is also known as: %@ , %@. , %@ \n%@",(self.objSearch?.KnownAs1)!, (self.objSearch?.KnownAs2)!, (self.objSearch?.KnownAs3)!, (self.objSearch?.ShortDesc)!)
            }else{
                self.labelShortDescReference.text  = String(format: "%@",(self.objSearch?.ShortDesc)!)
            }
            
        }else if self.labelShortDescReference.text?.characters.count == 0{
            self.labelShortDescReference.text = ""
        }
        
        self.labelShortDescReference.text = self.labelShortDescReference.text?.replacingOccurrences(of: "<br>", with: "")
        
        if self.labelShortDescReference.text?.characters.count == 0 {
            viewLineBottom.isHidden = true
        }else{
            viewLineBottom.isHidden = false
        }
        
        if self.labelShortDescReference.text? .characters.count == 0
        {
            layoutConstraintLableShortDescHeight.constant = 0
        }
        else
        {
            if (self.labelShortDescReference.text? .characters.count)! < 50 || (self.labelShortDescReference.text? .characters.count)! < 152 {
                layoutConstraintLableShortDescHeight.constant =  self.estimatedHeightOfLabel(text:  labelShortDescReference.text!)
            }else{
                layoutConstraintLableShortDescHeight.constant =  self.estimatedHeightOfLabel(text:  labelShortDescReference.text!) - 20
            }
        }
        
        let strPrevID =   "\(objSearch?.Previous_ID ?? "")"
        let  strNextID =   "\(objSearch?.Next_ID ?? "")"
        
        if strPrevID == "" && strNextID == "" {
            //            layoutConstraintViewNextPrevHeight.constant = 0
        }else{
            //            layoutConstraintViewNextPrevHeight.constant = 53
        }
        
        if strNextID == ""{
            button_Next.isHidden = true
        }else{
            button_Next.isHidden = false
        }
        
        if strPrevID == ""{
            self.button_Privious.isHidden = true
        }else{
            self.button_Privious.isHidden = false
        }
        
        
    }
    
    
    
    
    
    // ------------------------------------------------------------------------------------------------------------------
    func estimatedHeightOfLabel(text: String) -> CGFloat
    {
        let font = self.lblModel.font
        let textAttributes = [NSAttributedString.Key.font: font]
        let size = CGSize(width: view.frame.width - 16, height: 1000)
        let rectangleHeight = text.boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: textAttributes, context: nil).height
        return rectangleHeight + 10
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func getProductInfo()
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        var strEmail = ""
        if (dictTemp != nil) {
            strEmail = (dictTemp?.value(forKey:KConstant.kEmail) as? String)!
        }
        let dictParams = [KConstant.kMethod : "watch_detail.php","email": strEmail,"itemid":strItemID,"deviceid":uniqueIdentifier]
        print(dictParams)
        ServerRequest.sendServerRequestWithDictForProductInfo(dictParam: dictParams) { (response, isSuccess) in
            
            print(response)
            if isSuccess
            {
                
                self.objSearch = response as? Search
                print(self.objSearch?.arrextraimgs)
                print(self.objSearch?.img_url)
                
                
                //                self.collection_viewsmall.dataSource=self
                //                self.collection_viewMain.dataSource=self
                //  self.collection_viewsmall.reloadData()
                //  self.collection_viewMain.reloadData()
                self.setProductDetailsData()
                // self.getSimilarProducts(strItemID: self.strItemID)
            }else{
                //                ProgressHUD.dismiss()
                
                self.progressShow(false)
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getadd_remove_wish_list(strStatus: String,dictDetail: NSDictionary)
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        
        let dictParams = ["itemid":strItemID,"deviceid":uniqueIdentifier,"wish":strStatus,"firstname":dictDetail.value(forKey: KConstant.kFirstName),"lastname":dictDetail.value(forKey: KConstant.kLastName),"email":dictDetail.value(forKey: KConstant.kEmail),"phone":dictDetail.value(forKey: KConstant.kMobileNum)]
        
        ServerRequest.sendServerRequestforGetMethod(dictParam: dictParams as! Dictionary<String, String> , APIName: "add_remove_wish_list.php") { (response, isSuccess) in
            if isSuccess
            {
                let dict : NSDictionary = response as! NSDictionary
                
                if dict["result"] as! Int == 1{
                    if strStatus == "Y"{
                        self.btnAddWishList.setTitle("Remove from Favourite", for: .selected)
                        self.btnAddWishList1.setTitle("Remove from Favourite", for: .selected)
                        
                    }else if strStatus == "N"{
                        self.btnAddWishList.setTitle("Add to Favourite", for: .normal)
                        self.btnAddWishList1.setTitle("Add to Favourite", for: .normal)
                        
                    }
                }else{
                    self.displayAlertWithCompletion(message:dict["message"]  as! String, completion: {
                    })
                }
                //                ProgressHUD.dismiss()
                self.progressShow(false)
                
            }else{
                //                ProgressHUD.dismiss()
                self.progressShow(false)
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getSimilarProducts(strItemID: String)
    {
        let dictParams = [KConstant.kMethod : "similar_model.php","itemid":strItemID]
        
        ServerRequest.sendPostRequestForSimilarProducts(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess {
                self.arrSimilarProducts.removeAll()
                self.arrSimilarProducts = response as! Array<SimilarWatch>
                print(self.arrSimilarProducts);
                
                //                if self.arrSimilarProducts.count == 0
                //                {
                //                    self.labelSimilarProduct.isHidden = true
                //                    self.layoutConstraintCollectionViewHeight.constant = -60
                //                }
                //                else
                //                {
                //                    self.labelSimilarProduct.isHidden = false
                //                   self.layoutConstraintCollectionViewHeight.constant = 188
                //                }
                
                
                //                self.collectionViewProducts.delegate = nil
                //                self.collectionViewProducts.dataSource = nil
                // change 2 to desired number of seconds
                // Your code with delay
                
                
                self.collectionViewProducts.delegate = self
                self.collectionViewProducts.dataSource = self
                self.collectionViewProducts.reloadData()
                self.callSubModelFirst()
                //                sleep(1)
                //                self.collectionViewProducts.collectionViewLayout.invalidateLayout()
                
                
                
            }
            
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func moveToAskViewController(option: String,  strTitle : String)
    {
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        objAskAQuestionViewController.strOption = option
        objAskAQuestionViewController.strTitle = strTitle
        
        //        if isFromMultiple {
        objAskAQuestionViewController.isFromMultiple = false
        //            objAskAQuestionViewController.objWatchList = objProduct
        //        }else{
        //            objAskAQuestionViewController.isFromMultiple = false
        objAskAQuestionViewController.objSearch =  self.objSearch
        objAskAQuestionViewController.isFromSearch = true
        
        //        }
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func handleGesture(_ sender : UISwipeGestureRecognizer)
    {
        // mainScrollView.isScrollEnabled = false
        if sender.direction == .right {
            self.buttonPrevClicked(self.button_Privious)
        }
        else if sender.direction == .left {
            self.buttonNextClicked(self.button_Next)
        }
        // mainScrollView.layoutIfNeeded()
        //  mainScrollView.setNeedsDisplay()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    @IBAction func btnAddToWishlistClicked(_ sender: UIButton) {
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
            sender.isSelected = !sender.isSelected
            //            ProgressHUD.show()
            self.progressShow(true)
            if sender.isSelected {
                self.getadd_remove_wish_list(strStatus: "Y",dictDetail: dictTemp!)
            }else{
                self.getadd_remove_wish_list(strStatus: "N",dictDetail: dictTemp!)
            }
        }else{
            NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "callAddRemoveWishlist"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(getProductInfo), name: NSNotification.Name(rawValue: "callAddRemoveWishlist"), object: nil)
            let objMyInfoVC : MyInfoViewController  = self.storyboard?.instantiateViewController(withIdentifier: "MyInfoViewController") as! MyInfoViewController
            objMyInfoVC.isWishlist = true
            if sender.isSelected {
                objMyInfoVC.wishStatus = "N"
            }else{
                objMyInfoVC.wishStatus = "Y"
            }
            objMyInfoVC.strItemId  = strItemID as NSString
            self.navigationController?.pushViewController(objMyInfoVC, animated: true)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonBuyNowClicked(_ sender: Any) {
        self.moveToAskViewController(option: "Purchase", strTitle: "Buy Now")
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonAskQuestionClicked(_ sender: Any) {
        self.moveToAskViewController(option: "AskQuestion", strTitle: "Ask a Question")
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonRequestTradeClicked(_ sender: Any) {
        let  objRequestViewController = self.storyboard?.instantiateViewController(withIdentifier: "RequestViewController") as! RequestViewController
        objRequestViewController.objSearch = self.objSearch
        self.navigationController?.pushViewController(objRequestViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonHaveSearchClicked(_ sender: Any) {
        self.moveToAskViewController(option: "HaveUsSearch", strTitle: "Have us search for it")
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonAddToWaitListClicked(_ sender: Any) {
        self.moveToAskViewController(option: "AddNameToWaitList", strTitle: "Add your name to the wait-list")
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonVideoClicked(_ sender: Any)
    {
        let objWebViewController = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
        objWebViewController.strOption = "Video"
        objWebViewController.strTitle =  (self.objSearch?.BrandName)!
        objWebViewController.isVideo = true
        objWebViewController.strURL = (self.objSearch?.Video)!
        self.navigationController?.pushViewController(objWebViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonImageClicked(_ sender: Any) {
        let slider = ZoomableImageSlider(images:  [(objSearch?.Image_full)!], currentIndex: 0, placeHolderImage: nil)
        self.present(slider, animated: true, completion: nil)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonNextClicked(_ sender: Any)
    {
        isNextPrevClicked = true
        collectionViewProducts.contentOffset = CGPoint(x: 0, y: 0)
        
        
        let strPrevID =   "\(objSearch?.Previous_ID ?? "")"
        let  strNextID =   "\(objSearch?.Next_ID ?? "")"
        
        if strPrevID == "" && strNextID == "" {
            //            layoutConstraintViewNextPrevHeight.constant = 0
        }else{
            //        layoutConstraintViewNextPrevHeight.constant = 53
        }
        
        if strNextID == ""{
            button_Next.isHidden = true
        }else{
            
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }
            
            //            ZVProgressHUD.show()
            self.progressShow(true)
            button_Next.isHidden = false
            strItemID = strNextID
            self.callAllApi()
        }
        
        if strPrevID == ""{
            button_Privious.isHidden = true
        }else{
            button_Privious.isHidden = false
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonPrevClicked(_ sender: Any)
    {
        isNextPrevClicked = true
        //    collectionViewProducts.contentOffset = CGPoint(x: 0, y: 0)
        
        let strPrevID =   "\(objSearch?.Previous_ID ?? "")"
        let  strNextID =   "\(objSearch?.Next_ID ?? "")"
        
        
        if strPrevID == ""{
            button_Privious.isHidden = true
        }else{
            
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }
            self.progressShow(true)
            button_Privious.isHidden = false
            strItemID = strPrevID
            self.callAllApi()
        }
        
        if strNextID == ""{
            button_Next.isHidden = true
        }else{
            button_Next.isHidden = false
        }
    }
    
    
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>)
    {
        // print(velocity.x)
        if scrollView == collectionViewProducts
        {
            if velocity.x == -0.0 || scrollView == collectionViewProducts{
                return
            }
            
            if velocity.x < 0.0{
                self.buttonPrevClicked(self.button_Privious)
            }else{
                self.buttonNextClicked(self.button_Next)
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        
    }
    
    
    func didSelectCollection(_ tag: Int, Index: Int)
    {
        var strSelected = ""
        self.isVariationClicked = true
        
        if tag ==  0
        {
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }
            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ModelsViewController") as! ModelsViewController
            let objBrand = KConstant.APP.arrBrands[Index]
            let dict = ["object":objBrand,"nFlag":"0"] as [String : Any]
            objModelsViewController.dictOption = dict as [String : AnyObject]
            objModelsViewController.isFromHome =  true
            self.navigationController?.pushViewController(objModelsViewController, animated: true)
            return
            
         
        }
        else if tag ==  1
        {
            let objModel = self.arrWatchModels[Index] as! WatchModelRow
            strSelected = objModel.ModelSlug
            strModelSlug = strSelected
          
            strModelName = objModel.ModelName as NSString
            strSelectedVariation = ""
            
            modelIndex = Index
            variationIndex = -1
            subModelIndex = -1
         
            self.arrWatchSubModels.removeAllObjects()
            self.arrVariationList.removeAllObjects()
            self.arrSubVariationList.removeAllObjects()
            self.arrDateRange.removeAllObjects()
            self.arrWatchList.removeAllObjects()
            
            self.strSubModelSlug = ""
            self.strSelectedVariation = ""
            self.strSubVariationSlug = ""
            self.strDateSlug = ""
            
            
            if strModelSlug.characters.count > 0
            {
                // self.tableViewProducts.isHidden =  true
                let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
                if !(reachabilityManager?.isReachable)!
                {
                    self.displayAlertForNoIntenret()
                    return
                }else{
                    //   ZVProgressHUD.show()
                    self.progressShow(true)
                }
                if objModel.is_submodel == "1"{

                   
                    self.labelNotFound.text = "Please select Variations"
                    self.labelNotFound.isHidden = false
                    self.getSubModels()
                }else{
                    self.getVariations()
                }
            }else{
                self.displayAlertWithOk(message: "Model slug not found")
            }
            tableViewProducts.reloadData()
        }
        else if tag ==  2
        {
          
                      self.arrVariationList.removeAllObjects()
                      self.arrSubVariationList.removeAllObjects()
                      self.arrDateRange.removeAllObjects()
                     self.arrWatchList.removeAllObjects()
                     
                      self.strSelectedVariation = ""
                      self.strSubVariationSlug = ""
                      self.strDateSlug = ""
            
            if self.arrWatchModels.count > 0
            {
                let objsubModel = self.arrWatchSubModels[Index] as! SubModel
                strSubModelSlug = objsubModel.ModelSlug
                subModelIndex  = Index
                if strSubModelSlug.characters.count > 0
                {
                    //self.tableViewProducts.isHidden =  true
                    let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
                    if !(reachabilityManager?.isReachable)!
                    {
                        self.displayAlertForNoIntenret()
                        return
                    }else{
                        // ZVProgressHUD.show()
                        self.progressShow(true)
                    }
                    if(objsubModel.IsSubVariation == "1")
                    {
                        self.getVariations()
                    }
                    else
                    {
                        arrWatchList.removeAllObjects()
                        self.getWatchList()
                    }
                }else{
                    self.displayAlertWithOk(message: "Model slug not found")
                }
                tableViewProducts.reloadData()
            }
        }
        else  if tag ==  3
        {
           
            self.arrSubVariationList.removeAllObjects()
            self.arrDateRange.removeAllObjects()
                                 
            self.strSubVariationSlug = ""
            self.strDateSlug = ""
            
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
                //  ZVProgressHUD.show()
                self.progressShow(true)
            }
            nPageCount = 11
            let objVariation = self.arrVariationList[Index] as! Model
            variationIndex = Index
            strSelectedVariation = objVariation.SubModel_Slug
            if(objVariation.IsSubModelVariation == "1")
            {
                self.getSubVariationModels()
                 tableViewProducts.reloadData()
            }
            else
            {
               
                self.getWatchList()
                tableViewProducts.reloadData()
            }
            
            
        }
        else if tag == 4
        {
            self.arrDateRange.removeAllObjects()
            self.strDateSlug = ""
            let objVariation = self.arrSubVariationList[Index] as! Model
            subvariationIndex = Index
            strSubVariationSlug = objVariation.SubModel_Slug
            tableViewProducts.reloadData()
            self.getWatchList()
            tableViewProducts.reloadData()
        }
    }
    func getWatchList()
    {
         var dictParams = ["":""]
                  if(strBrandID == "46")
                  {
                      if(strSubVariationSlug != "")
                      {
            dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"VariationSlug":strSelectedVariation ,"SubVariationSlug":strSubVariationSlug,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]
                      }
                      else
                      {
                          dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"VariationSlug":strSelectedVariation,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]
                      }
                      
                  }
                  else
                  {
                      dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSelectedVariation,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]
                  }
                  
        ServerRequest.sendServerRequestWithPostMethodForWatchList(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess
            {
                //                ZVProgressHUD.dismiss()
                self.progressShow(false)
                let arrResponse = response as! Array<WatchHeader>
                
                if arrResponse.count == 0 || self.nPageCount == 11{
                    var frame = CGRect.zero
                    frame.size.height = .leastNormalMagnitude
                    self.tableViewProducts.tableFooterView = UIView(frame: frame)
                }else{
                    //                    ZVProgressHUD.dismiss()
                    self.progressShow(false)
                    let footerView = UIView(frame: CGRect(x: 0, y: 0, width:  self.tableViewProducts.frame.size.width, height: 40))
                    let imageViewGIF = UIImageView(image: nil)
                    let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
                    imageViewGIF.image = gifImage
                    imageViewGIF.frame = CGRect(x: self.view.frame.size.width/2, y: 1, width: 35, height: 35)
                    footerView.addSubview(imageViewGIF)
                    self.tableViewProducts.tableFooterView = footerView
                }
                
                
                self.arrWatchList.addObjects(from: arrResponse)
                self.tableViewProducts.isHidden = false;
                
                self.tableViewProducts.reloadData()
                
                
                
                if !self.isRequiredToAnimate{
                    KConstant.APP.window?.layer.add(self.popTransition(), forKey: "kTransitionAnimation")
                }
            }
            else
            {
                //                ZVProgressHUD.dismiss()
                self.progressShow(false)
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getModels()
       {
    
           let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
           if !(reachabilityManager?.isReachable)!
           {
               self.displayAlertForNoIntenret()
               return
           }
           
           for i in 0 ..< KConstant.APP.arrBrands.count
           {
               let objBrand = KConstant.APP.arrBrands[i] as Brand
               if objBrand.BrandID == self.strBrandID
               {
                   brandIndex = i
                   break
               }
           }
           
           if strBrandID.characters.count > 0
           {
               var dictParams = NSMutableDictionary()
               dictParams = [KConstant.kMethod : "brand_models.php","id":strBrandID]
               ServerRequest.sendServerRequestWithPostMethodForRowModels(dictParam: dictParams as! Dictionary<String, String>) { (response, isSuccess) in
                   if isSuccess
                   {
                       let arrResponse = response as! Array<WatchModelRow>
                       
                       self.arrWatchModels.removeAllObjects()
                       for i in 0 ..< arrResponse.count
                       {
                           let objWatchModelRow = arrResponse[i] as WatchModelRow
                           self.arrWatchModels.add(objWatchModelRow)
                       }
                       for i in 0 ..< self.arrWatchModels.count
                       {
                           let objWatchModelRow = self.arrWatchModels[i] as! WatchModelRow
                           if objWatchModelRow.ModelSlug == self.strModelSlug
                           {
                               self.modelIndex = i
                               if objWatchModelRow.is_submodel == "1"
                               {
                                   self.getSubModels()
                               }
                               else
                               {
                                   self.getVariations()
                               }
                               
                             //  self.getAPICall()
                           }
                         self.tableViewProducts.reloadData()
                       }
                   }else{
                       print("failure\(response)")
                   }
                   
                
                   
                   //let objModel = self.arrWatchModels[self.selectedIndex] as! WatchModelRow
                   
                   if self.strSubModelValue == "1" //objModel.is_submodel == "1"
                   {
                       self.labelNotFound.isHidden = false
                       
                       if(self.strBrandID == "46")
                       {
                           
                           self.labelNotFound.text = "Please select Variations"
                       }
                       else
                       {
                           self.labelNotFound.text = "Please Choose Model Family"
                       }
                   }
                   else
                   {
                       
                   }
                   
                   
                   self.tableViewProducts.reloadData()
                   
                  
                       // ZVProgressHUD.dismiss()
                    self.progressShow(false)
                   
                 
               }
           }
       }
    
    func getSubModels()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        
        
        if strBrandID.characters.count>0 &&  strModelSlug.characters.count>0
        {
            let dictParams = [KConstant.kMethod : "brand_submodel.php","id":strBrandID,"slug":self.strModelSlug]
            
            print(dictParams)
            
            ServerRequest.sendServerRequestWithDictForSubModels(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<SubModel>
                    
                    self.arrWatchSubModels.addObjects(from: arrResponse)
                    
                    /////********************
                    for i in 0 ..< arrResponse.count
                    {
                        let objWatchSubModel = arrResponse[i] as SubModel
                        
                        if objWatchSubModel.ModelSlug == self.strSubModelSlug
                        {
                            self.subModelIndex = i
                            if(objWatchSubModel.IsSubVariation == "1")
                            {
                                self.getVariations()
                                break
                            }
                        }
                       
                    }
                    
                    //************//**/**//*/*/*/**/*/*/*/*/*/*/*//****************
                    
            
                    if(self.strBrandID == "46")
                    {
                        // self.getWatchList()
                        self.arrWatchList.removeAllObjects();
                        self.tableViewProducts.reloadData()
                    }
                    else
                    {
                        
                        self.getVariations()
                    }
                        //  ZVProgressHUD.dismiss()
                    self.progressShow(false)
                    
                }else{
                    print("failure\(response)")
                }
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getVariations()
    {
        
        if strBrandID.characters.count > 0 && (strTemp.characters.count) > 0
        {
            let dictParams = [KConstant.kMethod : "submodel_list.php","BrandId":strBrandID,"ModelSlug":strTemp]
            
            ServerRequest.sendServerRequestWithDictForModels(dictParam: dictParams ) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<Model>
                    self.arrVariationList .removeAllObjects()
                    self.arrVariationList.addObjects(from: arrResponse)
                    for i in 0 ..< self.arrVariationList.count
                    {
                        let objBrand = self.arrVariationList[i] as! Model
                        
                        if objBrand.SubModel_Slug == self.strSelectedVariation
                        {
                            self.variationIndex = i
                            
                            break
                        }
                    }
                    
                    if(self.isLoadAll == 1)
                    {
                        //                        ZVProgressHUD.dismiss()
                        self.progressShow(false)
                    }
                    else
                    {
                        self.getWatchList();
                    }
                    self.tableViewProducts.reloadData()
                }
            }
        }
    }
    func getSubVariationModels()
     {
         
         let dictParams = [KConstant.kMethod : "submodel_variation_list.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"SubVariationSlug":strSelectedVariation]
         
         ServerRequest.sendServerRequestSubVariation(dictParam: dictParams) { (response, isSuccess) in
                     if isSuccess
         {
                         let arrResponse = response as! Array<Model>
                         self.arrSubVariationList.addObjects(from: arrResponse)
          
          
                          for i in 0 ..< self.arrSubVariationList.count
                          {
                              let objVariation = self.arrSubVariationList[i] as! Model
                              
                              if(objVariation.SubModel_Slug == self.strSubVariationSlug)
                              {
                                  self.subvariationIndex = i
                                  self.getWatchList()

                                  break
                              }
                          }
                         self.tableViewProducts.reloadData()
                     }else{
                         print("failure\(response)")
                     }
                     self.progressShow(false) // ProgressHUD.dismiss()
         }
      
    
         
        
     }
    
    
    
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func buttonClicked(sender: UIButton) {
        
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        
        let objWatchHeader = self.arrWatchList[(indexPath.section)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        
        objAskAQuestionViewController.strOption = "AskQuestion"
        objAskAQuestionViewController.strTitle = "Ask a Question"
        objAskAQuestionViewController.dictOption =  dictOption
        
        objAskAQuestionViewController.strBrandName =  objWatchHeader.BrandName ?? "BrandName"
        
        objAskAQuestionViewController.objWatchList =  objWatchList
        objAskAQuestionViewController.isFromMultiple = true
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    
    
    func relaodAllScreen(section:Int,indexPath:Int)
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        isLoadAll = 1;
        
        let objWatchHeader = self.arrWatchList[section] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[indexPath] as WatchList
        self.strItemID = objWatchList.ItemID
        
        
        
        imageWatch.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        imageWatch.layer.borderWidth =  0.6
        // self.automaticallyAdjustsScrollViewInsets = false;
        //  mainScrollView.isDirectionalLockEnabled = true
        
        //        ZVProgressHUD.show()
        self.progressShow(true)
        // labelNotFound.isHidden = true
        self.callAllApi()
        self.arrWatchList.removeAllObjects()
        tableViewProducts.reloadData()
        self.tableViewProducts.delegate = self
        self.tableViewProducts.dataSource = self
        
        KConstant.APP.window?.layer.add(self.pushTransition(), forKey: "kTransitionAnimation")
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func buttonBuyNowClicked(sender: UIButton)
    {
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let objWatchHeader = self.arrWatchList[(indexPath.section)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        
        if objWatchList.InStock == "1"
        {
            objAskAQuestionViewController.strOption = "Purchase"
            objAskAQuestionViewController.strTitle = "Buy Now"
        }else{
            objAskAQuestionViewController.strOption = "HaveUsSearch"
            objAskAQuestionViewController.strTitle = "Have us search for it"
        }
        objAskAQuestionViewController.strBrandName =  objWatchHeader.BrandName ?? "BrandName"
        objAskAQuestionViewController.objWatchList =  objWatchList
        objAskAQuestionViewController.isFromMultiple = true
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonImageClicked(sender: UIButton)
    {
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let objWatchHeader = self.arrWatchList[(indexPath.section)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        KConstant.APP.strProductName = objWatchList.Name
        
        if objWatchList.Image_full.characters.count > 0
        {
            let slider = ZoomableImageSlider(images:  [(objWatchList.Image_full)], currentIndex: 0, placeHolderImage: nil)
            self.present(slider, animated: true, completion: nil)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func backButtonClicked() {
        //        UIView.animate(withDuration: 0.75, animations: {() -> Void in
        //            UIView.setAnimationCurve(.easeInOut)
        //            UIView.setAnimationTransition(.flipFromLeft, for: (self.navigationController?.view)!, cache: false)
        //        })
        navigationController?.popViewController(animated: true)
        
        if self.isRequiedCubeAnimation {
            KConstant.APP.window?.layer.add(self.popTransition(), forKey: "kTransitionAnimation")
        }
    }
    
    
    
    // ------------------------------------------------------------------------------------------------------------------
    /*
     */
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITableView Deleagate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        if(section>=6)
        {
            let viewHeader = UIView(frame: CGRect(x: 0, y: -20, width: tableView.frame.size.width, height: 43))
            let labelHeaderTitle = UILabel(frame: CGRect(x: 10, y: 0, width:tableView.frame.size.width-20, height: 43))
            viewHeader.backgroundColor = UIColor.clear
            labelHeaderTitle.numberOfLines = 0
            labelHeaderTitle.adjustsFontSizeToFitWidth = true
            labelHeaderTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 15)
            
            let objWatchHeader = self.arrWatchList[section-6] as! WatchHeader
            labelHeaderTitle.text =  objWatchHeader.CategoryName
            viewHeader.backgroundColor = UIColor.init(red: 0.8667, green: 0.8667, blue: 0.8667, alpha: 1)
            viewHeader.addSubview(labelHeaderTitle)
            return viewHeader
        }
        else
        {
            if(arrWatchSubModels.count == 0 && section == 2)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(KConstant.APP.arrBrands.count == 0 && section == 0)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrWatchModels.count == 0 && section == 1)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrVariationList.count == 0 && section == 3)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrSubVariationList.count == 0 && section == 4)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            else if(arrDateRange.count == 0 && section == 5)
            {
                return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
            }
            
            let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 20))
            let labelHeaderTitle = UILabel(frame: CGRect(x: 10, y: 0, width:tableView.frame.size.width-20, height: 20))
            viewHeader.backgroundColor = UIColor.lightGray.withAlphaComponent(0.1)
            labelHeaderTitle.numberOfLines = 0
            labelHeaderTitle.adjustsFontSizeToFitWidth = true
            labelHeaderTitle.font = UIFont(name: KConstant.kFontOpenSenseSemibold, size: 12)
            if(section == 0)
            {
                labelHeaderTitle.text =  "Brand"
            }
            else if(section == 1)
            {
                labelHeaderTitle.text =  "Model"
            }
            else if(section == 2)
            {
                labelHeaderTitle.text =  "SubModel"
            }
            else if(section == 3)
            {
                labelHeaderTitle.text =  "Variation of the" + (strModelSlug as String)
            }
            else if(section == 4)
            {
                labelHeaderTitle.text =  " Sub Variation"
            }
            else if(section == 5)
            {
                labelHeaderTitle.text =  "Date Range"
            }
            labelHeaderTitle.textColor = UIColor.black
            viewHeader.addSubview(labelHeaderTitle)
            
            
            return viewHeader
        }
        return  UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        //  return UIView.new
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if(section<6)
        {
            
            if(arrWatchSubModels.count == 0 && section == 2)
            {
                return 0.05
            }
            else if(KConstant.APP.arrBrands.count == 0 && section == 0)
            {
                return 0.05
            }
            else if(arrWatchModels.count == 0 && section == 1)
            {
                return 0.05
            }
            else if(arrVariationList.count == 0 && section == 3)
            {
                return 0.05
            }
            else if(arrSubVariationList.count == 0 && section == 4)
            {
                return 0.05
            }
            else if(arrDateRange.count == 0 && section == 5)
            {
                return 0.05
            }
            return 20
        }
        return 44
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(section < 6)
        {
            if(arrWatchSubModels.count == 0 && section == 2)
            {
                return 0
            }
            else if(KConstant.APP.arrBrands.count == 0 && section == 0)
            {
                return 0
            }
            else if(arrWatchModels.count == 0 && section == 1)
            {
                return 0
            }
            else if(arrVariationList.count == 0 && section == 3)
            {
                return 0
            }
            else if(arrSubVariationList.count == 0 && section == 4)
            {
                return 0
            }
            else if(arrDateRange.count == 0 && section == 5)
            {
                return 0
            }
            return 1
        }
        let objWatchList = self.arrWatchList[section-6] as! WatchHeader
        return objWatchList.Product.count
        // }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return self.arrWatchList.count+6
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if(indexPath.section < 6)
        {
            if(arrWatchSubModels.count == 0 && indexPath.section == 2)
            {
                return 0
            }
            return 32
        }
        
        if self.arrWatchList.count > 0
        {
            
            let objWatchHeader = self.arrWatchList[indexPath.section-6] as! WatchHeader
            
            let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
            
            let strCondition = "\(objWatchList.condition )" as String
            
            var nHeight = 21 as Int
            
            if strCondition.characters.count > 0 {
                nHeight = 0
            }
            
            return CGFloat(232 - nHeight) // 288
        }
        return 2 // 288
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if(arrWatchSubModels.count == 0 && section == 2)
        {
            return 0.05
        }
        else if(KConstant.APP.arrBrands.count == 0 && section == 0)
        {
            return 0.05
        }
        else if(arrWatchModels.count == 0 && section == 1)
        {
            return 0.05
        }
        else if(arrVariationList.count == 0 && section == 3)
        {
            return 0.05
        }
        else if(arrSubVariationList.count == 0 && section == 4)
        {
            return 0.05
        }
        else if(arrDateRange.count == 0 && section == 5)
        {
            return 0.05
        }
        return 5;
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        if(arrWatchSubModels.count == 0 && section == 2)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(KConstant.APP.arrBrands.count == 0 && section == 0)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrWatchModels.count == 0 && section == 1)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrVariationList.count == 0 && section == 3)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrSubVariationList.count == 0 && section == 4)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        else if(arrDateRange.count == 0 && section == 5)
        {
            return UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 0))
        }
        let viewFooter = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 5))
        viewFooter.backgroundColor = UIColor.lightGray.withAlphaComponent(0.1)
        return viewFooter
    }
    
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        self.relaodAllScreen(section: indexPath.section-6, indexPath: indexPath.row)
        
        Analytics.logEvent("Product_Detail_Screen", parameters: [
            "name": "Product Detail Screen" as NSObject,
        ])
        
        
        //        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
        //        tracker.set(kGAIScreenName, value: "Product Detail Screen")
        //
        //        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
        //        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: -  UITableView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
       
        if(indexPath.section < 6)
        {
            let cell : Collection = tableView.dequeueReusableCell(withIdentifier: "Collection", for: indexPath) as! Collection
            cell.contentView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.1)
            cell.CollectionView.backgroundColor = UIColor.clear
            cell.backgroundColor = UIColor.clear
            cell.CollectionView.tag = indexPath.section
            cell.collectioDelegate = self
            if(indexPath.section == 0)
            {
                cell.arrayData = KConstant.APP.arrBrands as NSArray
                cell.strBrandID = self.strBrandID as NSString
                cell.CollectionView.reloadData()
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.brandIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 1)
            {
                cell.arrayData = arrWatchModels as NSArray
                cell.strModelName = self.strModelSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.modelIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 2)
            {
                cell.arrayData = self.arrWatchSubModels as NSArray
                cell.strSubModelSlag = self.strSubModelSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.subModelIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 3)
            {
                cell.arrayData = arrVariationList as NSArray
                cell.strVariation = strSelectedVariation as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.variationIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 4)
            {
                cell.arrayData =  arrSubVariationList as NSArray
                cell.strSubVariation = strSubVariationSlug as NSString
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.subvariationIndex, section: 0), at: .left, animated: true)
            }
            else if(indexPath.section == 5)
            {
                cell.arrayData = arrDateRange as NSArray
                cell.CollectionView.scrollToItem(at:IndexPath(item: self.dateRangeIndex, section: 0), at: .left, animated: true)
            }
            cell.CollectionView.reloadData()
            return cell
        }
        else
        {
            let cell : SearchCell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath ) as! SearchCell
            if self.arrWatchList.count > 0
            {
                let objWatchHeader = self.arrWatchList[indexPath.section-6] as! WatchHeader
                let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
                cell.labelName.text = objWatchList.Name+" "+objWatchList.Subtext
                cell.labelName2.text  = objWatchList.ShortDesc.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
                cell.labelName2.isHidden = true;
                cell.labelRef.text =  "Ref - "+objWatchList.ModelNumber
                cell.labelItemID.text = "Item Id - "+objWatchList.ItemID
                cell.labelRetailPrice.text =  "\(objWatchList.Retail_Lable ?? "")"+"\(objWatchList.RetailPrice ?? "")"
                cell.labelCase.text =  "Case - " + objWatchList.Case
                cell.labelSize.text =  "Size - " + "\(objWatchList.CaseSize ?? "")"
                cell.labelDial.text =  "Dial - " + objWatchList.Dial
                
                self.setAdjustableLabel(label:  cell.labelCondition)
                
                let url = URL(string: objWatchList.Image)!
                let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
                
                cell.imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
                
                var strCondition = "\(objWatchList.condition )" as String
                
                if strCondition.characters.count > 0
                {
                    cell.labelCondition.text =  "CONDITION - "+strCondition
                    cell.layoutConstraintConditionHeight.constant = 21
                }else{
                    cell.labelCondition.text = ""
                    cell.layoutConstraintConditionHeight.constant = 0
                }
                
                if (cell.labelRetailPrice.text?.characters.count)! == 0 {
                    cell.labelYourPriceOnly.isHidden = false
                }else{
                    cell.labelYourPriceOnly.isHidden = true
                }
                
                cell.buttonAskQuestion.tag = indexPath.row
                cell.buttonAskQuestion.addTarget(self, action: #selector(buttonClicked(sender:)), for: .touchUpInside)
                
                cell.buttonBuyNow.tag = indexPath.row
                cell.buttonBuyNow.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)
                
                cell.buttonImage.isHidden = true
                
                
                if indexPath.section == 0 && indexPath.row == 0
                {
                    cell.viewTopLine.isHidden = true
                }else {
                    cell.viewTopLine.isHidden = false
                }
                
                if objWatchList.InStock == "1"
                {
                    cell.labelYourPrice.text = "Your Price - "+objWatchList.YourPrice
                    cell.buttonBuyNow.setTitle("Buy Now", for: .normal)
                    cell.buttonBuyNow.backgroundColor = KConstant.kColorThemeYellow
                    cell.buttonBuyNow.setTitleColor(UIColor.white, for: .normal)
                }
                else
                {
                    cell.labelYourPrice.text = ""
                    cell.buttonBuyNow.setTitle("Have us find this watch", for: .normal)
                    cell.buttonBuyNow.backgroundColor = UIColor.white
                    cell.buttonBuyNow.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                    cell.buttonBuyNow.setTitleColor(UIColor.black, for: .normal)
                }
                
                //            cell.layoputConstraintViewMainTopSpace.constant = -1
                
                cell.labelYourPriceOnly.text = cell.labelYourPrice.text
                
                cell.buttonBuyNow.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                cell.buttonBuyNow.layer.borderWidth = 1.0
                cell.buttonAskQuestion.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                cell.buttonAskQuestion.layer.borderWidth = 1.0
                cell.layoutConstraintViewBottomTopLineHeight.constant = 1.0
            }
            return cell
        }
        let cell : Collection = tableView.dequeueReusableCell(withIdentifier: "Collection", for: indexPath) as! Collection
        return cell
    }
    
    
    
    
    
    
    
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        
        
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        self.isRequiredToAnimate = true
        if scrollOffset == 0 {
            
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
            //            if nPageCount > 11 {
            nPageCount = nPageCount + 12
            self.getWatchList()
            //            }
        }
    }
    
}

extension ProductDetailsViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if(objSearch?.arrextraimgs?.count != nil)
        {
            if collectionView == collection_viewMain
            {
                return (objSearch?.arrextraimgs?.count)!
            }
            else if collectionView == collection_viewsmall
            {
                
                return (objSearch?.arrextraimgs?.count)!
            }
            else{
                return self.arrSimilarProducts.count
            }
        }
        else{
            return self.arrSimilarProducts.count
        }
        return 0
        
        //        else
        //        {
        //            return 0;
        //        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if collectionView == collection_viewMain
        {
            return CGSize(width: UIScreen.main.bounds.size.width, height: collection_viewMain.frame.size.height)
        }
        else if collectionView == collection_viewsmall {
            return CGSize(width: 80, height: 80)
        }
        else{
            if KConstant.IS_IPHONE5 {
                return CGSize(width: 100, height: collectionView.frame.size.height-80)
            }else{
                //6 -- 120
                return CGSize(width: 123, height: collectionView.frame.size.height)
            }
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        if collectionView == collection_viewMain
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "celllarge", for: indexPath) as! customcellLarge
            
            //String(format: "%@%@",objSearch?.img_url!,objSearch?.arrextraimgs[indexPath.ro] )
            let strurl = String(format: "%@%@",(objSearch?.img_url!)!,(objSearch?.arrextraimgs![indexPath.row])! )
            let url = URL(string: strurl)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            cell.imgv.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            return cell
        }
        else if collectionView == collection_viewsmall
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellsmall", for: indexPath) as! customcellSmall
            let strurl = String(format: "%@%@",(objSearch?.img_url!)!,(objSearch?.arrextraimgs![indexPath.row])! )
            let url = URL(string: strurl)!
            cell.vw_selcted.layer.borderColor = KConstant.kColorThemeYellow.cgColor
            cell.vw_selcted.layer.borderWidth = 1.0
            if selectedindex == indexPath.row
            {
                cell.vw_selcted.isHidden=false
            }
            else{
                cell.vw_selcted.isHidden=true
            }
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            cell.imgv.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            return cell
        }
        else{
            let cell: BrandsCell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrandsCell", for: indexPath as IndexPath) as! BrandsCell
            let objSimilarWatch : SimilarWatch = self.arrSimilarProducts[indexPath.item] as SimilarWatch
            print(objSimilarWatch);
            
            let url = URL(string: objSimilarWatch.Image)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            //        cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            
            
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if collectionView == collection_viewsmall
        {
            
            let totalCellWidth = 80 * collection_viewsmall.numberOfItems(inSection: 0)
            //        let totalSpacingWidth = 10 * (collection_viewsmall.numberOfItems(inSection: 0) - 1)
            let totalSpacingWidth = 0
            let leftInset = (collection_viewsmall.layer.frame.size.width - CGFloat(totalCellWidth + totalSpacingWidth)) / 2
            let rightInset = leftInset
            
            return UIEdgeInsets(top: 0, left: leftInset, bottom: 0, right: rightInset)
        }
        else{
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        
        if collectionView == collection_viewMain
        {
            let gallry_vc = self.storyboard?.instantiateViewController(withIdentifier: "GallaryVC") as! GallaryVC
            gallry_vc.arrextraimg = self.objSearch?.arrextraimgs
            gallry_vc.img_url = self.objSearch?.img_url
            gallry_vc.selectedIndex = indexPath.row
            self.navigationController?.pushViewController(gallry_vc, animated: true)
        }
        else if collectionView == collection_viewsmall
        {
            selectedindex = indexPath.row
            collection_viewMain.scrollToItem(at: IndexPath(row: indexPath.row, section: 0), at: .left, animated: true)
            collection_viewsmall.reloadData()
        }
        else{
            let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
            //        let objWatchHeader = self.arrWatchList[indexPath.section] as! WatchHeader
            //        let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
            
            let objSimilarWatch : SimilarWatch = self.arrSimilarProducts[indexPath.item] as SimilarWatch
            objProductDetailsViewController.strItemID = objSimilarWatch.itemid
            
            self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
            
            //        self.getProductInfo()
            //        self.getSimilarProducts(strItemID: strItemID)
        }
        
    }
}

