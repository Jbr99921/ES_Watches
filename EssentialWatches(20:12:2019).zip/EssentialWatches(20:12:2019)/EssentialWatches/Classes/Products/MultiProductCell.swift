//
//  MultiProductCell.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class MultiProductCell: UITableViewCell {

    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var viewBottom: UIView!
    @IBOutlet weak var labelCase: UILabel!
    @IBOutlet weak var labelDial: UILabel!
    @IBOutlet weak var labelBracelet: UILabel!
    @IBOutlet weak var labelCaseSize: UILabel!
    @IBOutlet weak var labelMovement: UILabel!
    @IBOutlet weak var labelCondition: UILabel!
    @IBOutlet weak var labelRetailPrice: UILabel!
    @IBOutlet weak var labelYourPrice: UILabel!
    @IBOutlet weak var imageViewWatch: UIImageView!
    @IBOutlet weak var buttonAskQuestion: UIButton!

    @IBOutlet weak var viewName: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        viewName.layer.borderColor = UIColor.lightGray.cgColor
        viewName.layer.borderWidth = 0.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
