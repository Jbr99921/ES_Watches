//
//  customcellSmall.swift
//  EssentialWatches
//
//  Created by Apple on 23/07/18.
//  Copyright © 2018 MSP. All rights reserved.
//

import UIKit

class customcellSmall: UICollectionViewCell {
    
    @IBOutlet weak var vw_selcted: UIView!
    @IBOutlet weak var imgv: UIImageView!
}
