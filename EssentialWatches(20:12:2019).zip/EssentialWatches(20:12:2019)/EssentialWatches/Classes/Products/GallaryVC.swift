//
//  GallaryVC.swift
//  GlobalTributes
//
//  Created by MSPSYS061 on 06/02/18.
//  Copyright © 2018 Dan. All rights reserved.
//

import UIKit
import SDWebImage
class GallaryVC: BaseViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout,UIGestureRecognizerDelegate,UIScrollViewDelegate {
    var selectedIndex:Int!
  
    var flowLayout:UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    @IBOutlet var collectionViewBig: UICollectionView!
    @IBOutlet var collectionViewSmall: UICollectionView!
  
    var firstTime=1
    var arrextraimg:[String]!
    var img_url:String!
    override func viewDidLoad() {
        super.viewDidLoad()
        firstTime=1
       
        
        
        self.setTitleLabel(title: "Watch Details")
       
        
        self.viewHeader.buttonLogo.isHidden = true
        self.viewHeader.labelTitle.isHidden = true
        self.viewHeader.imageViewMiddleIcon.isHidden = false
        self.viewHeader.buttonMiddle.isHidden = false
        
        
        
        self.showHeaderLogo()
        
       
        collectionViewBig.isUserInteractionEnabled = true
        let pinchGest = UIPinchGestureRecognizer(target: self, action: #selector(pinchClick(_:)))
        pinchGest.delegate=self
      
      
    }

    
    
    override func viewWillAppear(_ animated: Bool) {
       // collectionViewBig.reloadData()
       
    collectionViewBig.scrollToItem(at: IndexPath(row: selectedIndex, section: 0), at: .left, animated: false)
   
    }
    override func viewDidLayoutSubviews() {
       
    }
    override func viewDidAppear(_ animated: Bool) {
        
}
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        
        
           return arrextraimg.count
        
    }
    
    // The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
    @available(iOS 6.0, *)
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        if collectionView==collectionViewSmall
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cells", for: indexPath) as! customCellSmall2
        
            let strurl = String(format: "%@%@",img_url,arrextraimg[indexPath.row] )
            let url = URL(string: strurl)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            cell.imgvs.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            cell.viewborder.layer.borderColor = KConstant.kColorThemeYellow.cgColor
            cell.viewborder.layer.borderWidth = 1.0
            if indexPath.row==selectedIndex
            {cell.viewborder.isHidden=false
                
            }
            else{
              cell.viewborder.isHidden=true
            }
            
           return cell
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellb", for: indexPath) as! customCellBig
            cell.scroll_view.zoomScale=1
           
            let strurl = String(format: "%@%@",img_url,arrextraimg[indexPath.row] )
            let url = URL(string: strurl)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            
            
            
                
               // cell.imgvb.sd_setImage(with: URL(string: arrDeatailTribute["photo1"].string!), placeholderImage: UIImage(named: "gtbanner"))
                cell.imgvScroll.isHidden=true
                cell.imgvb.isHidden=false
                
                 
                cell.imgvb.sd_setImage(with: url, placeholderImage: placeholderImage,  completed: { (image, error, cacheType, imageURL) in
                    cell.imgvScroll.isHidden=false
                    cell.imgvb.isHidden=true
                    cell.imgvScroll.display(image: image!)
            cell.imgvScroll.frame=CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height-210)
                })
               
            
           
            cell.layoutIfNeeded()
        
            
            return cell
        }
        
    }
func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
{
    if collectionView==collectionViewBig {
        return CGSize(width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height-210)
    }
    return CGSize(width: 80, height: 80)
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
    {
        print(indexPath.row)
        if firstTime==1 {
             collectionViewBig.scrollToItem(at: IndexPath(row: selectedIndex, section: 0), at: .left, animated: false)
            firstTime=2
        }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if collectionView==collectionViewSmall
        {
//            for i in 0..<totalImg
//            {
//
//                let cell:customCellSmall=collectionViewSmall.cellForItem(at: IndexPath(row: i, section: 0)) as! customCellSmall
//                cell.viewborder.isHidden=true
//
//            }
            let cell:customCellSmall2=collectionViewSmall.cellForItem(at: indexPath) as! customCellSmall2
            cell.viewborder.isHidden=false
            
            selectedIndex=indexPath.row
            
            
          collectionViewBig.scrollToItem(at: IndexPath(row: indexPath.row, section: 0), at: .left, animated: true)
        collectionViewSmall.reloadData()
        }
    }
    //MARK: - Pinch on image
    @objc func pinchClick(_ gest:UIPinchGestureRecognizer)
    {
      
            let touch:CGPoint = gest.location(in: collectionViewBig)
            let indexpath=collectionViewBig.indexPathForItem(at: touch)
            print(indexpath?.row)
            print(TMImageZoom.shared().isHandlingGesture)
            if indexpath != nil
            {
                let cell:customCellBig=collectionViewBig.cellForItem(at: indexpath!) as! customCellBig
                
                
                TMImageZoom.shared().gestureStateChanged(gest, withZoom: cell.imgvb)
            }
            else{
                //                TMImageZoom.shared().isHandlingGesture
               // TMImageZoom.shared().resetImageZoom()
                
            }
        
    }
//    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
//        if let indexPath = collectionViewBig.indexPathsForVisibleItems.first {
//           print(indexPath.row)
//            for i in 0..<totalImg
//            {
//
//                let cell:customCellSmall=collectionViewSmall.cellForItem(at: IndexPath(row: i, section: 0)) as! customCellSmall
//                cell.viewborder.isHidden=true
//
//            }
//            let cell:customCellSmall=collectionViewSmall.cellForItem(at: IndexPath(row: indexPath.row, section: 0)) as! customCellSmall
//            cell.viewborder.isHidden=false
//            cell.viewborder.layer.borderColor=UIColor.blue.cgColor
//            cell.viewborder.layer.borderWidth=3
//            cell.viewborder.layer.masksToBounds=true
//            selectedIndex=indexPath.row
//        }
//    }
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//       // let center = CGPoint(x: collectionViewBig.contentOffset.x + (collectionViewBig.frame.width / 2), y: (collectionViewBig.frame.height / 2))
//        
//        
//        
//    }
    //func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
   // {
//        let currentIndex:Int = Int(collectionViewBig.contentOffset.x / collectionViewBig.frame.size.width)
//
//        let indexPath = IndexPath(row: currentIndex, section: 0)
//
//
//
//
//        for i in 0..<totalImg-1
//        {
//
//            let cell:customCellSmall=collectionViewSmall.cellForItem(at: IndexPath(row: i, section: 0)) as! customCellSmall
//            cell.viewborder.isHidden=true
//
//        }
//        let cell:customCellSmall=collectionViewSmall.cellForItem(at: IndexPath(row: indexPath.row, section: 0)) as! customCellSmall
//        cell.viewborder.isHidden=false
//        cell.viewborder.layer.borderColor=UIColor.blue.cgColor
//        cell.viewborder.layer.borderWidth=3
//        cell.viewborder.layer.masksToBounds=true
//        selectedIndex=indexPath.row
   // }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        if scrollView==collectionViewBig
        {
            let currentIndex:Int = Int(collectionViewBig.contentOffset.x / collectionViewBig.frame.size.width)
            
            let indexPath = IndexPath(row: currentIndex, section: 0)
            
            selectedIndex=indexPath.row
            
            
            
           
            collectionViewSmall.reloadData()
            //   self.getMediaData()
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
