//
//  RequestViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire
import Firebase

class RequestViewController: BaseViewController, UITextViewDelegate {
    
    @IBOutlet weak var txtItemID: ECW_TextField!
    @IBOutlet weak var txtBrandName: ECW_TextField!
    @IBOutlet weak var txtModelName: ECW_TextField!
    @IBOutlet weak var txtHowOldIsIt: ECW_TextField!
    @IBOutlet weak var txtItHaveBoxPaper: ECW_TextField!
    @IBOutlet weak var txtTypeMetal: ECW_TextField!
    @IBOutlet weak var txtDialColor: ECW_TextField!
    @IBOutlet weak var txtFullName: ECW_TextField!
    @IBOutlet weak var txtEmailID: ECW_TextField!
    @IBOutlet weak var txtPhoneNumber: ECW_TextField!
    
    @IBOutlet weak var txtViewQuestion: UITextView!
    @IBOutlet weak var imgForWatch: UIImageView!
    @IBOutlet weak var lblNamePrice: UILabel!
    @IBOutlet weak var btnSubmit: UIButton!
    
    @IBOutlet var btnBrand: UIButton!
    @IBOutlet weak var txtHowDoYouCommunicate: ECW_TextField!
    @IBOutlet weak var scrollViewRequestTrade: TPKeyboardAvoidingScrollView!
    
    @IBOutlet weak var imageViewWatch: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelBrandTitle: UILabel!
    @IBOutlet weak var labelSubText: UILabel!
    
    @IBOutlet weak var layoutConstraintViewInfoTopSpace: NSLayoutConstraint!

    
    var arrPickerData = ["010"]
    var arrCommunicate = ["Either","Phone","Email"]
    var dictOption  = [String : AnyObject]()

    var objSearch : Search? = nil

    var isBrandSelected : Bool = false
    var isHiddenKeyboard : Bool = false
    
    var isReachedToPhone : Bool = false
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.txtViewQuestion.layer.borderColor = UIColor.lightGray.cgColor
        self.txtViewQuestion.layer.borderWidth = 0.5
        self.setTitleLabel(title: "Request a Trade")
        
        txtViewQuestion.isEditable = true
        txtViewQuestion.isUserInteractionEnabled = true
        
        if KConstant.IS_IPHONE_X{
            layoutConstraintViewInfoTopSpace.constant = 86
        }
        self.getBrands()
        
         let center = NotificationCenter.default
        center.addObserver(self,selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
 
    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool)
    {

        
        Analytics.logEvent("Request_A_Trade_Screen", parameters: [
            "name": "Request a Trade Screen" as NSObject,
            ])
        
        
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Request a Trade Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
        
        let url = URL(string: (objSearch?.Image)!)!
        let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//        imageViewWatch.af_setImage(withURL: url, placeholderImage: placeholderImage)
        imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

        labelName.text = (objSearch?.BrandName)! + "\n" + (objSearch?.Name)!
        labelSubText.text = objSearch?.SubText
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
            txtFullName.text =  "\(dictTemp?.value(forKey:KConstant.kFirstName) ?? "")" + " " + "\(dictTemp?.value(forKey:KConstant.kLastName) ?? "")"
            txtPhoneNumber.text = dictTemp?.value(forKey:KConstant.kMobileNum) as? String
            txtEmailID.text = dictTemp?.value(forKey:KConstant.kEmail) as? String
        }
    }

    // ------------------------------------------------------------------------------------------------------------------
    override func viewDidLayoutSubviews() {
        //layoutConstraintInfoViewHeight.constant =  70
        // if iPhone6+ then 400
    //    if KConstant.IS_IPHONE5 {
        
        var nExtraBefore = 1150 as CGFloat
        let nExtraAfter = 850 as CGFloat
        
        if KConstant.IS_IPHONE5 {
            nExtraBefore = 1200
        }
            if isHiddenKeyboard {
                self.scrollViewRequestTrade.contentSize = CGSize(width: self.scrollViewRequestTrade.frame.size.width, height: nExtraAfter)
            }else{
                self.scrollViewRequestTrade.contentSize = CGSize(width: self.scrollViewRequestTrade.frame.size.width, height: nExtraBefore)
            }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func sendRequestATrade()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        
        let strItemId:String = txtItemID.text!
        let strBrandname = txtBrandName.text//txtBrandName.text!
        let strModelName = txtModelName.text!
        let strage =             txtHowOldIsIt.text!
        let strBoxPaper =    txtItHaveBoxPaper.text!
        let strMetalType =  txtTypeMetal.text!
        let strDialColor =    txtDialColor.text!
        let strQuestion =     txtViewQuestion.text!
        let strFullName =    txtFullName.text!
        let strPhoneNumber = txtPhoneNumber.text!
        let strEmailId = txtEmailID.text!
        let strCommunicationType = txtHowDoYouCommunicate.text!
        
        let dict1 = [KConstant.kMethod : "request_a_trade.php","type":"RequestaTrade","itemid":strItemId,"brand":objSearch?.BrandName,"model":strModelName,"age":strage,"boxpaper":strBoxPaper,"metaltype":strMetalType,"dialcolor":strDialColor,"question":strQuestion,"fullname":strFullName,"phone":strPhoneNumber,"email":strEmailId,"communicationtype":strCommunicationType,"devicetype":"ios"] ;
        
         self.progressShow(true) //ProgressHUD.show()

        ServerRequest.sendPostRequestWithDict(dictParam: dict1 as! Dictionary<String, String>) { (response, isSuccess) in
            let dictRes = response as! NSDictionary
            let msg = dictRes["message"] as! String

            if isSuccess {
                self.displayAlertWithWithPopViewController(message:msg)
//                print("Suuccess\(response)")
            }else{
                print("failure\(response)")
                self.displayAlertWithOk(message: msg)
            }
            self.progressShow(false) // ProgressHUD.dismiss()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func resignTextFields() {
         txtItemID.resignFirstResponder()
        txtModelName.resignFirstResponder()
        txtHowOldIsIt.resignFirstResponder()
        txtItHaveBoxPaper.resignFirstResponder()
        txtTypeMetal.resignFirstResponder()
        txtDialColor.resignFirstResponder()
        txtFullName.resignFirstResponder()
        txtPhoneNumber.resignFirstResponder()
        txtEmailID.resignFirstResponder()
        txtHowDoYouCommunicate.resignFirstResponder()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func getBrands()
    {
          var arrTemp = ["010"]
          
          for i in 0 ..< KConstant.APP.arrBrands.count {
              let objBrand = KConstant.APP.arrBrands[i] as Brand
              arrTemp.append(objBrand.BrandName)
          }
          
          arrTemp.remove(at: 0)
          self.arrPickerData = arrTemp
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @objc func keyboardWillHide(notification: NSNotification)
    {
        isHiddenKeyboard = true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func btnBrandClicked(_ sender: Any)
    {
        self.resignTextFields()

        if KConstant.APP.arrBrands.count > 0
        {
            isBrandSelected = true
            self.resignTextFields()
//            let picker: SBPickerSelector = SBPickerSelector()
//            picker.pickerData =  arrPickerData//picker content
//            picker.delegate = self
//            picker.pickerType = .text
//            picker.doneButtonTitle = "Done"
//            picker.cancelButtonTitle = "Cancel"
//            picker.showPicker(from: self.view, in: self)
            
            SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:arrPickerData, defaultDate: Date()).cancel {
                
                }.set { values in
                    if let values = values as? [Brand]
                    {
                        
                       let objBrand : Brand = values[0] as Brand
                        self.txtBrandName.text = objBrand.BrandName
                    }

            }.present(into: self)
            
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func btnCommunicateClicked(_ sender: Any) {
        self.resignTextFields()
        
        if self.arrCommunicate.count > 0
        {
            isBrandSelected = false
//            self.resignTextFields()
//            let picker: SBPickerSelector = SBPickerSelector()
//            picker.pickerData =  self.arrCommunicate//picker content
//            picker.delegate = self
//            picker.pickerType = .text
//            picker.doneButtonTitle = "Done"
//            picker.cancelButtonTitle = "Cancel"
//            picker.showPicker(from: self.view, in: self)
            
            SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:self.arrCommunicate, defaultDate: Date()).cancel {
                           
                           }.set { values in
                               if let values = values as? [String]
                               {
                                self.txtHowDoYouCommunicate.text = values[0]
                               }

                       }.present(into: self)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonSubmitClicked(_ sender: Any) {
        
        self.resignTextFields()
        
        if txtItemID.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter item ID.")
            return
        }
        
        if txtModelName.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter model name/number.")
            return
        }
        
        if txtHowOldIsIt.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter how old is it.")
            return
        }
        
        if txtItHaveBoxPaper.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter does it have box/papers?")
            return
        }
        
        if txtTypeMetal.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter type of metal")
            return
        }
        
        if txtDialColor.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter dial color")
            return
        }
        
        if txtViewQuestion.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter your questions")
            return
        }
        
        if txtFullName.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter full name")
            return
        }
        
        if txtEmailID.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter email")
            return
        }
        
        if self.validateEmail(strEmail: txtEmailID.text!) == false{
            self.displayAlertWithOk(message: "Please enter valid mail")
        }
        
        if txtPhoneNumber.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter phone number.")
            return
        }
        
        if txtHowDoYouCommunicate.text?.characters.count == 0 {
            self.displayAlertWithOk(message: "Please enter your preference.")
            return
        }
        
        let fullName: String = txtFullName.text!
        var fullNameArr = fullName.components(separatedBy: " ")
        let firstName: String = fullNameArr[0]
        let lastName: String? = fullNameArr.count > 1 ? fullNameArr[1] : nil
        let dict:NSDictionary = [KConstant.kFirstName: firstName, KConstant.kLastName: lastName ?? "", KConstant.kMobileNum : txtPhoneNumber.text ?? "", KConstant.kEmail : txtEmailID.text ?? ""]
        KConstant.APP.saveValueInUserDefault(dict: dict)
        self.sendRequestATrade()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------
    
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        /*
         txtItemID.resignFirstResponder()
         txtModelName.resignFirstResponder()
         txtHowOldIsIt.resignFirstResponder()
         txtItHaveBoxPaper.resignFirstResponder()
         txtTypeMetal.resignFirstResponder()
         txtDialColor.resignFirstResponder()
         txtFullName.resignFirstResponder()
         txtPhoneNumber.resignFirstResponder()
         txtEmailID.resignFirstResponder()
         txtHowDoYouCommunicate.resignFirstResponder()
 */
        
        if textField == txtItemID {
            txtModelName.becomeFirstResponder()
        }else  if textField == txtModelName {
             txtHowOldIsIt.becomeFirstResponder()
        }else  if textField ==  txtHowOldIsIt {
             txtItHaveBoxPaper.becomeFirstResponder()
        }else  if textField ==  txtItHaveBoxPaper {
             txtTypeMetal.becomeFirstResponder()
        }else  if textField ==  txtTypeMetal {
             txtDialColor.becomeFirstResponder()
        }else  if textField ==  txtDialColor {
            txtViewQuestion.becomeFirstResponder()
        }else  if textField ==  txtFullName {
            txtEmailID.becomeFirstResponder()
        }else  if textField ==  txtEmailID {
            isReachedToPhone = true
             txtPhoneNumber.becomeFirstResponder()
        }else  if textField ==   txtPhoneNumber {
            textField.resignFirstResponder()
        }
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    {
        isHiddenKeyboard = false
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - SBPickerSelector  Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
//    func pickerSelector(_ selector: SBPickerSelector, selectedValues values: [String], atIndexes idxs: [NSNumber]){
//        let m = idxs[0] as! Int // m is an `Int64`
//
//        if isBrandSelected {
//            let objBrand : Brand = KConstant.APP.arrBrands[m] as Brand
//            txtBrandName.text = objBrand.BrandName
//        }else{
//            txtHowDoYouCommunicate.text = self.arrCommunicate[m]
//        }
//    }
//
//    // ------------------------------------------------------------------------------------------------------------------
//
//    func pickerSelector(_ selector: SBPickerSelector, intermediatelySelectedValues values: [String], atIndexes idxs: [NSNumber]){
//
//    }
//
//    // ------------------------------------------------------------------------------------------------------------------
//
//    func pickerSelector(_ selector: SBPickerSelector, cancelPicker cancel: Bool){
//    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
}
