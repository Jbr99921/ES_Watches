//
//  WishlistViewController.swift
//  EssentialWatches
//
//  Created by Zarna on 21/02/18.
//  Copyright © 2018 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire

class WishlistViewController: BaseViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
 
    @IBOutlet weak var tblV: UITableView!
    @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!

    var arrWishlist = NSMutableArray ()
    var nPageCount: Int = 0
    var isRequiredToHideLoader = false

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupInitialDesign()
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        nPageCount = 10
        self.arrWishlist.removeAllObjects();
        self.sendwishlistRequest()
        
      if DeviceUtility.isIphoneXType{
                  layoutConstraintTopViewTopSpace.constant =  25
              }else{
                  layoutConstraintTopViewTopSpace.constant =  5
              }

        
        
    }
    
    func setupInitialDesign(){
        self.setTitleLabel(title: "Favourite")
        self.textFieldSearch.delegate = self

        self.setIsRequiedMenuYes()
        
        tblV.tableFooterView = UIView.init(frame: CGRect.null)
       
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func handleRefresh(_ refreshControl: UIRefreshControl) {
        nPageCount = 10
        self.arrWishlist.removeAllObjects()
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
         self.progressShow(true) //ProgressHUD.show()
        self.sendwishlistRequest()
        tblV.reloadData()
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func buttonBuyNowClicked(sender: UIButton) {
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        
        let objSearch = self.arrWishlist[sender.tag] as! Search
        
        if objSearch.InStock == "1"
        {
            objAskAQuestionViewController.strOption = "Purchase"
            objAskAQuestionViewController.strTitle = "Buy Now"
        }else{
            objAskAQuestionViewController.strOption = "HaveUsSearch"
            objAskAQuestionViewController.strTitle = "Have us search for it"
        }
        
        objAskAQuestionViewController.isFromSearch = true
        objAskAQuestionViewController.objSearch = objSearch
        objAskAQuestionViewController.strItemID = objSearch.ItemID
        objAskAQuestionViewController.strModelNumber = objSearch.ModelNumber
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    @objc func buttonClicked(sender: UIButton)
    {
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        let objSearch = self.arrWishlist[sender.tag] as! Search
        objAskAQuestionViewController.strOption = "AskQuestion"
        objAskAQuestionViewController.strTitle = "Ask a Question"
        objAskAQuestionViewController.isFromSearch = true
        objAskAQuestionViewController.strItemID = objSearch.ItemID
        objAskAQuestionViewController.objSearch = objSearch
        objAskAQuestionViewController.strModelNumber = objSearch.ModelNumber
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    @objc func btnDeleteWishClicked(sender: UIButton) {
        let objSearch = self.arrWishlist[sender.tag] as! Search
        let strItemId = objSearch.ItemID
         self.progressShow(true) //ProgressHUD.show()
        self.getadd_remove_wish_list(strItemId: strItemId as String, index:sender.tag)
    }
    
    // MARK: - UITextField Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func sendwishlistRequest()
    {
         self.progressShow(true) //ProgressHUD.show()
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        var strEmail = ""
        if (dictTemp != nil) {
            strEmail = (dictTemp?.value(forKey:KConstant.kEmail) as? String)!
        }
        let dictParams = [KConstant.kMethod :  "is_wishlisted.php","email": strEmail,"deviceid" : uniqueIdentifier,"start":String(nPageCount-10),"end":String(nPageCount)]
        
        ServerRequest.sendServerRequestWithDictSearch(dictParam: dictParams ) { (response, isSuccess) in
            if isSuccess
            {
                let arrResponse = response as! Array<Search>
                
                if arrResponse.count == 0{
                    self.isRequiredToHideLoader = true
                }else{
                    self.isRequiredToHideLoader = false
                }
                if arrResponse.count > 0
                {
                    for i in 0 ..< arrResponse.count
                    {
                        let objSearch = arrResponse[i] as Search
                        if !self.arrWishlist.contains(objSearch){
                            self.arrWishlist.add(objSearch)
                        }
                    }
                }
                if self.arrWishlist.count == 0{
                    self.displayAlertWithOk(message: "No item found")
                }
                self.progressShow(false) // ProgressHUD.dismiss()
                self.tblV.reloadData()
            }else{
                self.displayAlertWithOk(message: "No item found")
                self.progressShow(false) // ProgressHUD.dismiss()
            }
            
        }
    }
    func getadd_remove_wish_list(strItemId: String, index:Int)
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        
        let dictParams = ["itemid":strItemId,"deviceid":uniqueIdentifier,"wish":"N","firstname":dictTemp?.value(forKey: KConstant.kFirstName),"lastname":dictTemp?.value(forKey: KConstant.kLastName),"email":dictTemp?.value(forKey: KConstant.kEmail),"phone":dictTemp?.value(forKey: KConstant.kMobileNum)]
        
        ServerRequest.sendServerRequestforGetMethod(dictParam: dictParams as! Dictionary<String, String> , APIName: "add_remove_wish_list.php") { (response, isSuccess) in
            if isSuccess
            {
                print(response)
                let dict : NSDictionary = response as! NSDictionary
                if dict["result"] as! Int == 1{
                    self.arrWishlist.removeObject(at: index)
                    self.tblV.reloadData()
                    //                    nPageCount = 10
                    //                    arrWishlist.removeAllObjects();
                    //                    self.sendwishlistRequest()
                    
                }else{
                    self.displayAlertWithCompletion(message:dict["message"]  as! String, completion: {
                    })
                }
                self.progressShow(false) // ProgressHUD.dismiss()
                
            }else{
                self.displayAlertWithCompletion(message:"Something went wrong", completion: {
                })
                self.progressShow(false) // ProgressHUD.dismiss()
            }
        }
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  UITableView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrWishlist.count
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let objSearch = self.arrWishlist[indexPath.row] as! Search
        var strCondition = "\(objSearch.condition ?? "")" as String
        var nHeight = 21 as Int
        if strCondition.characters.count > 0 {
            nHeight = 0
        }
        return CGFloat(280 - nHeight) // 288
    }

    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SearchCell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath ) as! SearchCell
        cell.selectionStyle = .none
        let objSearch = self.arrWishlist[indexPath.row] as! Search
        cell.buttonDelete.isHidden = false
        cell.buttonDelete.addTarget(self, action: #selector(btnDeleteWishClicked(sender:)), for: .touchUpInside)
        
        cell.labelName.text = objSearch.BrandName+"  " + objSearch.Name + "\n" +  objSearch.SubText
        
        //     cell.labelName.text = objSearch.Name
        cell.labelName2.text = objSearch.SubText
        cell.labelName2.isHidden = true;
        
        cell.labelYourPrice.text = "Your Price - "+objSearch.YourPrice
        cell.labelWirePrice.text = "Wire Price - "+objSearch.WirePrice
        
        //     cell.labelRef.text = objSearch.
        cell.labelRef.text = "Ref - "+objSearch.ModelNumber
        cell.labelItemID.text = "Item Id - "+objSearch.ItemID
        cell.labelRetailPrice.text = "Retail Price - "+"\(objSearch.RetailPrice ?? "")"
        
        cell.labelCase.text =  "Case - " + objSearch.Case
        cell.labelSize.text =  "Size - " + objSearch.CaseSize
        cell.labelDial.text =  "Dial - " + objSearch.Dial
        
        var strCondition = "\(objSearch.condition ?? "")" as String
        
        if strCondition.characters.count > 0 {
            cell.labelCondition.text =  "CONDITION - "+strCondition
            cell.layoutConstraintConditionHeight.constant = 21
        }else{
            cell.labelCondition.text = ""
            cell.layoutConstraintConditionHeight.constant = 0
        }
        if(objSearch.Image.count != 0)
        {
        let url = URL(string: objSearch.Image)!
        let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
        //     cell.imageViewProduct.contentMode = .scaleAspectFill
        //      cell.imageViewWatch.af_setImage(withURL: url, placeholderImage: placeholderImage)
        cell.imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        }
        
        if objSearch.InStock == "1"
        {
            cell.layoutConstraint_ViewSepCenterX.constant =  0
            cell.layoutConstraint_ButtonAskQuestionTrailing.constant =  10
            cell.layoutConstraint_ViewSepWidth.constant =  8
            
            //         cell.layoutConstraint_ButtonAskQuestionHeight.constant = 32
            cell.buttonBuyNow.isHidden = false
            cell.buttonHaveUsSearch.isHidden = true
            //         cell.buttonBuyNow.setTitle("Buy Now", for: .normal)
            //         cell.buttonBuyNow.backgroundColor = KConstant
        }else{
            //            cell.layoutConstraint_ButtonAskQuestionHeight.constant = 0
            cell.buttonBuyNow.isHidden = true
            cell.buttonHaveUsSearch.isHidden = true
            
            cell.layoutConstraint_ViewSepCenterX.constant =  -(self.tblV.frame.size.width/2)
            cell.layoutConstraint_ButtonAskQuestionTrailing.constant =  10
            cell.layoutConstraint_ViewSepWidth.constant =  0
            //            cell.buttonBuyNow.setTitle("Have us find this watch", for: .normal)
        }
        
        cell.buttonAskQuestion.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        cell.buttonAskQuestion.layer.borderWidth = 1.0
        
        cell.buttonHaveUsSearch.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        cell.buttonHaveUsSearch.layer.borderWidth = 1.0
        
        cell.buttonDelete.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        cell.buttonDelete.layer.borderWidth = 1.0
        
        //        cell.viewName.layer.borderColor = UIColor.black.cgColor
        //        cell.viewName.layer.borderWidth = 1
        
        //        if indexPath.row ==  0 {
        //            cell.viewTopLine.isHidden = false
        //        }else{
        //            cell.viewTopLine.isHidden = true
        //        }
        
        if objSearch.InStock == "1"
        {
            cell.labelWirePrice.isHidden = false
            cell.labelYourPrice.isHidden = false
            //         cell.labelYourPrice.text = "Your Price - "+objSearch.YourPrice
        }
        else
        {
            cell.labelWirePrice.isHidden = true
            cell.labelYourPrice.isHidden = true
            cell.labelYourPrice.text = ""
        }
        
        cell.labelRetailPrice.text =  "\(objSearch.Retail_Lable ?? "")"+"\(objSearch.RetailPrice ?? "")"
        
        if (cell.labelRetailPrice.text?.characters.count)! == 0 {
            cell.labelYourPriceOnly.isHidden = false
        }else{
            cell.labelYourPriceOnly.isHidden = true
        }
        
        cell.labelYourPriceOnly.text = cell.labelYourPrice.text
        
        cell.buttonAskQuestion.tag = indexPath.row
        cell.buttonBuyNow.tag = indexPath.row
        cell.buttonHaveUsSearch.tag = indexPath.row
        cell.buttonImage.tag = indexPath.row
        
        let strRetailPrice = "\(objSearch.RetailPrice ?? "")" as String
        
        if objSearch.InStock != "1" && strRetailPrice.characters.count == 0 &&   strCondition.characters.count == 0 &&    cell.labelRetailPrice.text?.characters.count == 0{
            cell.layoputConstraintView3TopSpace.constant = -13
        }else{
            cell.layoputConstraintView3TopSpace.constant = 0
        }
        
        cell.buttonBuyNow.backgroundColor = KConstant.kColorThemeYellow
        cell.buttonImage.isHidden = true
        self.setAdjustableLabel(label: cell.labelCondition)
        cell.buttonAskQuestion.addTarget(self, action: #selector(buttonClicked(sender:)), for: .touchUpInside)
        cell.buttonBuyNow.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)
        cell.buttonHaveUsSearch.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)
        //        cell.buttonImage.addTarget(self, action: #selector(buttonImageClicked(sender:)), for: .touchUpInside)
        return cell
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        return nil
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - TableView Footer Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        if arrWishlist.count == 0 || self.isRequiredToHideLoader || nPageCount == 10 {
            return nil
        }
        
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 40))
        let imageViewGIF = UIImageView(image: nil)
        let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
        
        imageViewGIF.image = gifImage
        imageViewGIF.frame = CGRect(x: self.view.frame.size.width/2, y: 1, width: 35, height: 35)
        footerView.addSubview(imageViewGIF)
        return footerView
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        if arrWishlist.count == 0 || self.isRequiredToHideLoader || nPageCount == 10 {
            return 0
        }
        return 40
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        let objSearch = self.arrWishlist[indexPath.row] as! Search
        objProductDetailsViewController.strItemID = objSearch.ItemID
        objProductDetailsViewController.strBrandName = objSearch.BrandName
        objProductDetailsViewController.isFromMultipleScreen = true
        objProductDetailsViewController.isLatestFromModel = true
        objProductDetailsViewController.isRequiedCubeAnimation = false
        self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
    }
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
            // then we are at the top
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
            nPageCount = nPageCount + 10
            self.sendwishlistRequest()
            
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
