//
//  SearchCell.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class SearchCell: UITableViewCell
{
    @IBOutlet weak var buttonBuyNow: UIButton!
    @IBOutlet weak var buttonAskQuestion: UIButton!
    @IBOutlet weak var buttonHaveUsSearch: UIButton!
    @IBOutlet weak var buttonImage: UIButton!
    @IBOutlet weak var buttonDelete: UIButton!

    @IBOutlet weak var imageViewWatch: UIImageView!
    
    @IBOutlet weak var viewName: UIView!
    @IBOutlet weak var labelYourPrice: UILabel!
    @IBOutlet weak var labelYourPriceOnly: UILabel!
    @IBOutlet weak var labelWirePrice: UILabel!
    
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelName2: UILabel!

    @IBOutlet weak var labelRef: UILabel!
    @IBOutlet weak var labelItemID: UILabel!
    @IBOutlet weak var labelRetailPrice: UILabel!

    @IBOutlet weak var labelCase: UILabel!
    @IBOutlet weak var labelSize: UILabel!
    @IBOutlet weak var labelDial: UILabel!

    @IBOutlet weak var viewTopLine: UIView!
    @IBOutlet weak var layoutConstraint_ButtonAskQuestionTrailing: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraint_ViewSepCenterX: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraint_ViewSepWidth: NSLayoutConstraint!
    
//    @IBOutlet weak var layoutConstraint_ButtonAskQuestionTrailing: NSLayoutConstraint!
    
    @IBOutlet weak var layoputConstraintViewTopSpace: NSLayoutConstraint!
    @IBOutlet weak var layoputConstraintViewHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintConditionHeight: NSLayoutConstraint!
    
    @IBOutlet weak var layoutConstraintViewBottomTopLineHeight: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintViewMainHeight: NSLayoutConstraint!

    @IBOutlet weak var layoputConstraintViewMainTopSpace: NSLayoutConstraint!
    @IBOutlet weak var layoputConstraintView3TopSpace: NSLayoutConstraint!

    @IBOutlet weak var labelCondition: UILabel!
    
    @IBOutlet weak var viewLineBottom: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
