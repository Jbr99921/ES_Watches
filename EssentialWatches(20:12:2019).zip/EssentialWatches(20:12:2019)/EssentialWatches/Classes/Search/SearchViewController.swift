//
//  SearchViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
//import Toast_Swift
import IQKeyboardManager
import Alamofire
import Firebase

class SearchViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,UIScrollViewDelegate
{
    @IBOutlet weak var tableViewSearch: UITableView!
    @IBOutlet weak var buttonSearch: UIButton!
    
     @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!
    
    var strSearchString =  ""
    var arrSearch = NSMutableArray ()
    
    var strSearch = ""
    var isFromSideMenu = false
    
    var nPageCount = 12
    var isRequiredToHideLoader = false

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad()
    {
//        self.view.makeToast("This is a piece of toast")

        tableViewSearch.contentInset = UIEdgeInsets.zero
        self.textFieldSearch.delegate = self
        
        if KConstant.IS_IPHONE5 {
            self.buttonSearch.setImage(UIImage(named: "search_icon_5"), for: .normal)
        }else if KConstant.IS_IPHONE5 {
            self.buttonSearch.setImage(UIImage(named: "search_icon_6"), for: .normal)
        }else{
            self.buttonSearch.setImage(UIImage(named: "search_icon"), for: .normal)
        }

        super.viewDidLoad()
        self.setTitleLabel(title: "Search")
        
        if isFromSideMenu {
            self.setIsRequiedMenuYes()
        }
        let center = NotificationCenter.default
        center.addObserver(self,selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        self.textFieldSearch.becomeFirstResponder()
        
//        var refreshControl: UIRefreshControl = {
//            let refreshControl = UIRefreshControl()
//            refreshControl.addTarget(self, action:
//                #selector(SearchViewController.handleRefresh(_:)),
//                                     for: UIControlEvents.valueChanged)
//            refreshControl.tintColor = UIColor.clear
//            return refreshControl
//        }()
//        
//        self.tableViewSearch.addSubview(refreshControl)
        
        var frame = CGRect.zero
        frame.size.height = .leastNormalMagnitude
        self.tableViewSearch.tableHeaderView = UIView(frame: frame)
        
        if DeviceUtility.isIphoneXType{
            layoutConstraintTopViewTopSpace.constant =  25
        }else{
            layoutConstraintTopViewTopSpace.constant =  5
        }

    }

    // ------------------------------------------------------------------------------------------------------------------

    override  func viewWillAppear(_ animated: Bool) {
       self.tableViewSearch.reloadData()
        

        
        Analytics.logEvent("Search_Screen", parameters: [
            "name": "Search Screen" as NSObject,
            ])
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Search Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    override  func viewDidAppear(_ animated: Bool) {
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override  func viewWillDisappear(_ animated: Bool) {
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override  func viewDidDisappear(_ animated: Bool) {
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction override func buttonSearchClicked(_ sender: Any)
    {
        if self.textFieldSearch.text!.characters.count > 0 {
            nPageCount = 12
            
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }
            
            self.arrSearch.removeAllObjects()
             self.progressShow(true) //ProgressHUD.show()
            self.sendSearchRequest()
        }else{
            self.displayAlertWithOk(message: "Please enter product name")
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @objc func buttonClicked(sender: UIButton)
    {
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        let objSearch = self.arrSearch[sender.tag] as! Search
        objAskAQuestionViewController.strOption = "AskQuestion"
        objAskAQuestionViewController.strTitle = "Ask a Question"
        objAskAQuestionViewController.isFromSearch = true
        objAskAQuestionViewController.strItemID = objSearch.ItemID
        objAskAQuestionViewController.objSearch = objSearch
        objAskAQuestionViewController.strModelNumber = objSearch.ModelNumber
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @objc func buttonBuyNowClicked(sender: UIButton) {
        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController

        let objSearch = self.arrSearch[sender.tag] as! Search
        
        if objSearch.InStock == "1"
        {
            objAskAQuestionViewController.strOption = "Purchase"
            objAskAQuestionViewController.strTitle = "Buy Now"
        }else{
            objAskAQuestionViewController.strOption = "HaveUsSearch"
            objAskAQuestionViewController.strTitle = "Have us search for it"
        }
            
        objAskAQuestionViewController.isFromSearch = true
        objAskAQuestionViewController.objSearch = objSearch
        objAskAQuestionViewController.strItemID = objSearch.ItemID
        objAskAQuestionViewController.strModelNumber = objSearch.ModelNumber
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override  func backButtonClicked()
    {
        if !isRequiedHome {
            self.navigationController?.popViewController(animated: false)
        }
        else
        {
            if self.textFieldSearch.isFirstResponder {
                self.textFieldSearch.resignFirstResponder()
            }
            KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonImageClicked(sender: UIButton)
    {
            let objSearch = self.arrSearch[(sender as AnyObject).tag] as! Search
        
            if objSearch.Image_full.characters.count > 0{
                let slider = ZoomableImageSlider(images:  [(objSearch.Image_full)], currentIndex: 0, placeHolderImage: nil)
                self.present(slider, animated: true, completion: nil)
            }else  if objSearch.Image.characters.count > 0{
                let slider = ZoomableImageSlider(images:  [(objSearch.Image)], currentIndex: 0, placeHolderImage: nil)
                self.present(slider, animated: true, completion: nil)
            }
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------

    func handleRefresh(_ refreshControl: UIRefreshControl) {
        nPageCount = 12
        self.arrSearch.removeAllObjects()
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
         self.progressShow(true) //ProgressHUD.show()
        self.sendSearchRequest()
        tableViewSearch.reloadData()
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func sendSearchRequest()
    {
        let strSearch = textFieldSearch.text
        let dictParams = [KConstant.kMethod :  "iphone_search.php","search" : strSearch,"start":String(nPageCount-11),"end":String(nPageCount)]
        
        ServerRequest.sendServerRequestWithDictSearch(dictParam: dictParams as! Dictionary<String, String>) { (response, isSuccess) in
            if isSuccess
            {
                
                
                IQKeyboardManager.shared().isEnabled = false;

                self.textFieldSearch.resignFirstResponder()
                var arrResponse = response as! Array<Search>
                
                if arrResponse.count == 0{
                    self.isRequiredToHideLoader = true
                }else{
                    self.isRequiredToHideLoader = false
                }
                
                if arrResponse.count > 0
                {
                    for i in 0 ..< arrResponse.count
                    {
                        let objSearch = arrResponse[i] as Search
                        if !self.arrSearch.contains(objSearch){
                            self.arrSearch.add(objSearch)
                        }
                    }
                }
                if self.arrSearch.count == 0{
                  //  self.showToast(message: "No products found")
                    self.displayAlertWithOk(message: "No item found")
                }
                self.tableViewSearch.reloadData()
            }else{
                self.displayAlertWithOk(message: "No item found")
            }
            self.progressShow(false) // ProgressHUD.dismiss()
        }
    }

    // ------------------------------------------------------------------------------------------------------------------

    func showToast(message : String) {
        
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height/2, width: 165, height: 35))
        toastLabel.backgroundColor = UIColor.black
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: KConstant.kFontOpenSenseLight, size: 14.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  keyboardWillHide Notification Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func keyboardWillHide(notification: NSNotification)
    {
        if self.textFieldSearch.text!.characters.count > 0
        {
            
                self.arrSearch.removeAllObjects()
                
                let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
                if !(reachabilityManager?.isReachable)!
                {
                    self.displayAlertForNoIntenret()
                    return
                }
                
               //  self.progressShow(true) //ProgressHUD.show()
                self.sendSearchRequest()
            }
      
    textFieldSearch.resignFirstResponder()
        
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: -  UITableView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrSearch.count
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let objSearch = self.arrSearch[indexPath.row] as! Search
        var strCondition = "\(objSearch.condition ?? "")" as String
        var nHeight = 21 as Int
        if strCondition.characters.count > 0 {
            nHeight = 0
        }
        return CGFloat(247 - nHeight) // 288
    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SearchCell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath ) as! SearchCell
        
        let objSearch = self.arrSearch[indexPath.row] as! Search

        cell.labelName.text = objSearch.BrandName+"  " + objSearch.Name + "\n" +  objSearch.SubText
        
//     cell.labelName.text = objSearch.Name
        cell.labelName2.text = objSearch.SubText
        cell.labelName2.isHidden = true;

        cell.labelYourPrice.text = "Your Price - "+objSearch.YourPrice
        cell.labelWirePrice.text = "Wire Price - "+objSearch.WirePrice

//     cell.labelRef.text = objSearch.
        cell.labelRef.text = "Ref - "+objSearch.ModelNumber
        cell.labelItemID.text = "Item Id - "+objSearch.ItemID
        cell.labelRetailPrice.text = "Retail Price - "+"\(objSearch.RetailPrice ?? "")"

        cell.labelCase.text =  "Case - " + objSearch.Case
        cell.labelSize.text =  "Size - " + objSearch.CaseSize
        cell.labelDial.text =  "Dial - " + objSearch.Dial

        var strCondition = "\(objSearch.condition ?? "")" as String

        if strCondition.characters.count > 0 {
            cell.labelCondition.text =  "CONDITION - "+strCondition
            cell.layoutConstraintConditionHeight.constant = 21
        }else{
            cell.labelCondition.text = ""
            cell.layoutConstraintConditionHeight.constant = 0
        }
        
        let url = URL(string: objSearch.Image)!
        let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//     cell.imageViewProduct.contentMode = .scaleAspectFill
//      cell.imageViewWatch.af_setImage(withURL: url, placeholderImage: placeholderImage)
        cell.imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

        if objSearch.InStock == "1"
        {
            cell.layoutConstraint_ViewSepCenterX.constant =  0
            cell.layoutConstraint_ButtonAskQuestionTrailing.constant =  10
            cell.layoutConstraint_ViewSepWidth.constant =  8
            
//         cell.layoutConstraint_ButtonAskQuestionHeight.constant = 32
            cell.buttonBuyNow.isHidden = false
            cell.buttonHaveUsSearch.isHidden = true
//         cell.buttonBuyNow.setTitle("Buy Now", for: .normal)
//         cell.buttonBuyNow.backgroundColor = KConstant
        }else{
//            cell.layoutConstraint_ButtonAskQuestionHeight.constant = 0
            cell.buttonBuyNow.isHidden = true
            cell.buttonHaveUsSearch.isHidden = true
            
            cell.layoutConstraint_ViewSepCenterX.constant =  -(self.tableViewSearch.frame.size.width/2)
            cell.layoutConstraint_ButtonAskQuestionTrailing.constant =  10
            cell.layoutConstraint_ViewSepWidth.constant =  0
//            cell.buttonBuyNow.setTitle("Have us find this watch", for: .normal)
        }

        cell.buttonAskQuestion.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        cell.buttonAskQuestion.layer.borderWidth = 1.0

        cell.buttonHaveUsSearch.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        cell.buttonHaveUsSearch.layer.borderWidth = 1.0
        
//        cell.viewName.layer.borderColor = UIColor.black.cgColor
//        cell.viewName.layer.borderWidth = 1
        
//        if indexPath.row ==  0 {
//            cell.viewTopLine.isHidden = false
//        }else{
//            cell.viewTopLine.isHidden = true
//        }
        
        if objSearch.InStock == "1"
        {
            cell.labelWirePrice.isHidden = false
            cell.labelYourPrice.isHidden = false
//         cell.labelYourPrice.text = "Your Price - "+objSearch.YourPrice
        }
        else
        {
            cell.labelWirePrice.isHidden = true
            cell.labelYourPrice.isHidden = true
            cell.labelYourPrice.text = ""
        }
        
        cell.labelRetailPrice.text =  "\(objSearch.Retail_Lable ?? "")"+"\(objSearch.RetailPrice ?? "")"
        
        if (cell.labelRetailPrice.text?.characters.count)! == 0 {
            cell.labelYourPriceOnly.isHidden = false
        }else{
            cell.labelYourPriceOnly.isHidden = true
        }
        
        cell.labelYourPriceOnly.text = cell.labelYourPrice.text

        cell.buttonAskQuestion.tag = indexPath.row
        cell.buttonBuyNow.tag = indexPath.row
        cell.buttonHaveUsSearch.tag = indexPath.row
        cell.buttonImage.tag = indexPath.row
        
        let strRetailPrice = "\(objSearch.RetailPrice ?? "")" as String

        if objSearch.InStock != "1" && strRetailPrice.characters.count == 0 &&   strCondition.characters.count == 0 &&    cell.labelRetailPrice.text?.characters.count == 0{
            cell.layoputConstraintView3TopSpace.constant = -13
        }else{
            cell.layoputConstraintView3TopSpace.constant = 0
        }
        
        cell.buttonBuyNow.backgroundColor = KConstant.kColorThemeYellow
         cell.buttonImage.isHidden = true
        self.setAdjustableLabel(label: cell.labelCondition)
        cell.buttonAskQuestion.addTarget(self, action: #selector(buttonClicked(sender:)), for: .touchUpInside)
        cell.buttonBuyNow.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)
        cell.buttonHaveUsSearch.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)
//        cell.buttonImage.addTarget(self, action: #selector(buttonImageClicked(sender:)), for: .touchUpInside)
        return cell
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        return nil
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        let objSearch = self.arrSearch[indexPath.row] as! Search
        objProductDetailsViewController.strItemID = objSearch.ItemID
        
      //  let objBrand = dictOption["object"] as! Brand
       // objProductDetailsViewController.strBrandID = objSearch.BrandID
        objProductDetailsViewController.strBrandName = objSearch.BrandName
       // objProductDetailsViewController.strBrandID = objSearch.Brandid!
     //   objProductDetailsViewController.strModelSlug = objSearch.ModelSlug!
        objProductDetailsViewController.isFromMultipleScreen = true
        objProductDetailsViewController.isLatestFromModel = true

//        objProductDetailsViewController.strCategoryName = objSearch.CategoryName
//        objProductDetailsViewController.strTitle = objSearch.Name
//        objProductDetailsViewController.objSearch = objSearch
//        objProductDetailsViewController.isFromSearch = true
        objProductDetailsViewController.isRequiedCubeAnimation = false
        self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - TableView Footer Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {

        if arrSearch.count == 0 || self.isRequiredToHideLoader || nPageCount == 12 {
            return nil
        }
        
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 40))
        let imageViewGIF = UIImageView(image: nil)
        let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
        imageViewGIF.image = gifImage
        imageViewGIF.frame = CGRect(x: self.view.frame.size.width/2, y: 1, width: 35, height: 35)
        footerView.addSubview(imageViewGIF)
        return footerView
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        if arrSearch.count == 0 || self.isRequiredToHideLoader || nPageCount == 12 {
            return 0
        }
        return 40
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
            // then we are at the top
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
                nPageCount = nPageCount + 12
                self.sendSearchRequest()
        }
    }

    // ------------------------------------------------------------------------------------------------------------------

    /*
    @IBAction override func buttonSearchClicked() {
       strSearch = self.textFieldSearch.text!
     
        if strSearch.characters.count > 0 {
            self.sendSearchRequest()
        }else{
            self.displayAlertWithOk(message: "Please enter your your search text")
        }
    }
 */

    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if self.textFieldSearch.text!.characters.count > 0
        {
            self.arrSearch.removeAllObjects()
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return true
            }
            
             self.progressShow(true) //ProgressHUD.show()
             self.sendSearchRequest()
        }else{
            self.displayAlertWithOk(message: "Please enter your search text")
        }
        textField.resignFirstResponder()
        return true
    }
    // ------------------------------------------------------------------------------------------------------------------

}
