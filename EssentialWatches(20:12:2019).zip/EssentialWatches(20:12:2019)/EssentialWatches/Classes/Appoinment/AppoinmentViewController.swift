//
//  AppoinmentViewController.swift
//  EssentialWatches
//
//  Created by Zarna on 21/02/18.
//  Copyright © 2018 MSP. All rights reserved.
//

import UIKit
import IQKeyboardManager
import ZVProgressHUD
class AppoinmentViewController: BaseViewController {
    @IBOutlet weak var txtFirstName: ECW_TextField!
    @IBOutlet weak var txtLastName: ECW_TextField!
    @IBOutlet weak var txtEmail: ECW_TextField!
    @IBOutlet weak var txtPhoneNum: ECW_TextField!
    @IBOutlet weak var txtBrandName: ECW_TextField!
    @IBOutlet weak var txtModelName: ECW_TextField!
    @IBOutlet weak var txtDate: ECW_TextField!
    @IBOutlet weak var txtStartTime: ECW_TextField!
    @IBOutlet weak var txtEndTime: ECW_TextField!
    
    @IBOutlet weak var txtVDescripation: UITextView!
    @IBOutlet weak var datepicker: UIDatePicker!
    @IBOutlet weak var toolBar: UIToolbar!
    @IBOutlet weak var buttonBrand: UIButton!
    
    var arrPickerData  = ["010"]
    var arrStartTime : NSMutableArray = [] //["10:00","11:00","12:00","13:00"]
    var strBrandID : NSString = ""
    
    // MARK:- Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        IQKeyboardManager.shared().disabledToolbarClasses.add(AppoinmentViewController.self)
        
        self.setupInitialDesignScreen()
       
        
    }
    
    //  MARK:-  Custom Access MEthods
    func setupInitialDesignScreen() {
        
        self.setTitleLabel(title: "Visit Store")
        self.setIsRequiedMenuYes()
        
        txtVDescripation.layer.borderWidth = 0.5;
        txtVDescripation.layer.borderColor = UIColor.lightGray.cgColor
        
        txtDate.inputView = datepicker
        txtDate.inputAccessoryView = toolBar
        txtPhoneNum.inputAccessoryView = toolBar
        txtBrandName.inputView = nil
        txtBrandName.inputAccessoryView = nil
        datepicker.translatesAutoresizingMaskIntoConstraints = false
        let currentDate : Date = Date()
        datepicker.minimumDate = currentDate
        self.getBrands()
        
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
            txtFirstName.text = dictTemp?.value(forKey:KConstant.kFirstName) as? String
            txtLastName.text = dictTemp?.value(forKey:KConstant.kLastName) as? String
            txtPhoneNum.text = dictTemp?.value(forKey:KConstant.kMobileNum) as? String
            txtEmail.text = dictTemp?.value(forKey:KConstant.kEmail) as? String
        }
        
    }
    
    func getBrands()
    {
        var arrTemp = ["010"]
        for i in 0 ..< KConstant.APP.arrBrands.count {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            arrTemp.append(objBrand.BrandName)
        }
        arrTemp.remove(at: 0)
        self.arrPickerData = arrTemp
    }
    
    //  MARK:- IBAction Methods
    @IBAction func buttonBrandClicked(_ sender: Any)
    {
        txtModelName.text = ""
        if  self.arrPickerData.count > 0
        {
            self.view.endEditing(true)
            
            
            
            SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:arrPickerData, defaultDate: Date()).cancel {
                
                }.set { values in
                    if let values = values as? [Brand]
                    {
                        
                        let objBrand : Brand = values[0] as Brand
                        self.strBrandID = objBrand.BrandID as NSString
                        self.txtBrandName.text = objBrand.BrandName
                        self.txtModelName.becomeFirstResponder()
                    }

            }.present(into: self)
            
        }
    }
    
    @IBAction func buttonStartTimeClicked(_ sender: Any)
    {
        txtEndTime.text = ""
        txtStartTime.text = ""
        if  self.arrStartTime.count > 0
        {
            self.view.endEditing(true)
            
            SBPickerSwiftSelector(mode: SBPickerSwiftSelector.Mode.text, data:nil, defaultDate: Date()).cancel {
                print("cancel, will be autodismissed")
                }.set { values in
                        
                     if let values = values as? [String]
                     {
                        self.txtStartTime.text = values[0]
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "HH"
                        let date : NSDate = dateFormatter.date(from:self.txtStartTime.text!)! as NSDate
                        let dateC = date.addingTimeInterval(60.0 * 60.0)
                        self.txtEndTime.text = dateFormatter.string(from: dateC as Date)
                        
                        self.txtVDescripation.becomeFirstResponder()

                        
                    }

            }.present(into: self)
            
//            let picker: SBPickerSelector = SBPickerSelector()
//            picker.pickerData =  arrStartTime as! [Any]//picker content
//            picker.delegate = self
//            picker.pickerType = .text
//            picker.tag = 2
//            picker.doneButtonTitle = "Next"
//            picker.cancelButtonTitle = "Cancel"
//            picker.showPickerOver(self)
            //            picker.showPicker(from: self.view, in: self)
        }
    }
    
    @IBAction func btnDoneClicked(sender: UIBarButtonItem){
        if txtPhoneNum.isFirstResponder{
            self.buttonBrandClicked((Any).self)
            //            txtBrandName.becomeFirstResponder()
        }else if txtDate.isFirstResponder{
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            txtDate.text = dateFormatter.string(from: datepicker.date)
            self.sendAvalailable_timerequest()
            
            //            self.buttonStartTimeClicked((Any).self)
        }else{
            self.view.endEditing(true)
        }
    }
    
    @IBAction func buttonSubmitClicked(_ sender: UIButton)
    {
        self.view.endEditing(true)
        if (txtFirstName.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter First Name.")
            return
        }
        if (txtLastName.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Last Name.")
            return
        }
        if (txtEmail.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Email.")
            return
        }
        
        if self.validateEmail(strEmail: txtEmail.text!) == false{
            self.displayAlertWithOk(message: "Please Enter valid Email.")
            return
        }
        
        if (txtPhoneNum.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Phone Number.")
            return
        }
        
        if (txtBrandName.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Select Brand of Watch.")
            return
        }
        if (txtModelName.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Model of Watch.")
            return
        }
        if (txtDate.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Date.")
            return
        }
        if (txtStartTime.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Select Start Time.")
            return
        }
        if (txtEndTime.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Select End Time.")
            return
        }
        if (txtVDescripation.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Description.")
            return
        }
        let dict:NSDictionary = [KConstant.kFirstName: txtFirstName.text ?? "", KConstant.kLastName: txtLastName.text ?? "", KConstant.kMobileNum : txtPhoneNum.text ?? "", KConstant.kEmail : txtEmail.text ?? ""]
        KConstant.APP.saveValueInUserDefault(dict: dict)
        
        self.sendappointment_request()
        
    }
    
    func sendappointment_request()
    {
         self.progressShow(true) //ProgressHUD.show()
        //        let dateFormatter = DateFormatter()
        //        dateFormatter.dateFormat = "HH:mm"
        //        let date : NSDate = dateFormatter.date(from:txtStartTime.text!)! as NSDate
        //        dateFormatter.dateFormat = "HH"
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        
        let dictParams = ["deviceid":uniqueIdentifier,"firstname":txtFirstName.text as! String,"lastname":txtLastName.text as! String,"email":txtEmail.text as! String,"phone":txtPhoneNum.text as! String,"model":txtModelName.text as! String,"brandid":strBrandID as String,"description":txtVDescripation.text as! String,"appointment_date":txtDate.text as! String,"appointment_time":txtStartTime.text as! String] as [String : Any]
        
        ServerRequest.sendServerRequestforGetMethod(dictParam: dictParams as! Dictionary<String, String> , APIName: "appointment_req.php") { (response, isSuccess) in
            if isSuccess
            {
                let dict : NSDictionary = response as! NSDictionary
                self.displayAlertWithCompletion(message:dict["message"]  as! String, completion: {
                    if dict["result"] as! Int == 1{
                        
                        self.txtStartTime.text = ""
                        self.txtEndTime.text = ""
                        self.txtDate.text = ""
                        self.txtBrandName.text = ""
                        self.txtModelName.text = ""
                        self.txtVDescripation.text = ""
                        self.strBrandID = ""
                    }
                })
                
                self.progressShow(false) // ProgressHUD.dismiss()
            }else{
                self.displayAlertWithOk(message: "No item found")
                self.progressShow(false) // ProgressHUD.dismiss()
            }
            
        }
    }
    func sendAvalailable_timerequest()
    {
         self.progressShow(true) //ProgressHUD.show()
        
        
        let dictParams = ["date":txtDate.text as! String] as [String : Any]
        
        ServerRequest.sendServerRequestforGetMethod(dictParam: dictParams as! Dictionary<String, String> , APIName: "aval_time_ew.php") { (response, isSuccess) in
            if isSuccess
            {
                let dict : NSDictionary = response as! NSDictionary
                if dict["result"] as! Int == 1{
                    if (dict["list"] as! NSArray).count > 0{
                        self.arrStartTime = []
                        self.arrStartTime.addObjects(from:(dict["list"] as! NSArray) as! [Any])
                        self.buttonStartTimeClicked((Any).self)
                    }else{
                        self.displayAlertWithOk(message: "Please select another date")
                    }
                }
                self.progressShow(false) // ProgressHUD.dismiss()
            }else{
                self.displayAlertWithOk(message: "No item found")
                self.progressShow(false) // ProgressHUD.dismiss()
            }
            
        }
    }
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITextField Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if  txtFirstName.isFirstResponder {
            txtLastName.becomeFirstResponder()
        }else  if  txtLastName.isFirstResponder {
            txtEmail.becomeFirstResponder()
        }else  if  txtEmail.isFirstResponder {
            txtPhoneNum.becomeFirstResponder()
        }else  if  txtPhoneNum.isFirstResponder {
            //            txtBrandName.becomeFirstResponder()
            self.buttonBrandClicked((Any).self)
        }else  if  txtBrandName.isFirstResponder {
            txtModelName.becomeFirstResponder()
        }else  if  txtModelName.isFirstResponder {
            txtDate.becomeFirstResponder()
        }else  if  txtDate.isFirstResponder {
            txtDate.resignFirstResponder()
//            self.buttonStartTimeClicked((Any).self)
            
        }
        return true
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - SBPickerSelector Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
//    func pickerSelector(_ selector: SBPickerSelector, selectedValues values: [String], atIndexes idxs: [NSNumber]){
//        if selector.tag == 1 {
//            let m = idxs[0] as! Int // m is an `Int64`
//            let objBrand : Brand = KConstant.APP.arrBrands[m] as Brand
//            strBrandID = objBrand.BrandID as NSString
//            txtBrandName.text = objBrand.BrandName
//            txtModelName.becomeFirstResponder()
//        }else if selector.tag == 2{
//            txtStartTime.text = values[0]
//            let dateFormatter = DateFormatter()
//            dateFormatter.dateFormat = "HH"
//            let date : NSDate = dateFormatter.date(from:txtStartTime.text!)! as NSDate
//            let dateC = date.addingTimeInterval(60.0 * 60.0)
//            txtEndTime.text = dateFormatter.string(from: dateC as Date)
//
//            txtVDescripation.becomeFirstResponder()
//        }
//
//    }
//
//    // ------------------------------------------------------------------------------------------------------------------
//
//    func pickerSelector(_ selector: SBPickerSelector, cancelPicker cancel: Bool){
//        if selector.tag == 1 {
//                    txtBrandName.text = ""
//
//        }
//    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}

