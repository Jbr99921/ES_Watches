//
//  BaseViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire

class BaseViewController: UIViewController
{
    var viewHeader = HeaderView()
    var viewSearch = SearchView()
    
    var  strDeviceName = " "
    
    @IBOutlet weak var textFieldSearch: UITextField!

    var isRequiedHome : Bool = false
    var objHomeViewController = HomeViewController()
    var objNavigationController =  UINavigationController()
    
    let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "http://www.apple.com")

    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        KConstant.APP.objCurrentNavigationController = self.navigationController!
        viewHeader = HeaderView.instanceFromNib() as! HeaderView
//        viewHeader.labelTitle.font = UIFont(name: KConstant.kFontOpenSenseRegular, size: 23)
//        viewHeader.labelTitle.textColor = KConstant.kColorThemeYellow
        
         if DeviceUtility.isIphoneXType{
            viewHeader.frame = CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 64)
        }else{
            viewHeader.frame = CGRect(x: 0, y: 5, width: self.view.frame.size.width, height: 64)
        }
        
//        if UIApplication.shared.statusBarFrame.height >= 44{
//            viewHeader.frame = CGRect(x: 0, y: 40, width: self.view.frame.size.width, height: 80)
//        }else{
//            viewHeader.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 64)
//        }
        

     

        viewHeader.labelTitle.textColor = KConstant.kColorThemeYellow
        self.setAdjustableLabel(label: viewHeader.labelTitle)
        viewHeader.buttonBack.addTarget(self, action: #selector(backButtonClicked), for: .touchUpInside)
        viewHeader.buttonPhone.addTarget(self, action: #selector(buttonPhoneClicked), for: .touchUpInside)
        viewHeader.buttonMenu.addTarget(self, action: #selector(menuButtonClicked), for: .touchUpInside)
        viewHeader.buttonLogo.addTarget(self, action: #selector(logoButtonClicked), for: .touchUpInside)
        viewHeader.buttonMiddle.addTarget(self, action: #selector(logoButtonClicked), for: .touchUpInside)
        viewHeader.buttonBack.isHidden = false
        viewHeader.imageViewBack.isHidden = false
        viewHeader.menuLead.constant = 35
        self.view.addSubview(viewHeader)
        
    }

    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func setTitleLabel(title: String){
        viewHeader.labelTitle.text = title
    }
   
    // ------------------------------------------------------------------------------------------------------------------

    func getTitle() -> NSString {
      return  viewHeader.labelTitle.text as! NSString
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func setBorderOnControl(view : UIButton)  {
        view.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        view.layer.borderWidth =  1.0
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func setIsRequiedMenuYes()  {
        isRequiedHome = true
        viewHeader.buttonBack.isHidden = true
        viewHeader.imageViewBack.isHidden = true
        viewHeader.menuLead.constant = 7
//     viewHeader.imageViewBack.image = UIImage(named: "menu_icon")
    }

    // ------------------------------------------------------------------------------------------------------------------

    func showHeaderLogo()
    {
        if DeviceUtility.isIphoneXType{
          viewHeader.frame = CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 64)
      }else{
              viewHeader.frame = CGRect(x: 0, y: 5, width: self.view.frame.size.width, height: 64)
      }
          

        viewHeader.layoutConstraintBackImageCenterX.constant = 5
         viewHeader.layoutConstraintMenuButtonCenterY.constant = 5
         //viewHeader.layoutConstraintPhoneButtonTopSpace.constant = 30

        self.viewHeader.labelTitle.isHidden = true
        self.viewHeader.imageViewMiddleIcon.isHidden = false
        self.viewHeader.buttonMiddle.isHidden = false
        self.viewHeader.buttonLogo.isHidden = true
    }

    // ------------------------------------------------------------------------------------------------------------------

    func hideHeaderLogo() {
        self.viewHeader.buttonLogo.isHidden = false
        self.viewHeader.labelTitle.isHidden = false
        self.viewHeader.imageViewMiddleIcon.isHidden = true
        self.viewHeader.buttonMiddle.isHidden = true
    }

    // ------------------------------------------------------------------------------------------------------------------

    func setAdjustableLabel(label: UILabel) {
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func displayAlertWithOk(message: String) {
        let alert = UIAlertController(title: KConstant.kAPPName, message:message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
            alert.dismiss(animated: true, completion: nil)
        })
        self.present(alert, animated: true, completion: nil)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func displayAlertWithWithPopViewController(message: String) {
        let alert = UIAlertController(title: KConstant.kAPPName, message:message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
            self.navigationController?.popViewController(animated: true)
        })
        self.present(alert, animated: true, completion: nil)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func displayAlertWithCompletion(message: String , completion:@escaping() -> ()) {
        let alert = UIAlertController(title: KConstant.kAPPName, message:message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
            completion()
        })
        KConstant.APP.window?.rootViewController?.present(alert, animated: true, completion: nil)
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    func validateEmail(strEmail: String) -> Bool
    {
        let stricterFilter: Bool = true
        let stricterFilterString: String = "[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}"
        let laxString: String = ".+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*"
        let emailRegex: String = stricterFilter ? stricterFilterString : laxString
        let emailTest: NSPredicate = NSPredicate(format: "SELF MATCHES %@",emailRegex)
        return emailTest.evaluate(with: strEmail)
    }

    // ----------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonSearchClicked(_ sender: Any)
    {
        var objSearchViewController = SearchViewController()
        objSearchViewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
        objSearchViewController.isFromSideMenu = false
        objSearchViewController.strSearchString =  self.textFieldSearch.text!
        self.navigationController?.pushViewController(objSearchViewController, animated: false)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @objc func backButtonClicked()
    {
        if !isRequiedHome {
            self.navigationController?.popViewController(animated: true)
        }else{
            KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
        }
    }

    @objc func menuButtonClicked()
    {
        self.view.endEditing(true)
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }
    
    @objc func logoButtonClicked()
    {
        self.navigationController?.popToRootViewController(animated: true)
        objHomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        objNavigationController =  UINavigationController.init(rootViewController: objHomeViewController)
       
        objNavigationController.isNavigationBarHidden = true
        KConstant.APP.objSidePanelController.centerPanel = objNavigationController
        KConstant.APP.objSidePanelController.showCenterPanel(animated: true)
//     KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
//     let objSideMenuViewController : SideMenuViewController = self.storyboard?.instantiateViewController(withIdentifier: "SideMenuViewController") as! SideMenuViewController
        KConstant.APP.objSideMenuVC.nSelectedCell = 0
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
            if  (KConstant.APP.objSideMenuVC.tblSlideMenu != nil) {
                        KConstant.APP.objSideMenuVC.tblSlideMenu.selectRow(at: NSIndexPath.init(row: 0, section: 0) as IndexPath, animated: true, scrollPosition:.top)
            }
        }

    }

    // ------------------------------------------------------------------------------------------------------------------
//    +1 310 601 7264

    @IBAction  func buttonPhoneClicked(_ sender: Any) {
        if let url = URL(string: "tel://+1-3106017264"), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
     func displayAlertForNoIntenret() {
            let alert = UIAlertController(title: KConstant.kAPPName, message:"Please check your internet conncetion and try again.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default) { action in
                alert.dismiss(animated: true, completion: nil)
            })
            self.present(alert, animated: true, completion: nil)
        return
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom  Animation Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func pushTransition() -> CATransition {
        let transition = CATransition()
        transition.duration = 1.5 as? CFTimeInterval ?? CFTimeInterval()
        transition.type = CATransitionType(rawValue: "cube")
        transition.subtype = CATransitionSubtype(rawValue: "fromRight")
        transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeIn)
        return transition
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func popTransition() -> CATransition {
        let transition = CATransition()
        transition.duration = 1.5 as? CFTimeInterval ?? CFTimeInterval()
        transition.type = CATransitionType(rawValue: "cube")
        transition.subtype = CATransitionSubtype(rawValue: "fromLeft")
        transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeIn)
        return transition
    }
    // ------------------------------------------------------------------------------------------------------------------
}





public extension UIDevice {
    
    var modelName: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        
        switch identifier {
        case "iPod5,1":                                 return "iPod Touch 5"
        case "iPod7,1":                                 return "iPod Touch 6"
        case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
        case "iPhone4,1":                               return "iPhone 4s"
        case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
        case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
        case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
        case "iPhone7,2":                               return "iPhone 6"
        case "iPhone7,1":                               return "iPhone 6 Plus"
        case "iPhone8,1":                               return "iPhone 6s"
        case "iPhone8,2":                               return "iPhone 6s Plus"
        case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
        case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
        case "iPhone8,4":                               return "iPhone SE"
        case "iPhone10,1", "iPhone10,4":                return "iPhone 8"
        case "iPhone10,2", "iPhone10,5":                return "iPhone 8 Plus"
        case "iPhone10,3", "iPhone10,6":                return "iPhone X"
        case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
        case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
        case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
        case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
        case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
        case "iPad6,11", "iPad6,12":                    return "iPad 5"
        case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
        case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
        case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
        case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
        case "iPad6,3", "iPad6,4":                      return "iPad Pro 9.7 Inch"
        case "iPad6,7", "iPad6,8":                      return "iPad Pro 12.9 Inch"
        case "iPad7,1", "iPad7,2":                      return "iPad Pro 12.9 Inch 2. Generation"
        case "iPad7,3", "iPad7,4":                      return "iPad Pro 10.5 Inch"
        case "AppleTV5,3":                              return "Apple TV"
        case "AppleTV6,2":                              return "Apple TV 4K"
        case "AudioAccessory1,1":                       return "HomePod"
        case "i386", "x86_64":                          return "Simulator"
        default:                                        return identifier
        }
    }
    
}
// ------------------------------------------------------------------------------------------------------------------

