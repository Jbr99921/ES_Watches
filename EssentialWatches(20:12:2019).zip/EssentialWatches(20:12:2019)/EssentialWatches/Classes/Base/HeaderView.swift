//
//  HeaderView.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class HeaderView: UIView {

    @IBOutlet weak var imageViewBack: UIImageView!
    @IBOutlet weak var imageViewLogo: UIImageView!
    @IBOutlet weak var imageViewPhone: UIImageView!
    @IBOutlet weak var imageViewMiddleIcon: UIImageView!
    @IBOutlet weak var buttonBack: UIButton!
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var buttonLogo: UIButton!
    @IBOutlet weak var buttonPhone: UIButton!
    @IBOutlet weak var buttonMenu: UIButton!
    @IBOutlet weak var buttonMiddle: UIButton!    
    @IBOutlet weak var menuLead: NSLayoutConstraint!

    @IBOutlet weak var layoutConstraintBackImageCenterX: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintMenuButtonCenterY: NSLayoutConstraint!
    @IBOutlet weak var layoutConstraintPhoneButtonTopSpace: NSLayoutConstraint!

    override func draw(_ rect: CGRect)
    {
        
    }
    
    class func instanceFromNib() -> UIView {
        if KConstant.IS_IPHONE5 ||  KConstant.IS_IPHONE_6{
            return UINib(nibName: "HeaderView_iPhone6", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
        }else{
            return UINib(nibName: "HeaderView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
        }
    }

    

}
