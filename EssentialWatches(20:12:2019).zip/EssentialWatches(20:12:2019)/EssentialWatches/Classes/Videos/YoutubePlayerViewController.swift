//
//  YoutubePlayerViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 22/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class YoutubePlayerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
