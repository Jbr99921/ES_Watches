//
//  VideosViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import AssetsLibrary
import Alamofire
import Firebase


class VideosViewController: BaseViewController, UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate,UICollectionViewDelegateFlowLayout
{
    @IBOutlet weak var collectionViewHome: UICollectionView!
    
    var collectionViewLayout: CustomCellFlowLayout!
    var screenSize = CGSize()
    
    var arrVideos = NSMutableArray()
    var nPageCount = 10

    override func viewDidLoad()
    {
        super.viewDidLoad()
        //let gridFlowLayout = ProductsGridFlowLayout()
//        self.setTitleLabel(title: "Featured Watch Videos")
        
        if DeviceUtility.isIphoneXType{
            viewHeader.frame = CGRect(x: 0, y: 25, width: self.view.frame.size.width, height: 64)
        }else{
            viewHeader.frame = CGRect(x: 0, y: 5, width: self.view.frame.size.width, height: 64)
        }
        self.viewHeader.labelTitle.text = "Videos"
        collectionViewLayout = CustomCellFlowLayout()
        collectionViewHome.collectionViewLayout = collectionViewLayout
        collectionViewLayout.sectionInset = UIEdgeInsets(top: 0,left: 5,bottom: 0,right: 5);
        collectionViewLayout.minimumInteritemSpacing = 10
        collectionViewLayout.minimumLineSpacing = 10
        screenSize = UIScreen.main.bounds.size
        
        self.setIsRequiedMenuYes()

        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
         self.progressShow(true) //ProgressHUD.show()
        self.getYoutubeVideos()
        
//        let refreshControl: UIRefreshControl = {
//            let refreshControl = UIRefreshControl()
//            refreshControl.addTarget(self, action:
//                #selector(VideosViewController.handleRefresh(_:)),
//                                     for: UIControlEvents.valueChanged)
//            refreshControl.tintColor = UIColor.clear
//            return refreshControl
//        }()
//        self.collectionViewHome.addSubview(refreshControl)
        
    }
   
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        Analytics.logEvent("Featured_Watch_Videos_Screen", parameters: [
            "name": "Featured Watch Videos Screen" as NSObject,
            ])
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Featured Watch Videos Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
        
        //Bhavesh 30-Nov'2019``````````
        self.viewHeader.buttonLogo.isHidden = true
        //``````````````
    }
    
    
    func handleRefresh(_ refreshControl: UIRefreshControl)
    {
        nPageCount = 10
        self.arrVideos.removeAllObjects()
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
         self.progressShow(true) //ProgressHUD.show()
        self.getYoutubeVideos()
        
        collectionViewHome.reloadData()
        refreshControl.endRefreshing()
    }
    
    
    func getYoutubeVideos()
    {
        let dictParams = [KConstant.kMethod :  "featuredwatches_detail.php","start":String(nPageCount-9),"end":String(nPageCount)]
        ServerRequest.sendServerRequestWithDictForYoutubeVideos(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess {
                    self.arrVideos.addObjects(from: response as! Array<YoutubeVideo>)
                    self.collectionViewHome.reloadData()
            }else{
                print("failure\(response)")
            }
            self.progressShow(false) // ProgressHUD.dismiss()
        }
    }
    
    @IBAction func buttonMenuClicked(_ sender: Any) {
        print(KConstant.APP.objSidePanelController)
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }
    
    func buttonSelectClicked(sender:AnyObject) -> Void {
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrVideos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeProductCollectionViewCell", for: indexPath) as! HomeProductCollectionViewCell
        cell.labelProduct.textAlignment = .center
        
        let objYoutubeVideo : YoutubeVideo = self.arrVideos[indexPath.item] as! YoutubeVideo
        cell.labelProduct.text = objYoutubeVideo.BrandName
        cell.labelWatchInfo.text = objYoutubeVideo.ModelName

        let url = URL(string: objYoutubeVideo.ModelImage)!
      
        let escapedString = url.absoluteString.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)
          let placeholderImage = UIImage(named: "temp.png")!
          cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        
//        if (escapedString?.contains("brand_patek"))!
//        {
//            self.getDataFromUrl(url: url) { data, response, error in
//                guard let data = data, error == nil else { return }
//                print(response?.suggestedFilename ?? url.lastPathComponent)
//                print("Download Finished")
//                print("\n\nDownload Finished data====== \(data) and url \(url) and name\(objYoutubeVideo.BrandName)")
//                DispatchQueue.main.async() {
//                     cell.imageViewProduct.image = UIImage(data: data)
//                }
//            }
//        }else{
          
//            print(escapedString! + objYoutubeVideo.ModelName)
//            print(objYoutubeVideo.ModelImage)
//            cell.imageViewProduct.af_setImage(withURL:URL(string: escapedString!)!, placeholderImage: placeholderImage)
       
//        }
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath){
        let objYoutubeVideo : YoutubeVideo = self.arrVideos[indexPath.item] as! YoutubeVideo
        let objWebViewController = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
        objWebViewController.strOption = "Video"
        objWebViewController.strTitle =  objYoutubeVideo.BrandName
        objWebViewController.isVideo = true
        objWebViewController.strURL = objYoutubeVideo.video
        self.navigationController?.pushViewController(objWebViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (screenSize.width/2)-10, height: 190);
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UICollectionView Footer Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView
    {
        let view1 = UICollectionReusableView()
        switch kind
        {
        case UICollectionView.elementKindSectionHeader:
            assert(false, "Unexpected element kind")
        case UICollectionView.elementKindSectionFooter:
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView", for: indexPath as IndexPath) as! GIFImageCollectionFooterView
            let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
            view.imageViewGIF.image = gifImage
            return view
        default:
            assert(false, "Unexpected element kind")
        }
        return view1
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if arrVideos.count == 0 {
            return CGSize(width: 0, height: 0)
        }
        return CGSize(width: collectionView.frame.size.width, height: 60)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
            // then we are at the top
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
                // self.progressShow(true) //ProgressHUD.show()
                nPageCount = nPageCount + 10
                self.getYoutubeVideos()
        }
    }
    
  

    
    
}
