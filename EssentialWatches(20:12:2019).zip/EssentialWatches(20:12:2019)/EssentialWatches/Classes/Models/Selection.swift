//
//  Selection.swift
//  EssentialWatches
//
//  Created by msp on 17/11/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import HTHorizontalSelectionList

class Selection: UIView {

    @IBOutlet var viewBrand: HTHorizontalSelectionList!
    @IBOutlet var viewModel: HTHorizontalSelectionList!
    @IBOutlet var viewVariation: HTHorizontalSelectionList!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
