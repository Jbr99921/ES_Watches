//
//  DateRangesModel.swift
//  EssentialWatches
//
//  Created by Chandresh on 17/12/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import Foundation
import Unbox

struct DateRangeModel{
    let BrandID : String?
    let YearName: String
    let YearSlug : String
    let ModelImage : String?
   
}

extension DateRangeModel : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.BrandID =  try?  unboxer.unbox(key: "BrandID")
        self.YearName =  try  unboxer.unbox(key: "YearName")
        self.YearSlug =  try  unboxer.unbox(key: "YearSlug")
        self.ModelImage =  try?  unboxer.unbox(key: "ModelImage")
    }
}
