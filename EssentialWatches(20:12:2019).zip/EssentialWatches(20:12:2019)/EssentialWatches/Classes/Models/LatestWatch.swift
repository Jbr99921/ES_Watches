//
//  LatestWatch.swift
//  EssentialWatches
//
//  Created by Vikram on 15/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct LatestWatch
{
    var BrandID : String
    var ModelID : String
    var ModelName : String
    var ModelNumber : String
    var Class1 : String
    var Class2 : String
    var ModelSlug : String
    var WirePrice : String
    var ModelImage : String
    var CategoryName : String
    var BrandName : String
    var Date : String
    var is_wish_listed : Bool
    var Product : LatestWatchProduct
}

extension LatestWatch : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.BrandID =  try  unboxer.unbox(key: "BrandID")
        self.ModelID =  try  unboxer.unbox(key: "ModelID")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.ModelNumber =  try  unboxer.unbox(key: "ModelNumber")
        self.Class1 =  try  unboxer.unbox(key: "Class1")
        self.Class2 =  try  unboxer.unbox(key: "Class2")
        self.ModelSlug =  try  unboxer.unbox(key: "ModelSlug")
        self.WirePrice =  try  unboxer.unbox(key: "WirePrice")
        self.ModelImage =  try  unboxer.unbox(key: "ModelImage")
        self.CategoryName =  try  unboxer.unbox(key: "CategoryName")
        self.BrandName =  try  unboxer.unbox(key: "BrandName")
        self.Date =  try  unboxer.unbox(key: "Date")
        self.Product =  try  unboxer.unbox(key: "Product")
        self.is_wish_listed =  try  unboxer.unbox(key: "is_wish_listed")
        
    }
}

