//
//  WatchHeader.swift
//  EssentialWatches
//
//  Created by Vikram on 15/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Foundation
import Unbox

struct WatchHeader
{
    let CategoryName : String
    let BrandName : String?
    let ModelName : String
    let Product : [WatchList]
}

extension WatchHeader : Unboxable
{
    init(unboxer: Unboxer) throws {
         self.CategoryName =  try  unboxer.unbox(key: "CategoryName")
        self.BrandName =  try?  unboxer.unbox(key: "BrandName")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.Product =  try  unboxer.unbox(key: "Product")
    }
}

