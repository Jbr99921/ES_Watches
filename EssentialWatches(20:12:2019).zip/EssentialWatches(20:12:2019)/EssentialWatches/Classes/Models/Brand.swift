//
//  Product.swift
//  EssentialWatches
//
//  Created by Vikram on 11/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct Brand{
    let BrandName : String
    let BrandID : String
    let BrandImage: String
}

extension Brand : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.BrandName =  try  unboxer.unbox(key: "BrandName")
        self.BrandID =  try  unboxer.unbox(key: "BrandID")
        self.BrandImage =  try  unboxer.unbox(key: "BrandImage")
    }
}


struct BrandList{
    let BrandName : String
    let BrandID : String
    let BrandImage: String
    let ItemCount: String
}

extension BrandList : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.BrandName =  try  unboxer.unbox(key: "BrandName")
        self.BrandID =  try  unboxer.unbox(key: "BrandID")
        self.BrandImage =  try  unboxer.unbox(key: "BrandImage")
        self.ItemCount =  try  unboxer.unbox(key: "ItemCount")
    }
}


struct WatchVideoList{
    let item_id : String
    let video_name : String
    let video_url: String
    let created_at: String
}

extension WatchVideoList : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.item_id =  try  unboxer.unbox(key: "item_id")
        self.video_name =  try  unboxer.unbox(key: "video_name")
        self.video_url =  try  unboxer.unbox(key: "video_url")
        self.created_at =  try  unboxer.unbox(key: "created_at")
    }
}
