//
//  Search.swift
//  EssentialWatches
//
//  Created by Vikram on 19/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct Search
{
    let CategoryName  : String
    let Title  : String?
    let ModelName  : String
    let ModelSlug  : String?
    let BrandName  : String
    let Brandid : String?
    let Image : String
    let Image_full : String
    let Name : String
    let SubText : String
    let ModelNumber : String
    let RetailPrice : String?
    let Retail_Lable : String?
    let LastKnownRetailPrice : String?
    let WirePrice : String
    let YourPrice : String
    let Case : String
    let Dial : String
    let ItemID : String
    let InStock : String
    let ShortDesc : String
    let condition : String?
//    let Est_RetailPrice : String

    let CaseSize : String
    let Movement : String
    let Bracelet : String
    let KnownAs1 : String
    let KnownAs2 : String
    let KnownAs3 : String
    let KnownAs4 : String
    let KnownAs5 : String
    let Video : String
    
    let Previous_ID : String?
    let Next_ID : String?
    let Tag : String?
    let Watch_Lable : String?
    let Watch_Lable1 : String?
    
    let is_submodel : String?
    let parrent_slug : String?
    let subModelSlug : String?
    let variationslug : String?
    let variationname : String?
    let wishlisted : String?
    let arrextraimgs:[String]?
    let img_url:String?
}


extension Search : Unboxable
{
    init(unboxer: Unboxer) throws
    {
        self.CategoryName =  try  unboxer.unbox(key: "CategoryName")
        self.Title =  try? unboxer.unbox(key: "Title")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.ModelSlug =  try? unboxer.unbox(key: "ModelSlug")
        self.BrandName =  try  unboxer.unbox(key: "BrandName")
         self.Brandid =  try? unboxer.unbox(key: "Brandid")
        self.Image =  try  unboxer.unbox(key: "Image")
        self.Image_full =  try  unboxer.unbox(key: "Image_full")
        self.Name =  try  unboxer.unbox(key: "Name")
        self.SubText =  try  unboxer.unbox(key: "SubText")
        self.ModelNumber =  try  unboxer.unbox(key: "ModelNumber")
        
        self.RetailPrice =  try?  unboxer.unbox(key: "RetailPrice")
        self.Retail_Lable =  try?  unboxer.unbox(key: "Retail_Lable")
        self.LastKnownRetailPrice =  try?  unboxer.unbox(key: "LastKnownRetailPrice")

        self.WirePrice =  try  unboxer.unbox(key: "WirePrice")
        self.YourPrice =  try  unboxer.unbox(key: "YourPrice")
        self.Case =  try  unboxer.unbox(key: "Case")
        self.Dial =  try  unboxer.unbox(key: "Dial")
        self.ItemID =  try  unboxer.unbox(key: "ItemID")
        self.InStock =  try  unboxer.unbox(key: "InStock")
        self.ShortDesc =  try  unboxer.unbox(key: "ShortDesc")
        self.condition =  try?  unboxer.unbox(key: "condition")
//     self.Est_RetailPrice =  try  unboxer.unbox(key: "Est_RetailPrice")

        self.CaseSize =  try  unboxer.unbox(key: "CaseSize")
        self.Movement =  try  unboxer.unbox(key: "Movement")
        self.Bracelet =  try  unboxer.unbox(key: "Bracelet")
        self.KnownAs1 =  try  unboxer.unbox(key: "KnownAs1")
        self.KnownAs2 =  try  unboxer.unbox(key: "KnownAs2")
        self.KnownAs3 =  try  unboxer.unbox(key: "KnownAs3")
        self.KnownAs4 =  try  unboxer.unbox(key: "KnownAs4")
        self.KnownAs5 =  try  unboxer.unbox(key: "KnownAs5")
        
        self.Video =  try  unboxer.unbox(key: "Video")

        self.Previous_ID =  try?  unboxer.unbox(key: "Previous_ID")
        self.Next_ID =  try?  unboxer.unbox(key: "Next_ID")
        self.Tag =  try?  unboxer.unbox(key: "Tag")
        self.Watch_Lable =  try?  unboxer.unbox(key: "Watch_Lable")
        self.Watch_Lable1 =  try?  unboxer.unbox(key: "Watch_Lable1")
        
        self.is_submodel =  try?  unboxer.unbox(key: "is_submodel")
        self.parrent_slug =  try?  unboxer.unbox(key: "parrent_slug")
        self.subModelSlug =  try?  unboxer.unbox(key: "subModelSlug")
        self.variationslug =  try?  unboxer.unbox(key: "variationslug")
        self.variationname =  try?  unboxer.unbox(key: "variationname")
        
        self.wishlisted =  try?  unboxer.unbox(key: "wishlisted")
self.arrextraimgs = try?  unboxer.unbox(key: "extra_images")
        self.img_url = try?  unboxer.unbox(key: "image_url")
        
    }
}

