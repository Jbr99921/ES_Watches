//
//  RecentWatch.swift
//  EssentialWatches
//
//  Created by Vikram on 12/10/17.
//  Copyright © 2017 MSP. All rights reserved.
//
import Unbox

struct RecentWatch{
    let id : String
    let class1 : String
    let wireprice: String?
    let image: String
}

extension RecentWatch : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.id =  try  unboxer.unbox(key: "id")
        self.class1 =  try  unboxer.unbox(key: "class1")
        self.wireprice =  try?  unboxer.unbox(key: "wireprice")
        self.image =  try  unboxer.unbox(key: "image")
    }
}

