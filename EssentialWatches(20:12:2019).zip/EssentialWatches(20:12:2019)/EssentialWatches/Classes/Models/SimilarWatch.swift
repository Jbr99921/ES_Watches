//
//  SimilarWatch.swift
//  EssentialWatches
//
//  Created by Vikram on 18/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Foundation
import Unbox

struct SimilarWatch
{
    let Image : String
    let ModelName : String
    let itemid : String
    let Title : String
    let WatchLink : String
}

extension SimilarWatch : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.Image =  try  unboxer.unbox(key: "Image")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.itemid =  try  unboxer.unbox(key: "itemid")
        self.Title =  try  unboxer.unbox(key: "Title")
        self.WatchLink =  try  unboxer.unbox(key: "WatchLink")
    }
}
