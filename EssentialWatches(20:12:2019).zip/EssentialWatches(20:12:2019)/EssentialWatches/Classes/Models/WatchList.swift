//
//  WatchList.swift
//  EssentialWatches
//
//  Created by Vikram on 15/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct WatchList
{
    let ItemID  : String
    let InStock  : String
    let Title  : String
    let Name  : String
    let Subtext  : String
    let ModelNumber : String
    let ShortDesc : String
    let RetailPrice : String?
    let Retail_Lable : String?
    let LastKnownRetailPrice : String?
    let YourPrice : String
    let WirePrice : String?
    let Image : String
    let Image_full : String
    let Case : String
    let CaseSize : String?
    let Movement : String
    let Dial : String
    let condition : String
    let Bracelet : String
    let KnownAs1 : String
    let KnownAs2 : String
    let KnownAs3 : String
    let KnownAs4 : String
    let KnownAs5 : String
    
    
}

extension WatchList : Unboxable
{
    init(unboxer: Unboxer) throws
    {
        self.ItemID =  try  unboxer.unbox(key: "ItemID")
        self.InStock =  try  unboxer.unbox(key: "InStock")
        self.Name =  try  unboxer.unbox(key: "Name")
        self.Title =  try  unboxer.unbox(key: "Title")
        self.Subtext =  try  unboxer.unbox(key: "Subtext")
        self.ModelNumber =  try  unboxer.unbox(key: "ModelNumber")
        self.ShortDesc =  try  unboxer.unbox(key: "ShortDesc")
        self.RetailPrice =  try?  unboxer.unbox(key: "RetailPrice")
        self.Retail_Lable =  try?  unboxer.unbox(key: "Retail_Lable")
        self.LastKnownRetailPrice =  try?  unboxer.unbox(key: "LastKnownRetailPrice")
        self.YourPrice =  try  unboxer.unbox(key: "YourPrice")
        self.WirePrice =  try?  unboxer.unbox(key: "WirePrice")
        self.Image =  try  unboxer.unbox(key: "Image")
        self.Image_full =  try  unboxer.unbox(key: "Image_full")
        self.Case =  try  unboxer.unbox(key: "Case")
        self.CaseSize =  try?  unboxer.unbox(key: "CaseSize")
        self.Movement =  try  unboxer.unbox(key: "Movement")
        self.Dial =  try  unboxer.unbox(key: "Dial")
        self.condition =  try  unboxer.unbox(key: "condition")
        self.Bracelet =  try  unboxer.unbox(key: "Bracelet")
        self.KnownAs1 =  try  unboxer.unbox(key: "KnownAs1")
        self.KnownAs2 =  try  unboxer.unbox(key: "KnownAs2")
        self.KnownAs3 =  try  unboxer.unbox(key: "KnownAs3")
        self.KnownAs4 =  try  unboxer.unbox(key: "KnownAs4")
        self.KnownAs5 =  try  unboxer.unbox(key: "KnownAs5")
    }
}

