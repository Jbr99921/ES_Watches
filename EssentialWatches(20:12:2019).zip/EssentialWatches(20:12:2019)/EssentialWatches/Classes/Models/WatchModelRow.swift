//
//  WatchModelRow.swift
//  EssentialWatches
//
//  Created by Vikram on 15/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//


import Unbox

struct WatchModelRow
{
    let ModelID : String?
    let ModelName: String
    let ModelSlug: String
    let ModelImage: String
    let Count: String
    let is_submodel: String?
}

extension WatchModelRow : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.ModelID =  try?  unboxer.unbox(key: "ModelID")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.ModelSlug =  try  unboxer.unbox(key: "ModelSlug")
        self.ModelImage =  try  unboxer.unbox(key: "ModelImage")
        self.Count =  try  unboxer.unbox(key: "Count")
        self.is_submodel = try? unboxer.unbox(key: "is_submodel")
    }
}

