//
//  YoutubeVideo.swift
//  EssentialWatches
//
//  Created by Vikram on 13/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct YoutubeVideo
{
    let BrandID : String
    let ModelID : String
    let ModelName: String
    let ModelNumber: String
    let Class1: String
    let Class2: String
    let ModelSlug: String
    let ModelImage: String
    let CategoryName: String
    let BrandName: String
    let WirePrice: String
    let video: String
}

extension YoutubeVideo : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.BrandID =  try  unboxer.unbox(key: "BrandID")
        self.ModelID =  try  unboxer.unbox(key: "ModelID")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.ModelNumber =  try  unboxer.unbox(key: "ModelNumber")
        self.Class1 =  try  unboxer.unbox(key: "Class1")
        self.Class2 =  try  unboxer.unbox(key: "Class2")
        self.ModelSlug =  try  unboxer.unbox(key: "ModelSlug")
        self.ModelImage =  try  unboxer.unbox(key: "ModelImage")
        self.CategoryName =  try  unboxer.unbox(key: "CategoryName")
        self.BrandName =  try  unboxer.unbox(key: "BrandName")
        self.WirePrice =  try  unboxer.unbox(key: "WirePrice")
        self.video =  try  unboxer.unbox(key: "video")
    }
}

