//
//  WatchList.swift
//  EssentialWatches
//
//  Created by Vikram on 15/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct LatestWatchProduct
{
    let ItemID  : String
    let InStock  : String
    let Name  : String
    let ShortDesc : String
    let Image : String
    let Image_full : String
    let Case : String
    let CaseSize : String
    let Movement : String
    let Dial : String
    let condition : String
    let Bracelet : String
    let KnownAs1 : String
    let KnownAs2 : String
    let KnownAs3 : String
    let KnownAs4 : String?
    let KnownAs5 : String?
    
    //NEw CHANGE
    let LastKnownRetailPrice : String
    let YourPrice : String
    let RetailPrice : String?
    let Video : String?
}

/*
"ItemID": "51223",
"InStock": "1",
"Name": "Royal Oak Automatic in Rose Gold on Brown Crocodile Leather Strap with Silver Waffle Dial",
"Ref": "15450OR.OO.D088CR.01",
"ShortDesc": "",
"Image": "https:\/\/b0650f7f058d5f70d743-97d5bb3f4194bc3eff7a94253e4a4e28.ssl.cf1.rackcdn.com\/51223_SM_1323.jpg",
"Image_full": "https:\/\/b0650f7f058d5f70d743-97d5bb3f4194bc3eff7a94253e4a4e28.ssl.cf1.rackcdn.com\/51223_MAIN_3909.jpg",
"Case": "Rose Gold",
"CaseSize": "37mm",
"Movement": "Automatic",
"Dial": "Silver Waffle Dial",
"condition": "New wB wP",
"Bracelet": "Brown Crocodile Leather ",
"KnownAs1": "15450OR-OO-D088CR-01",
"KnownAs2": "15450OR\/OO\/D088CR\/01",
"KnownAs3": "15450OROOD088CR01",
"KnownAs4": "",
"KnownAs5": ""
*/

extension LatestWatchProduct : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.ItemID =  try  unboxer.unbox(key: "ItemID")
        self.InStock =  try  unboxer.unbox(key: "InStock")
        self.Name =  try  unboxer.unbox(key: "Name")
        self.ShortDesc =  try  unboxer.unbox(key: "ShortDesc")
        self.Image =  try  unboxer.unbox(key: "Image")
        self.Image_full =  try  unboxer.unbox(key: "Image_full")
        self.Case =  try  unboxer.unbox(key: "Case")
        self.CaseSize =  try  unboxer.unbox(key: "CaseSize")
        self.Movement =  try  unboxer.unbox(key: "Movement")
        self.Dial =  try  unboxer.unbox(key: "Dial")
        self.condition =  try  unboxer.unbox(key: "condition")
        self.Bracelet =  try  unboxer.unbox(key: "Bracelet")
        self.KnownAs1 =  try  unboxer.unbox(key: "KnownAs1")
        self.KnownAs2 =  try  unboxer.unbox(key: "KnownAs2")
        self.KnownAs3 =  try  unboxer.unbox(key: "KnownAs3")
        self.KnownAs4 =  try?  unboxer.unbox(key: "KnownAs4")
        self.KnownAs5 =  try?  unboxer.unbox(key: "KnownAs5")
        
        self.LastKnownRetailPrice =  try  unboxer.unbox(key: "LastKnownRetailPrice")
        self.YourPrice =  try  unboxer.unbox(key: "YourPrice")
        self.RetailPrice =  try?  unboxer.unbox(key: "RetailPrice")
        self.Video =  try?  unboxer.unbox(key: "Video")
        
        
    }
}

