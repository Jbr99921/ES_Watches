//
//  Product.swift
//  EssentialWatches
//
//  Created by Vikram on 11/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct SubVariation{
    let BrandID : String?
    let SubModelName: String
    let SubModel_Slug : String
    let SubModel_Image : String?
    let IsSubModelVariation : String?
}

extension SubVariation : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.BrandID =  try?  unboxer.unbox(key: "BrandID")
        self.SubModelName =  try  unboxer.unbox(key: "SubModelName")
        self.SubModel_Slug =  try  unboxer.unbox(key: "SubModel_Slug")
        self.SubModel_Image =  try?  unboxer.unbox(key: "SubModel_Image")
        self.IsSubModelVariation =  try?  unboxer.unbox(key: "IsSubModelVariation")
    }
}
