//
//  SubModel.swift
//  EssentialWatches
//
//  Created by msp on 20/11/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import Unbox

struct SubModel{
    let ModelImage : String?
    let ModelID : String?
    let ModelName: String
    let ModelSlug : String
    let Count : String?
    let is_submodel: String?
    let IsSubVariation: String?
    
    
}

extension SubModel : Unboxable
{
    init(unboxer: Unboxer) throws {
        self.ModelImage =  try?  unboxer.unbox(key: "ModelImage")
        self.Count =  try?  unboxer.unbox(key: "Count")
        self.ModelID =  try?  unboxer.unbox(key: "ModelID")
        self.ModelName =  try  unboxer.unbox(key: "ModelName")
        self.ModelSlug =  try  unboxer.unbox(key: "ModelSlug")
        self.is_submodel = try? unboxer.unbox(key: "is_submodel")
        self.IsSubVariation = try? unboxer.unbox(key: "IsSubVariation")
    }
}
