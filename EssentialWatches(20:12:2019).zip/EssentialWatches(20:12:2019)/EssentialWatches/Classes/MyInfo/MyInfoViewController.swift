//
//  MyInfoViewController.swift
//  EssentialWatches
//
//  Created by Zarna on 23/02/18.
//  Copyright © 2018 MSP. All rights reserved.
//

import UIKit
import IQKeyboardManager
import ZVProgressHUD
import Alamofire

class MyInfoViewController: BaseViewController {
    @IBOutlet weak var txtFirstName: ECW_TextField!
    @IBOutlet weak var txtLastName: ECW_TextField!
    @IBOutlet weak var txtEmail: ECW_TextField!
    @IBOutlet weak var txtPhoneNum: ECW_TextField!
    @IBOutlet weak var btnSubmit: UIButton!
    
      @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!
    
    
    var isWishlist: Bool = false
    var strItemId: NSString = ""
    var wishStatus: NSString = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        IQKeyboardManager.shared().disabledToolbarClasses.add(AppoinmentViewController.self)
        
        self.setupInitialDesignScreen()
        
        if DeviceUtility.isIphoneXType{
            layoutConstraintTopViewTopSpace.constant =  25
        }else{
            layoutConstraintTopViewTopSpace.constant =  5
        }
        
    }
    
    func setupInitialDesignScreen() {
        
        self.setTitleLabel(title: "My Info")

        if isWishlist {
//            self.setTitleLabel(title: "Wishlist")
//            self.btnSubmit.setTitle("Add to Wishlist", for: .normal)
            
        }else{
            self.setIsRequiedMenuYes()
            
        }
        self.btnSubmit.setTitle("Submit", for: .normal)

//        if wishStatus == "N" {
//            self.btnSubmit.setTitle("Remove from Wishlist", for: .normal)
//            
//        }else{
//            self.btnSubmit.setTitle("Add to Wishlist", for: .normal)
//            
//        }
        let dictTemp  = UserDefaults.standard.value(forKey: KConstant.kUserDetail) as? NSDictionary
        if (dictTemp != nil) {
            txtFirstName.text = dictTemp?.value(forKey:KConstant.kFirstName) as? String
            txtLastName.text = dictTemp?.value(forKey:KConstant.kLastName) as? String
            txtPhoneNum.text = dictTemp?.value(forKey:KConstant.kMobileNum) as? String
            txtEmail.text = dictTemp?.value(forKey:KConstant.kEmail) as? String
        }
    }
    
    @IBAction func buttonSubmitClicked(_ sender: UIButton)
    {
        self.view.endEditing(true)
        if (txtFirstName.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter First Name.")
            return
        }
        if (txtLastName.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Last Name.")
            return
        }
        if (txtEmail.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Email.")
            return
        }
        
        if self.validateEmail(strEmail: txtEmail.text!) == false{
            self.displayAlertWithOk(message: "Please Enter Valid Email.")
            return
        }
        
        if (txtPhoneNum.text?.isEmpty)! {
            self.displayAlertWithOk(message: "Please Enter Phone Number.")
            return
        }
        
        let dict:NSDictionary = [KConstant.kFirstName: txtFirstName.text ?? "", KConstant.kLastName: txtLastName.text ?? "", KConstant.kMobileNum : txtPhoneNum.text ?? "", KConstant.kEmail : txtEmail.text ?? ""]
        KConstant.APP.saveValueInUserDefault(dict: dict)
        
        if isWishlist {
             self.progressShow(true) //ProgressHUD.show()
            self.getadd_remove_wish_list(strStatus: "Y", dictDetail: dict)
        }else{
            self.displayAlertWithCompletion(message:"Your Info Added Successfully", completion: {
                self.navigationController?.popToRootViewController(animated: true)
                self.objHomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                self.objNavigationController =  UINavigationController.init(rootViewController: self.objHomeViewController)
                
                self.objNavigationController.isNavigationBarHidden = true
                KConstant.APP.objSidePanelController.centerPanel = self.objNavigationController
                KConstant.APP.objSidePanelController.showCenterPanel(animated: true)
                KConstant.APP.objSideMenuVC.nSelectedCell = 0
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
                    if  (KConstant.APP.objSideMenuVC.tblSlideMenu != nil) {
                        KConstant.APP.objSideMenuVC.tblSlideMenu.selectRow(at: NSIndexPath.init(row: 0, section: 0) as IndexPath, animated: true, scrollPosition:.top)
                    }
                }
            })
//            self.displayAlertWithOk(message: "Your Info Added Successfully")

        }
    }
    
    func getadd_remove_wish_list(strStatus: String,dictDetail: NSDictionary)
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
        
        let dictParams = ["itemid":strItemId,"deviceid":uniqueIdentifier,"wish":strStatus,"firstname":dictDetail.value(forKey: KConstant.kFirstName),"lastname":dictDetail.value(forKey: KConstant.kLastName),"email":dictDetail.value(forKey: KConstant.kEmail),"phone":dictDetail.value(forKey: KConstant.kMobileNum)]
        
        ServerRequest.sendServerRequestforGetMethod(dictParam: dictParams as! Dictionary<String, String> , APIName: "add_remove_wish_list.php") { (response, isSuccess) in
            if isSuccess
            {
                let dict : NSDictionary = response as! NSDictionary
                if dict["result"] as! Int == 1{
//                    if strStatus == "Y"{
//                        self.btnSubmit.setTitle("Remove from Wishlist", for: .selected)
//                    }else if strStatus == "N"{
//                        self.btnSubmit.setTitle("Add to Wishlist", for: .normal)
//                    }
                    NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "callAddRemoveWishlist"), object: nil)
                    self.displayAlertWithCompletion(message:dict["message"]  as! String, completion: {
                        self.navigationController?.popViewController(animated: true)
                    })
                }else{
                    self.displayAlertWithCompletion(message:dict["message"]  as! String, completion: {
                        
                    })
                }
                self.progressShow(false) // ProgressHUD.dismiss()
            }else{
                self.progressShow(false) // ProgressHUD.dismiss()
            }
        }
    }
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITextField Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        if  txtFirstName.isFirstResponder {
            txtLastName.becomeFirstResponder()
        }else  if  txtLastName.isFirstResponder {
            txtEmail.becomeFirstResponder()
        }else  if  txtEmail.isFirstResponder {
            txtPhoneNum.becomeFirstResponder()
        }else  if  txtPhoneNum.isFirstResponder {
            txtPhoneNum .resignFirstResponder()
        }
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
