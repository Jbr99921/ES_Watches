//
//  BrandsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire
import Firebase

class BrandsViewController: BaseViewController, UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITextFieldDelegate{

    @IBOutlet weak var collectionViewHome: UICollectionView!
    @IBOutlet weak var labelSubTitle: UILabel!

    var collectionViewLayout: CustomCellFlowLayout!
    var screenSize = CGSize()
    
    var isFromHome = false
    var isViewAllClicked = false

    var arrBrands = Array<Brand>()
    var arrWatchModels = Array<WatchModel>()
    var dictOption  = [String : AnyObject]()
    @IBOutlet var screenViewTop: NSLayoutConstraint!
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - View LifeCycle Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.textFieldSearch.delegate = self

        //let gridFlowLayout = ProductsGridFlowLayout()
        if isFromHome  && !isViewAllClicked {
            self.setTitleLabel(title: "Models")
        }else{
            self.setTitleLabel(title: "Brands")
        }
        
        collectionViewLayout = CustomCellFlowLayout()
        collectionViewHome.collectionViewLayout = collectionViewLayout
//     collectionViewLayout.sectionInset = UIEdgeInsetsMake(0,10,0,10);
        collectionViewLayout.minimumInteritemSpacing = 8
        screenSize = UIScreen.main.bounds.size
        
        if !self.isFromHome {
            self.setIsRequiedMenuYes()
        }
        
        
        let refreshControl: UIRefreshControl = {
            let refreshControl = UIRefreshControl()
            refreshControl.addTarget(self, action:
                #selector(BrandsViewController.handleRefresh(_:)),
                                     for: UIControl.Event.valueChanged)
            refreshControl.tintColor = UIColor.clear
            return refreshControl
        }()
        self.collectionViewHome.addSubview(refreshControl)
        
        
        //Bhavesh 30-Nov'2019``````````
        self.viewHeader.buttonLogo.isHidden = true
        self.setIsRequiedMenuYes()
        //``````````````
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        

        //Bhavesh 2-Dec
        
        self.screenViewTop.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)
                  
        //````````````
        
        Analytics.logEvent("Brands_Screen", parameters: [
            "name": "Brands Screen" as NSObject,
            ])
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Brands Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getBrands()
    {
        if dictOption.count > 0
        {
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
                 self.progressShow(true) //ProgressHUD.show()
            }
            
            let  strCheck = dictOption["nFlag"] as! String
            let objBrand = dictOption["object"] as! Brand

//            let dictParams = [KConstant.kMethod : "brand.php","id":objBrand.BrandID]
            
            let dictParams = [KConstant.kMethod : "brand_models.php","id":objBrand.BrandID]
            
            if strCheck == "0"
            {
                ServerRequest.sendServerRequestWithPostMethod(dictParam: dictParams) { (response, isSuccess) in
                    if isSuccess {
                        self.arrWatchModels = response as! Array<WatchModel>
                        self.collectionViewHome.reloadData()
                    }else{
                    }
                    self.progressShow(false) // ProgressHUD.dismiss()
                }
            }
        }
        else
        {
            
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
                 self.progressShow(true) //ProgressHUD.show()
            }
            
            let dict1 = [KConstant.kMethod : "brand_list.php"]
            ServerRequest.sendServerRequestWithDict(dictParam: dict1) { (response, isSuccess) in
                if isSuccess {
                    self.arrBrands = response as! Array<Brand>
                    self.collectionViewHome.reloadData()
                }else{
                    print("failure\(response)")
                }
                self.progressShow(false) // ProgressHUD.dismiss()
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        if (reachabilityManager?.isReachable)!{
            self.getBrands()
        }else{
            self.displayAlertForNoIntenret()
        }
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Action Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    
    @IBAction func buttonMenuClicked(_ sender: Any) {
        print(KConstant.APP.objSidePanelController)
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func buttonSelectClicked(sender:AnyObject) -> Void {
        let button = sender
        let value = button.tag
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UICollectionView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if dictOption.count > 0 {
            return self.arrWatchModels.count
        }else{
            return KConstant.APP.arrBrands.count
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrandsCell", for: indexPath) as! BrandsCell
        
        if dictOption.count > 0
        {
            let objWatchModel : WatchModel = self.arrWatchModels[indexPath.item] as WatchModel
            cell.labelProduct.text = objWatchModel.ModelName
            let url = URL(string: objWatchModel.ModelImage!)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        }
        else
        {
            let objBrand : Brand = KConstant.APP.arrBrands[indexPath.item] as Brand
            cell.labelProduct.text = objBrand.BrandName
            let url = URL(string: objBrand.BrandImage)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        }
        return cell
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if self.isFromHome && self.dictOption.count > 0
        {
            let objMultiProductsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MultiProductsViewController") as! MultiProductsViewController
         
            if dictOption.count > 0
            {
                let objWatchModel : WatchModel = self.arrWatchModels[indexPath.item] as WatchModel
                objMultiProductsViewController.strModelSlug = objWatchModel.ModelSlug
                let objBrand = dictOption["object"] as! Brand
                objMultiProductsViewController.strBrandID = objBrand.BrandID
                objMultiProductsViewController.strBrandName = objBrand.BrandName
                //objMultiProductsViewController.isFromSubModel = false
            }
            self.navigationController?.pushViewController(objMultiProductsViewController, animated: true)
        }
        else
        {
            let objBrand : Brand = KConstant.APP.arrBrands[indexPath.item] as Brand
            let dict = ["object":objBrand,"nFlag":"0"] as [String : Any]
            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ModelsViewController") as! ModelsViewController
            objModelsViewController.dictOption = dict as [String : AnyObject]
            objModelsViewController.isFromHome =  true
            self.navigationController?.pushViewController(objModelsViewController, animated: true)
        }
        
//        let objSubBrandsViewController = self.storyboard?.instantiateViewController(withIdentifier: "SubBrandsViewController") as! SubBrandsViewController
//        self.navigationController?.pushViewController(objSubBrandsViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (screenSize.width/3)-12    , height: 163);
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------

    override var prefersStatusBarHidden : Bool {
        return false
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    // ------------------------------------------------------------------------------------------------------------------


}
