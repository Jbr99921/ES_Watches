//
//  BrandsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire
import  Firebase

class LatestWatchesViewController: BaseViewController, UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UITextFieldDelegate, UIScrollViewDelegate{
    
    @IBOutlet weak var collectionViewHome: UICollectionView!
    
    var collectionViewLayout: CustomCellFlowLayout!
    var screenSize = CGSize()

    var isFromHome = false
    
    @IBOutlet var layoutConstraintLabelTitleHeight: [NSLayoutConstraint]!
    var nFlag = 0
    
    var arrLatestWatches =  NSMutableArray()
    var arrFeaturedWatches =  NSMutableArray ()
    
    var nPageCountLatest = 12
    var nPageCountFeature = 12
    
    var refreshControlLatest = UIRefreshControl()

    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - View LifeCycle Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.textFieldSearch.delegate = self
        
        collectionViewLayout = CustomCellFlowLayout()
        collectionViewHome.collectionViewLayout = collectionViewLayout
        collectionViewLayout.minimumInteritemSpacing = 8
        screenSize = UIScreen.main.bounds.size
  
//        self.setupRefreshControl()
        
        let refreshControl: UIRefreshControl = {
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
            }

            let refreshControl = UIRefreshControl()
            refreshControl.addTarget(self, action:
                #selector(LatestWatchesViewController.handleRefresh(_:)),
                                     for: UIControl.Event.valueChanged)
            refreshControl.tintColor = UIColor.clear
            return refreshControl
        }()

        self.collectionViewHome.addSubview(refreshControl)
        
        if nFlag == 1
        {
            self.setTitleLabel(title: "Latest Arrivals")

            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
                 self.progressShow(true) //ProgressHUD.show()
                self.getLatestWatches()
            }
        }else{
            self.setTitleLabel(title: "Featured Watches")
            let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
            if !(reachabilityManager?.isReachable)!
            {
                self.displayAlertForNoIntenret()
                return
            }else{
                 self.progressShow(true) //ProgressHUD.show()
                self.getFeaturedWatches()
            }
        }
        
        //Bhavesh 30-Nov'2019``````````
        self.viewHeader.buttonLogo.isHidden = true
        self.setIsRequiedMenuYes()
        //``````````````
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool) {
        
        var strTitle = ""
        if nFlag == 1        {
            strTitle =  "Latest Arrivals"
            Analytics.logEvent("Latest_Arrivals_Screen", parameters: [
                "name": strTitle+" Screen" as NSObject,
                ])
        }else{
            strTitle =  "Featured Watches"
            Analytics.logEvent("Featured_Watches_Screen", parameters: [
                "name": strTitle+" Screen" as NSObject,
                ])
        }

        super.viewWillAppear(animated)
        

//        Analytics.logEvent(strTitle+"Screen", parameters: [
//            "name": strTitle+" Screen" as NSObject,
//            ])
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: strTitle+" Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
        
         self.progressShow(true) //ProgressHUD.show()

        if nFlag == 1 {
            self.arrLatestWatches.removeAllObjects()
            nPageCountLatest = 12
            self.getLatestWatches()
        }else{
            self.arrFeaturedWatches.removeAllObjects()
            nPageCountFeature = 12
            self.getFeaturedWatches()
        }
        
        collectionViewHome.reloadData()
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func getLatestWatches()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let uniqueIdentifier = appDelegate.getDeviceIdentifierFromKeychain()
                 
        let dictParams = [KConstant.kMethod :  "latestwatches_detail.php","deviceid":uniqueIdentifier,"start":String(nPageCountLatest-11),"end":String(nPageCountLatest)]

        ServerRequest.sendServerRequestWithDictForAllLatestWatches(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess
            {
                self.arrLatestWatches.addObjects(from:  response as! Array<LatestWatch>)
                self.collectionViewHome.reloadData()
//                print("Suuccess\(self.arrLatestWatches)")
            }else{
                print("failure\(response)")
            }
            self.progressShow(false) // ProgressHUD.dismiss()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getFeaturedWatches()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
        let dictParams = [KConstant.kMethod :  "featuredwatches_detail.php","start":String(nPageCountFeature-11),"end":String(nPageCountFeature)]

        ServerRequest.sendServerRequestWithDictForAllFeaturedWatches(dictParam: dictParams) { (response, isSuccess) in
            if isSuccess {
                self.arrFeaturedWatches.addObjects(from:  response as! Array<FeaturedWatch>)
                self.collectionViewHome.reloadData()
            }else{
                print("failure\(response)")
            }
            self.progressShow(false) // ProgressHUD.dismiss()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func setupRefreshControl()
    {
        self.refreshControlLatest = UIRefreshControl()
        let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
        
        let compass_background = UIImageView(image: gifImage)
        compass_background.center = CGPoint(x: self.view.frame.size.width/2, y: 30)
        self.refreshControlLatest.tintColor = UIColor.clear
        self.refreshControlLatest.addSubview(compass_background)
        
        self.refreshControlLatest.addTarget(self, action:#selector(LatestWatchesViewController.handleRefresh(_:)),for: UIControl.Event.valueChanged)
        self.collectionViewHome.addSubview( self.refreshControlLatest)
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Action Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonMenuClicked(_ sender: Any) {
        print(KConstant.APP.objSidePanelController)
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func buttonSelectClicked(sender:AnyObject) -> Void {
        let button = sender
        let value = button.tag
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UICollectionView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if nFlag == 1 {
            return self.arrLatestWatches.count
        }else{
            return self.arrFeaturedWatches.count
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BrandsCell", for: indexPath) as! BrandsCell
        
        if nFlag == 1 { // Latest
            let objLatestWatch : LatestWatch = self.arrLatestWatches[indexPath.item] as! LatestWatch
            let objProduct : LatestWatchProduct = objLatestWatch.Product
            cell.labelProduct.text = objLatestWatch.BrandName
            cell.labelWatchInfo.text = objProduct.Name
            cell.labelWirePrice.text =  "Wire Price : " + objLatestWatch.WirePrice
            let url = URL(string: objProduct.Image)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//            cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
        }
        else
        { // Featured
            let objFeatureWatch : FeaturedWatch = self.arrFeaturedWatches[indexPath.item] as! FeaturedWatch
            cell.labelProduct.text = objFeatureWatch.BrandName
            cell.labelWatchInfo.text = objFeatureWatch.ModelName
            cell.labelWirePrice.text =  "Wire Price : " + objFeatureWatch.WirePrice
            let url = URL(string: objFeatureWatch.ModelImage)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//         cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
            
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
            cell.imageViewProduct.contentMode = .scaleAspectFill
            cell.imageViewProduct.clipsToBounds = true
        }
        
        if KConstant.IS_IPHONE_6 || KConstant.IS_IPHONE_6P{
            cell.layoutImageViewHeight.constant = 100
        }
        
        self.setAdjustableLabel(label:  cell.labelWirePrice)
        return cell
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        if nFlag == 1 { // Latest
            let objLatestWatch : LatestWatch = self.arrLatestWatches[indexPath.item] as! LatestWatch
//            objProductDetailsViewController.objLatestWatch = objLatestWatch
//            objProductDetailsViewController.strOptionFromLatestOrFeature = "latest"
            objProductDetailsViewController.strItemID = objLatestWatch.Product.ItemID
   //         objProductDetailsViewController.strCategoryName = objLatestWatch.CategoryName
        }else{
            let objFeatureWatch : FeaturedWatch = self.arrFeaturedWatches[indexPath.item] as! FeaturedWatch
//            objProductDetailsViewController.objFeaturedWatch = objFeatureWatch
//            objProductDetailsViewController.strTitle = objFeatureWatch.Product.Name
//            objProductDetailsViewController.strCategoryName = objFeatureWatch.CategoryName
//            objProductDetailsViewController.strOptionFromLatestOrFeature = "feature"
            objProductDetailsViewController.strItemID = objFeatureWatch.Product.ItemID
        }
        
        objProductDetailsViewController.isRequiedCubeAnimation = false
        self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if KConstant.IS_IPHONE5 {
            return CGSize(width: (screenSize.width/3)-12, height: 162);
        }else{
            return CGSize(width: (screenSize.width/3)-12, height: 175);
        }
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UICollectionView Footer Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView
    {
        let view1 = UICollectionReusableView()
        switch kind
        {
        case UICollectionView.elementKindSectionHeader:
            assert(false, "Unexpected element kind")
        case UICollectionView.elementKindSectionFooter:
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView", for: indexPath as IndexPath) as! GIFImageCollectionFooterView
            let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
            view.imageViewGIF.image = gifImage
            return view
        default:
            assert(false, "Unexpected element kind")
        }
        return view1
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if nFlag == 1 && self.arrLatestWatches.count == 0 {
            return CGSize(width: collectionView.frame.size.width, height: 0)
         }
       return CGSize(width: collectionView.frame.size.width, height: 60)
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
            // then we are at the top
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
           if nFlag == 1
            {
                    // self.progressShow(true) //ProgressHUD.show()
                    nPageCountLatest = nPageCountLatest + 12
                    self.getLatestWatches()
            }else{
                    // self.progressShow(true) //ProgressHUD.show()
                    nPageCountFeature = nPageCountFeature + 12
                    self.getFeaturedWatches()
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    
}
