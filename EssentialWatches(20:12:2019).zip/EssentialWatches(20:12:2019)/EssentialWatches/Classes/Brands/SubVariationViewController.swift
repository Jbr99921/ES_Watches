//
//  ModelsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Kingfisher
import Alamofire
import Firebase

class SubVariationViewController: BaseViewController, UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIScrollViewDelegate,ModelCellDelegate{

//@IBOutlet weak var collectionViewHome: UICollectionView!
//@IBOutlet  var collectionViewWatch: UICollectionView!
    @IBOutlet weak var labelSubTitle: UILabel!
    @IBOutlet weak var tableViewModels: UITableView!
    @IBOutlet var screenViewTop: NSLayoutConstraint!
    
// var collectionViewLayout: CustomCellFlowLayout!
    var screenSize = CGSize()
    
    var isFromHome = false
    var isViewAllClicked = false
    var isPullToRefreshCalled = false
    var strBrandId = ""
    var strModelSlug = ""
    var strSubModelSlug = ""
    var strVariationSlug = ""
    var arrBrands = Array<Brand>()
    var dictOption  = [String : AnyObject]()
    var nPageCount = 10
    var nPageCountRecent = 10
    var numberofSection = 0;
    var arrWatchRecent = NSMutableArray ()
    var arrWatchModels = NSMutableArray ()
    var arrRolexNon_Sport = NSMutableArray ()
    var isRecentFetched = false
    var isModelFetched = false
    var nameofTheWatch = ""
    
    var arrMenu = ["SELL YOUR WATCH","GET YOUR WATCH AUTHENTICATED"]
    var arrMenu1 = ["TRADE-IN YOUR WATCH","CERTIFIED APPRIASAL"]

    var nRequiredLoaderLatest = 1
    var nRequiredLoaderModels = 1

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        if dictOption.count > 0
        {
            let  strCheck = dictOption["nFlag"] as! String
//            let objBrand = dictOption["object"] as! Brand
//            let name = objBrand.BrandName
//            nameofTheWatch = name
        }
        
        self.textFieldSearch.delegate = self
        screenSize = UIScreen.main.bounds.size

        if !self.isFromHome {
            self.setIsRequiedMenuYes()
        }
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
             self.progressShow(true) //ProgressHUD.show()
            self.method1()
        }
        
        self.showHeaderLogo()
        
        
        //Bhavesh 30-Nov
        
            self.screenViewTop.constant = (self.viewHeader.frame.origin.y + self.viewHeader.frame.height + 1)

    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool)
    {
        //Bhavesh 2-Dec
        
        self.tabBarController?.tabBar.isHidden = true
        self.tabBarController?.tabBar.layer.zPosition = -1
        self.tabBarController?.tabBar.isTranslucent = true
        
        //``````````````
        
        
         self.nRequiredLoaderLatest = 1
         self.nRequiredLoaderModels = 1
        

        Analytics.logEvent("Models_Screen", parameters: [
            "name": "Models Screen" as NSObject,
            ])
        

    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func getModels()
    {
        let dictParams = [KConstant.kMethod : "submodel_variation_list.php","BrandId":self.strBrandId,"ModelSlug":strModelSlug,"SubModelSlug":strSubModelSlug,"SubVariationSlug":strVariationSlug]
        
        ServerRequest.sendServerRequestSubVariation(dictParam: dictParams) { (response, isSuccess) in
                    if isSuccess
        {
                        let arrResponse = response as! Array<Model>
                        self.arrWatchModels.addObjects(from: arrResponse)
                        self.tableViewModels.reloadData()
                    }else{
                        print("failure\(response)")
                    }
                    self.progressShow(false) // ProgressHUD.dismiss()
        }
   }
    // ------------------------------------------------------------------------------------------------------------------
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getRecentModels()
    {
        if dictOption.count > 0
        {
          //  let  strCheck = dictOption["nFlag"] as! String
          //  let objBrand = dictOption["object"] as! WatchModel
            
            
            // nPageCountRecent
            
//            var tempPageCount = self.nPageCountRecent-9 as Int
//
//            if self.nPageCountRecent == 10 {
//                tempPageCount = 0
//            }
            
            let dictParams = [KConstant.kMethod : "latest_arrivals_used_rolex.php","BrandId":strBrandId,"ModelSlug":strModelSlug]
            
//            if strCheck == "0"
//            {
                ServerRequest.sendServerRequestWithPostMethodForRecentWatches(dictParam: dictParams) { (response, isSuccess) in
                    if isSuccess {
                        let arrResponse = response as! Array<RecentWatch>
//                     self.arrWatchRecent.addObjects(from: arrResponse)
                        
                        if arrResponse.count == 0{
                            self.nRequiredLoaderLatest = 0
                        }
                        
                        if self.arrWatchRecent.count >= 10
                        {
                            if  arrResponse.count > 0{
                                for i in 0 ..< arrResponse.count
                                {
                                    let objRecentWatchResponse : RecentWatch = arrResponse[i] as RecentWatch
                                    let objRecentWatchStored : RecentWatch = self.arrWatchRecent[i] as! RecentWatch
                                    if objRecentWatchResponse.id !=  objRecentWatchStored.id {
                                        self.arrWatchRecent.add(objRecentWatchResponse)
                                    }
                                }
                            }
                            
                        }
                        else
                        {
                            self.arrWatchRecent.addObjects(from: arrResponse)
                        }
                        
                        print("I finished First")
                        self.tableViewModels.reloadData()
                    }else{
                        print("failure\(response)")
                    }
                }
            }
        //}
    }
    
    // ------------------------------------------------------------------------------------------------------------------
   
    func method1(){
        self.getRecentModels()
        
        self.method2 {
//            if numberofSection == 3
            
                self.getModels()
          
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func method2(completion: () -> Void) {
        completion()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonMenuClicked(_ sender: Any) {
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------


    func buttonSelectClicked(sender:AnyObject) -> Void {
        let button = sender
        let value = button.tag
    }
    
  
    override var prefersStatusBarHidden : Bool {
        return false
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func handleRefresh(_ refreshControl: UIRefreshControl)
    {
        self.tableViewModels.isHidden = true
        
        self.nPageCountRecent = 10
        self.arrWatchRecent.removeAllObjects()
        self.getRecentModels()

        self.nPageCount = 10
        self.arrWatchModels.removeAllObjects()
        
        
        self.getModels()
       
       
        
        refreshControl.endRefreshing()
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Action Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func navigateItemAt(sender: UIButton){
        //...
        var objNotificationViewController = FormsViewController()
        objNotificationViewController = self.storyboard?.instantiateViewController(withIdentifier: "FormsViewController") as! FormsViewController
        
        var a:Int = 0
        
        if sender.tag == 0 {
            a = 5
        }
        else if sender.tag == 1{
            a = 6
        }
        else if sender.tag == 2{
            a = 7
        }
        else if sender.tag == 3 {
            a = 8
        }
        objNotificationViewController.nIndex = a
        objNotificationViewController.isFromHome = true
        self.navigationController?.pushViewController(objNotificationViewController, animated: true)
    }

    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITableView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let  viewHeader = HeaderTitleView.instanceFromNib() as! HeaderTitleView
        let objBrand = dictOption["object"] as! Model

            if section == 1 {
                viewHeader.labelTitle.text = "Latest " + objBrand.SubModelName + " Watches Added to Our Site:"
            }else if section == 0 {
                viewHeader.labelTitle.text = "All " + objBrand.SubModelName + " Models :"
            }

         viewHeader.labelTitle.font = viewHeader.labelTitle.font.withSize(14)
        viewHeader.layoutConstraintLabelTitleTopSpace.constant = 11
        viewHeader.buttonShowAll.isHidden = true
        viewHeader.imageViewArrow.isHidden = true
        return viewHeader
    }
    
     // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {

        if self.arrWatchModels.count > 0 && section == 1{
            return 46
        }else  if self.arrWatchRecent.count > 0 && section == 0{
            return 46
        }
            return 0
    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        else{
            return 1
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func numberOfSections(in tableView: UITableView) -> Int{
        return 2
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
            if(indexPath.section == 0)
            {
                if self.arrWatchRecent.count > 0{
                    return 183
                }else{
                    return 0
                }
            }
            else  if(indexPath.section == 1)
            {
                return 183
                
                var temp = 0
                if(self.arrWatchModels.count % 3 == 0)
                {
                    temp = self.arrWatchModels.count/3;
                }
                else
                {
                    temp = self.arrWatchModels.count/3;
                    temp = temp + 1;
                }
                return  CGFloat(195  * temp)
            }
//            else
//            {
                return 0
//            }
//        }
        
   
    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.00001
    }
    
    // -----------------------------------------------------------------------------------------    -------------------------

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
//          let cell : ModelTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ModelTableViewCell", for: indexPath ) as! ModelTableViewCell
//                        cell.delegate = self
//                        cell.collectionViewHome.tag = 3
//                        cell.collectionViewHome.isHidden = false
//                        cell.collectionViewWatch.isHidden = true
//                        if self.arrWatchModels.count > 0{
//                        cell.setCollectionDataForVariation(self.arrWatchModels, withIndex: 1, isRequiredLoaderModels: self.nRequiredLoaderModels)
//                        }
//            return cell
        
        
        let cell : ModelTableViewCell
        

            if indexPath.section == 1
            {
                let cell : ModelTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ModelTableViewCell", for: indexPath ) as! ModelTableViewCell
                cell.delegate = self
                cell.collectionViewHome.isHidden = true
                cell.collectionViewWatch.isHidden = false
                if self.arrWatchRecent.count > 0{
                    cell.setCollectionDataForLatestArrivalWatches(self.arrWatchRecent as! Array<RecentWatch>, withIndex: 0,isRequiredLoaderLatest:0)
                }
                return cell
            }
            else if indexPath.section == 0
            {
                let cell : ModelTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ModelTableViewCell", for: indexPath ) as! ModelTableViewCell
                cell.delegate = self
                cell.collectionViewHome.tag = 3
                cell.collectionViewHome.isHidden = false
                cell.collectionViewWatch.isHidden = true
                if self.arrWatchModels.count > 0{
                cell.setCollectionDataForVariation(self.arrWatchModels, withIndex: 1, isRequiredLoaderModels: 0)
                }
                return cell
            }

        return UITableViewCell()

    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func handle(withNotification notification : NSNotification)
    {
        let dictObject  = notification.object as! Dictionary<String, Any>
//        print(dictObject)
        let  strCheck = dictObject["nFlag"] as! String
        var strSubModel = "0"

            if strCheck == "1"
        {
            if dictObject["is_submodel_data"]! != nil {
                strSubModel = dictObject["is_submodel_data"]! as! String
            }
        }
        //}
 
        if (strSubModel == "1") {
                let objBrand = dictObject["object"] as! WatchModel
               // print(objBrand)
                let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "SubModelsViewController") as! SubModelsViewController
                objModelsViewController.dictOption = dictObject as [String : AnyObject]
                objModelsViewController.isFromModel =  true
                objModelsViewController.strBrandId = strBrandId

                self.navigationController?.pushViewController(objModelsViewController, animated: true)
        }
        else
        {
            if strCheck == "0"
            {
                let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
                let objRecentWatch = dictObject["object"] as! RecentWatch
                print("All Data =",dictObject["object"] ?? "0")
                objModelsViewController.strItemID = objRecentWatch.id
                let objBrand = dictOption["object"] as! WatchModel
                objModelsViewController.strBrandID = strBrandId
                objModelsViewController.strBrandName = objBrand.ModelSlug
                
                
                objModelsViewController.isFromMultipleScreen = true
                objModelsViewController.isLatestFromModel = true
                objModelsViewController.isRequiedCubeAnimation = false
                self.navigationController?.pushViewController(objModelsViewController, animated: true)
                return
            }
            else   if strCheck == "1"
            {
//                if !(self.navigationController?.topViewController is MultiProductsViewController)
//                {
                    let objMultiProductsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MultiProductsViewController") as! MultiProductsViewController
                    let objWatchModel = dictObject["object"] as! WatchModel
                    objMultiProductsViewController.strModelSlug = objWatchModel.ModelSlug
                    objMultiProductsViewController.strModelName = objWatchModel.ModelName
                    let objBrand = dictOption["object"] as! WatchModel
                    objMultiProductsViewController.strBrandID = strBrandId
                    objMultiProductsViewController.strBrandName = objBrand.ModelSlug
                
                    self.navigationController?.pushViewController(objMultiProductsViewController, animated: true)
                    return
//                }
            }
            else   if strCheck == "2" // Load more section0
            {
                self.nPageCountRecent = self.nPageCountRecent + 10
                self.getRecentModels()
            }else   if strCheck == "3"   // Load more section1
            {
                self.nPageCount = self.nPageCount + 10
                
                self.getModels()
                
            }

        }
       
    }
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
//
//    func scrollViewDidScroll(_ scrollView: UIScrollView)
//    {
//        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
//        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
//        let scrollOffset: Float = Float(scrollView.contentOffset.y)
//
//        if scrollOffset == 0 {
//            // then we are at the top
//            if self.arrWatchModels.count <= 6 {
//                self.nPageCount = self.nPageCount + 11
//                self.getModels()
//            }
////            self.nPageCount = self.nPageCount + 11
////            self.getModels()
//        }
//        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
//        {
//            self.nPageCount = self.nPageCount + 11
//            self.getModels()
//        }
//    }
    // ------------------------------------------------------------------------------------------------------------------

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func reloadLatestArrivalsSection0(){
//         self.progressShow(true) //ProgressHUD.show()
        self.nPageCountRecent = self.nPageCountRecent + 10
        self.getRecentModels()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func reloadModelsSection1(){
    //         self.progressShow(true) //ProgressHUD.show()
    //    self.nPageCount = self.nPageCount + 10
    //    self.getModels()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func cellSelectedUsingDict(_ dict: Dictionary<String, Any>)
    {
        let dictObject  = dict
        let  strCheck = dictObject["nFlag"] as! String
        var strSubModel = "0"

         let objWatchModel = dictObject["object"] as! Model

        if (objWatchModel.IsSubModelVariation == "1")
        {
             let objVariationViewController = self.storyboard?.instantiateViewController(withIdentifier: "SubVariationViewController") as! SubVariationViewController
            objVariationViewController.dictOption = dict as [String : AnyObject]
            objVariationViewController.isFromHome =  true
            objVariationViewController.strBrandId = strBrandId
            objVariationViewController.strModelSlug = strModelSlug
            objVariationViewController.strSubModelSlug = strSubModelSlug
            objVariationViewController.strVariationSlug = objWatchModel.SubModel_Slug
            self.navigationController?.pushViewController(objVariationViewController, animated: true)
        }
        else
        {
            if strCheck == "0"
            {
                let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
                let objRecentWatch = dictObject["object"] as! RecentWatch
                print("All Data =",dictObject["object"] ?? "0")
                objModelsViewController.strItemID = objRecentWatch.id
                let objBrand = dictOption["object"] as! Brand
                objModelsViewController.strBrandID = objBrand.BrandID
                objModelsViewController.strBrandName = objBrand.BrandName
                
                
                objModelsViewController.isFromMultipleScreen = true
                objModelsViewController.isLatestFromModel = true
                objModelsViewController.isRequiedCubeAnimation = false
                self.navigationController?.pushViewController(objModelsViewController, animated: true)
                return
            }
            else   if strCheck == "1"
            {
                
                let objMultiProductsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MultiProductsViewController") as! MultiProductsViewController
                let objWatchModel = dictObject["object"] as! Model
                objMultiProductsViewController.strModelSlug = strModelSlug
                objMultiProductsViewController.strModelName = objWatchModel.SubModelName
                objMultiProductsViewController.strSubModelSlug = strSubModelSlug
                objMultiProductsViewController.strSelectedVariation = self.strVariationSlug
                objMultiProductsViewController.strSubVariationSlug = objWatchModel.SubModel_Slug
                objMultiProductsViewController.strBrandID = strBrandId
                //objMultiProductsViewController.isFromSubModel = false
                //objModelsViewController.isFromMultipleScreen = true
                self.navigationController?.pushViewController(objMultiProductsViewController, animated: true)
                return
                //                }
            }
            else   if strCheck == "2" // Load more section0
            {
                self.nPageCountRecent = self.nPageCountRecent + 10
                self.getRecentModels()
            }
            
        }

    }
    
    // ------------------------------------------------------------------------------------------------------------------

}
