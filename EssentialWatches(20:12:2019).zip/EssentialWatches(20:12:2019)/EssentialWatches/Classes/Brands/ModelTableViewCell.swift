//
//  ModelTableViewCell.swift
//  EssentialWatches
//
//  Created by Vikram on 13/10/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

protocol ModelCellDelegate {
    func reloadLatestArrivalsSection0()
    func reloadModelsSection1()
    func cellSelectedUsingDict(_ dict: Dictionary<String , Any> )
}

class ModelTableViewCell: UITableViewCell,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{

    @IBOutlet weak var collectionViewHome: UICollectionView!
    @IBOutlet  var collectionViewWatch: UICollectionView!
    @IBOutlet  var layoutConstraintCollectionViewHomeHeight: NSLayoutConstraint!

    var arrWatchModels = NSMutableArray()
    var arrWatchRecent = Array<RecentWatch>()
    var delegate : ModelCellDelegate?

    var nRequiredLoaderLatest:Int = 1
    var nRequiredLoaderAllModels:Int = 1

    // ------------------------------------------------------------------------------------------------------------------
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        self.collectionViewHome.register(GIFImageCollectionFooterView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView")
//        collectionViewHome.isScrollEnabled = false
    }

    // ------------------------------------------------------------------------------------------------------------------

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    func setCollectionDataForLatestArrivalWatches(_ collectionData: Array<RecentWatch>, withIndex nIndex: Int, isRequiredLoaderLatest : Int)
    {
        self.collectionViewWatch?.register(UINib(nibName: "LatestModelCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        self.arrWatchRecent = collectionData
        self.collectionViewWatch?.tag = 0
        self.collectionViewWatch.dataSource = self
        self.collectionViewWatch.delegate = self
        self.nRequiredLoaderLatest = isRequiredLoaderLatest
        
//        self.collectionViewWatch.register(GIFImageCollectionFooterView.self, forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView")
        self.collectionViewWatch?.reloadData()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func setCollectionDataForModels(_ collectionData: NSMutableArray, withIndex nIndex: Int, isRequiredLoaderModels : Int)
    {
        // ALL Non-Sport Models
        self.collectionViewHome?.register(UINib(nibName: "LatestModelCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        self.arrWatchModels = collectionData
        self.collectionViewHome?.tag = 1
        self.nRequiredLoaderAllModels = isRequiredLoaderModels
        self.collectionViewHome?.reloadData()
        self.collectionViewHome.dataSource = self
        self.collectionViewHome.delegate = self
    }
    
    func setCollectionDataForVariation(_ collectionData: NSMutableArray, withIndex nIndex: Int, isRequiredLoaderModels : Int)
       {
           // ALL Non-Sport Models
             self.collectionViewHome?.register(UINib(nibName: "LatestModelCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
                 self.arrWatchModels = collectionData
                 self.collectionViewHome?.tag = 3
                 self.collectionViewHome?.reloadData()
                 self.collectionViewHome.dataSource = self
                 self.collectionViewHome.delegate = self
       }
    
   
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func setCollectionDataForSubModels(_ collectionData: NSMutableArray, withIndex nIndex: Int)
    {
        self.collectionViewHome?.register(UINib(nibName: "LatestModelCell", bundle: nil), forCellWithReuseIdentifier: "HomeProductCollectionViewCell")
        self.arrWatchModels = collectionData
        self.collectionViewHome?.tag = 2
        self.collectionViewHome?.reloadData()
        self.collectionViewHome.dataSource = self
        self.collectionViewHome.delegate = self
    }
    
    // --------------------------------------------------------------------------------------------------------------
    // MARK: - UICollectionViewDataSource methods
    // ------------------------------------------------------------------------------------------------------------------

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView.tag == 0
        {
            if self.arrWatchRecent.count > 0{
                return self.arrWatchRecent.count
            }
        }
        else if collectionView.tag == 1
        {
            if self.arrWatchModels.count > 0{
                return self.arrWatchModels.count
            }
        }
        else if (collectionView == collectionViewHome && collectionView.tag == 3)
        {
            if self.arrWatchModels.count > 0{
            return self.arrWatchModels.count
            }
        }
        else
        {
            if self.arrWatchModels.count > 0{
                return self.arrWatchModels.count
            }
        }
        return 0
    }
     func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
     {
         if  KConstant.IS_IPHONE5 {
                    return CGSize(width: 94, height:183)
                }else  if  KConstant.IS_IPHONE_6 {
                    return CGSize(width: 113, height: 183)
                }else{
        //                if(collectionView.tag == 1)
        //                {
        //                       return CGSize(width: 126, height: self.collectionViewHome.frame.size.height)
        //                }
                    return CGSize(width: 126, height: 183)
                }
    }
    // ------------------------------------------------------------------------------------------------------------------
   
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        if ((collectionView.tag) == 0)
        {
            let cell: HomeProductCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeProductCollectionViewCell", for: indexPath as IndexPath) as! HomeProductCollectionViewCell
            let objRecentWatch : RecentWatch = self.arrWatchRecent[indexPath.item] as RecentWatch
            cell.labelProduct.text = objRecentWatch.class1
            cell.labelProduct.textAlignment = .left
            cell.labelWirePrice.textAlignment = .left
            cell.labelWirePrice.textColor = UIColor.red

            cell.labelWirePrice.numberOfLines = 0
            cell.labelWirePrice.adjustsFontSizeToFitWidth = true
            
            cell.labelWirePrice.text =  "Wire Price : " + objRecentWatch.wireprice!
            let url = URL(string: objRecentWatch.image)!
            let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
//         cell.imageViewProduct.af_setImage(withURL: url, placeholderImage: placeholderImage)
            cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)

            cell.viewBackground .layer.borderColor = UIColor.lightGray.cgColor
            cell.viewBackground .layer.borderWidth = 1.0
            
            cell.imageViewProduct.clipsToBounds = true
            cell.imageViewProduct.contentMode = .scaleAspectFill
            return cell
        }
        else if(collectionView == collectionViewHome && collectionView.tag == 3)
        {
              let cell: HomeProductCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeProductCollectionViewCell", for: indexPath as IndexPath) as! HomeProductCollectionViewCell
                        
                            let objWatchModel : Model = self.arrWatchModels[indexPath.item] as! Model
                            cell.labelProduct.text = objWatchModel.SubModelName
                            cell.labelProduct.textColor = UIColor.black
                            cell.labelProduct.font = UIFont(name:KConstant.kFontOpenSans_Regulare, size: 12 )
            
                            cell.labelProduct.textAlignment = .center
                            cell.labelProduct.widthAnchor.constraint(equalToConstant: self.contentView.frame.height).isActive = true
                            cell.labelProduct.widthAnchor.constraint(equalToConstant: self.contentView.frame.width).isActive = true
                            cell.labelProduct.lineBreakMode = .byWordWrapping
                            cell.labelProduct.numberOfLines = 2
                        
                        //    cell.labelProduct.translatesAutoresizingMaskIntoConstraints = true
                        
            
                            let strImageURL  = "\(objWatchModel.SubModel_Image ?? "")"

                            if strImageURL.characters.count > 0
                            {
                                let url = URL(string:  strImageURL)!
                                let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
                                cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
                            }else{
                              
                            cell.imageViewProduct.image = UIImage(named: KConstant.kImagePlaceholderName)
                            }
                            cell.viewBackground .layer.borderColor = UIColor.lightGray.cgColor
                            cell.viewBackground .layer.borderWidth = 1.0

                            cell.imageViewProduct.clipsToBounds = true
                            cell.imageViewProduct.contentMode = .scaleAspectFill
             return cell
        }
        else
        {
            let cell: HomeProductCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeProductCollectionViewCell", for: indexPath as IndexPath) as! HomeProductCollectionViewCell
            
                let objWatchModel : WatchModel = self.arrWatchModels[indexPath.item] as! WatchModel
                cell.labelProduct.text = objWatchModel.ModelName
                cell.labelProduct.textAlignment = .center
                cell.labelWirePrice.textAlignment = .center
//             cell.labelProductInfo.isHidden = true
                let strItems = String(format: "( %@ Items)","\(objWatchModel.Count ?? "")")
                cell.labelWirePrice.text = strItems
                cell.labelWirePrice.textColor = UIColor.black
            let strImageURL  = "\(objWatchModel.ModelImage ?? "")"
            
                if strImageURL.characters.count > 0
                {
                    let url = URL(string:  strImageURL)!
                    let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
                    cell.imageViewProduct.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)
                }else{
                    cell.imageViewProduct.image = UIImage(named: KConstant.kImagePlaceholderName)
                }
                cell.viewBackground .layer.borderColor = UIColor.lightGray.cgColor
                cell.viewBackground .layer.borderWidth = 1.0

                cell.imageViewProduct.clipsToBounds = true
                cell.imageViewProduct.contentMode = .scaleAspectFill
            
            return cell
        }
    }
    
    
    // ------------------------------------------------------------------------------------------------------------------
    
    /*
    @objc func handle(withNotification notification : NSNotification)
    {
        let dictObject  = notification.object as! Dictionary<String, Any>
        print(dictObject)
        let  strCheck = dictObject["nFlag"] as! String
        
        if strCheck == "0"
        {
            let objBrand = dictObject["object"] as! Brand
            print(objBrand)
            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ModelsViewController") as! ModelsViewController
            objModelsViewController.dictOption = dictObject as [String : AnyObject]
            objModelsViewController.isFromHome =  true
            self.navigationController?.pushViewController(objModelsViewController, animated: true)
        }
        else
        {
            var strItemID = ""
            if strCheck == "1"
            {
                let objLatestWatch : LatestWatch = dictObject["object"] as!  LatestWatch
                let  objFeaturedWatchProduct : LatestWatchProduct = objLatestWatch.Product as LatestWatchProduct
                strItemID = objFeaturedWatchProduct.ItemID
            }else{
                let objFeaturedWatch : FeaturedWatch = dictObject["object"] as!  FeaturedWatch
                let  objFeaturedWatchProduct : LatestWatchProduct = objFeaturedWatch.Product as LatestWatchProduct
                strItemID = objFeaturedWatchProduct.ItemID
            }
            let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
            objProductDetailsViewController.strItemID = strItemID
            self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)
        }
    }
    */

    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if (collectionView.tag == 0)
        {
            let objRecentWatch : RecentWatch = self.arrWatchRecent[indexPath.item] as RecentWatch
            let dict = ["object":objRecentWatch,"nFlag":"0"] as [String : Any]
            delegate?.cellSelectedUsingDict(dict)
            //NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "ModelsCellClickNotification"), object: dict)
        }
        else if (collectionView.tag == 1)
        {
            let objWatchModel : WatchModel = self.arrWatchModels[indexPath.item] as! WatchModel
          //  print(self.arrWatchModels)
            
                var dict =  ["object":objWatchModel,"nFlag":"1" ] as [String : Any]
                if objWatchModel.is_submodel == nil {
                    dict["is_submodel_data"] = "0"
                }else{
                    dict["is_submodel_data"] = objWatchModel.is_submodel!
                }
                delegate?.cellSelectedUsingDict(dict)
                //NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "ModelsCellClickNotification"), object: dict)
        }
        else if (collectionView.tag == 2)
        {
            let objWatchModel : WatchModel = self.arrWatchModels[indexPath.item] as! WatchModel
            //print(self.arrWatchModels)
            
            let dict =  ["object":objWatchModel,"nFlag":"2" ] as [String : Any]
           // dict["is_submodel_data"] = objWatchModel.is_submodel!
            delegate?.cellSelectedUsingDict(dict)
//            NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "SubModelsCellClickNotification"), object: dict)
        }
        else if (collectionView.tag == 3)
                {
                    let objWatchModel : Model = self.arrWatchModels[indexPath.item] as! Model
                    //print(self.arrWatchModels)
                    
                    let dict =  ["object":objWatchModel,"nFlag":"1" ] as [String : Any]
                   // dict["is_submodel_data"] = objWatchModel.is_submodel!
                    delegate?.cellSelectedUsingDict(dict)
        //            NotificationCenter.default.post(name:  NSNotification.Name(rawValue: "SubModelsCellClickNotification"), object: dict)
                }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UICollectionView Footer Methods
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView
    {
        
//        if  self.collectionViewHome.tag == 2
//        {
//            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView",   for: indexPath as IndexPath) as! GIFImageCollectionFooterView
//            let gifImage = UIImage.gifImageWithName("funny1")
//            view.imageViewGIF.isHidden = true;
//            view.imageViewGIF.image = gifImage
//            return view
//        }
//        else
//        {
        
        
        let view1 = UICollectionReusableView()

        switch kind
        {
        case UICollectionView.elementKindSectionHeader:
            assert(false, "Unexpected element kind")
        case UICollectionView.elementKindSectionFooter:
            let view = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "GIFImageCollectionFooterView",   for: indexPath as IndexPath) as! GIFImageCollectionFooterView
                let gifImage = UIImage.gif(name: "funny1") //gifImageWithName("funny1")
                view.imageViewGIF.image = gifImage
            return view
        default:
            assert(false, "Unexpected element kind")
        }
        
        return view1
        //}
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize
    {
        if  self.collectionViewHome.tag == 2 {
            return CGSize(width: 0, height: 0)
        }
        
        if  collectionView.tag == 0 && collectionView == self.collectionViewWatch
        {
            if self.nRequiredLoaderLatest == 0{
                return CGSize(width: 0, height: 0)
            }else{
                return CGSize(width: 60.0, height: collectionView.frame.size.height)
            }
        }
        else  if  collectionView.tag == 1
        {
            if self.nRequiredLoaderAllModels == 0{
                return CGSize(width: 0, height: 0)
            }else{
                return CGSize(width: 60.0, height: collectionView.frame.size.height)
            }
        }
        
        if self.arrWatchRecent.count == 0 {
            return CGSize(width: 0, height: 0)
        }
        
        if collectionView == self.collectionViewWatch ||  collectionView == self.collectionViewHome{
            return CGSize(width: 60.0, height: collectionView.frame.size.height)
        }
        
        return CGSize(width: 0, height: 0)
    }

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView)
    {
        let bottomEdge: Float = Float(scrollView.contentOffset.x + scrollView.frame.size.width)
        if scrollView.contentOffset.x == 0.0 {
            return
        }
        
        if bottomEdge >= Float(scrollView.contentSize.width) {
            if self.collectionViewHome?.tag == 0 {
                delegate?.reloadLatestArrivalsSection0()
            }else {
                delegate?.reloadModelsSection1()
            }
        }
    }
    // ------------------------------------------------------------------------------------------------------------------

}


