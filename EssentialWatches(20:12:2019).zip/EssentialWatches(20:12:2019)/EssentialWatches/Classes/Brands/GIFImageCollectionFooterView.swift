//
//  GIFImageCollectionFooterView.swift
//  EssentialWatches
//
//  Created by Vikram on 06/12/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class GIFImageCollectionFooterView: UICollectionReusableView {
        
    @IBOutlet weak var imageViewGIF: UIImageView!
}
