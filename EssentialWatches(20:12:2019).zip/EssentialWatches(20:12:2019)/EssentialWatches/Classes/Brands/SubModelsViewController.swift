//
//  ModelsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Kingfisher
import Alamofire
import Firebase


class SubModelsViewController: BaseViewController, UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIScrollViewDelegate,ModelCellDelegate{

//    @IBOutlet weak var collectionViewHome: UICollectionView!
//    @IBOutlet  var collectionViewWatch: UICollectionView!
    @IBOutlet weak var labelSubTitle: UILabel!

    @IBOutlet weak var tableViewModels: UITableView!
    
//    var collectionViewLayout: CustomCellFlowLayout!
    var screenSize = CGSize()
    
    var isFromModel = false
    var isViewAllClicked = false
    var isPullToRefreshCalled = false

    var arrBrands = Array<Brand>()
    var dictOption  = [String : AnyObject]()
    var nPageCount = 10
    var nPageCountRecent = 10
    var numberofSection = 0;
    var arrWatchRecent = NSMutableArray ()
    var arrWatchModels = NSMutableArray ()
    var arrRolexNon_Sport = NSMutableArray ()
    var isRecentFetched = false
    var isModelFetched = false
    var nameofTheWatch = ""
    var strBrandId = ""
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
        if dictOption.count > 0
        {
//            let  strCheck = dictOption["nFlag"] as! String
//            let objWatch = dictOption["object"] as! WatchModel
            
            
     //       let objBrand = dictOption["object"] as! Brand
//            var name = objWatch.BrandName
//            nameofTheWatch = name
            numberofSection = 1
//            if nameofTheWatch == "Rolex" || nameofTheWatch == "Used Rolex" {
//                numberofSection = 3
//            }
//            if name.range(of:"Rolex") != nil {
//
//                //self.getRolexSport()
//                numberofSection = 3
//                print("exists")
//            }
//            else
//            {
//                numberofSection = 2
//            }
        }
        
        

        self.textFieldSearch.delegate = self
        screenSize = UIScreen.main.bounds.size

    //    NotificationCenter.default.addObserver(self, selector: #selector(SubModelsViewController.handle(withNotification:)), name: NSNotification.Name(rawValue: "SubModelsCellClickNotification"), object: nil)
        
        if !self.isFromModel {
            self.setIsRequiedMenuYes()
        }
        
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
         self.progressShow(true) //ProgressHUD.show()

        self.method1()
        
        self.showHeaderLogo()

//        self.getModels()
//        self.getRecentModels()
        
//        let refreshControl: UIRefreshControl = {
//            let refreshControl = UIRefreshControl()
//            refreshControl.addTarget(self, action:
//                #selector(ModelsViewController.handleRefresh(_:)),
//                                     for: UIControlEvents.valueChanged)
//            refreshControl.tintColor = UIColor.clear
//            return refreshControl
//        }()
//        self.tableViewModels.addSubview(refreshControl)
    }

    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        

        
        Analytics.logEvent("Sub_Models_Screen", parameters: [
            "name": "SubModels Screen" as NSObject,
            ])
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "SubModels Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    
    func getRecentModels()
        {
            if dictOption.count > 0
            {
                let  strCheck = dictOption["nFlag"] as! String
                let objBrand = dictOption["object"] as! WatchModel
                
                
                // nPageCountRecent
                
                var tempPageCount = self.nPageCountRecent-9 as Int
                
                if self.nPageCountRecent == 10 {
                    tempPageCount = 0
                }
                
                let dictParams = [KConstant.kMethod : "latest_arrivals_used_rolex.php","BrandId":strBrandId,"ModelSlug":objBrand.ModelSlug]
                
             
                    ServerRequest.sendServerRequestWithPostMethodForRecentWatches(dictParam: dictParams) { (response, isSuccess) in
                        if isSuccess {
                            let arrResponse = response as! Array<RecentWatch>
    //                     self.arrWatchRecent.addObjects(from: arrResponse)
                            
                            
                            if self.arrWatchRecent.count >= 10
                            {
                                if  arrResponse.count > 0{
                                    for i in 0 ..< arrResponse.count
                                    {
                                        let objRecentWatchResponse : RecentWatch = arrResponse[i] as RecentWatch
                                        let objRecentWatchStored : RecentWatch = self.arrWatchRecent[i] as! RecentWatch
                                        if objRecentWatchResponse.id !=  objRecentWatchStored.id {
                                            self.arrWatchRecent.add(objRecentWatchResponse)
                                        }
                                    }
                                }
                                
                            }
                            else
                            {
                                self.arrWatchRecent.addObjects(from: arrResponse)
                            }
                            
                            print("I finished First")
                            self.tableViewModels.reloadData()
                        }else{
                            print("failure\(response)")
                        }
                    }
                }
            
        }
    
    // ------------------------------------------------------------------------------------------------------------------

    func getModels()
    {
        if dictOption.count > 0
        {
            let  strCheck = dictOption["nFlag"] as! String
            let objWatch = dictOption["object"] as! WatchModel

            self.setTitleLabel(title: objWatch.ModelName + " Watches")
            let dictParams = [KConstant.kMethod : "brand_submodel.php","id":strBrandId,"slug":objWatch.ModelSlug]//"start":String(tempPageCount),"end":String(self.nPageCount)

          //  print(dictParams)
            
//            if strCheck == "0"
//            {
                ServerRequest.sendServerRequestWithPostMethod(dictParam: dictParams) { (response, isSuccess) in
                    if isSuccess
                    {
                        let arrResponse = response as! Array<WatchModel>
                        self.arrWatchModels.addObjects(from: arrResponse)
                        print("I finished secondly")
                        self.tableViewModels.reloadData()
                    }else{
                        print("failure\(response)")
                    }
                    self.progressShow(false) // ProgressHUD.dismiss()
                }
         //   }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getRolexNon_sport()
    {
        if dictOption.count > 0
        {
            let  strCheck = dictOption["nFlag"] as! String
            let objBrand = dictOption["object"] as! Brand
            
            self.setTitleLabel(title: objBrand.BrandName + " Watches")
            self.labelSubTitle.text = "All " + objBrand.BrandName + " Models :"
            
            var tempPageCount = self.nPageCount-9 as Int
            
            if self.nPageCount == 10 {
                tempPageCount = 0
            }
            var strApiCall = " "
            if nameofTheWatch == "Used Rolex" {
                strApiCall = "brand_rolexused.php"
            }
            else
            {
                strApiCall = "brand_rolexnew.php"
            }

            let dictParams = [KConstant.kMethod : strApiCall,"id":objBrand.BrandID,"type":"non-sport","start":String(tempPageCount),"end":String(self.nPageCount)]
            
           // print(dictParams)
            
            if strCheck == "0"
            {
                ServerRequest.sendServerRequestWithPostMethod(dictParam: dictParams) { (response, isSuccess) in
                    
                    if isSuccess
                    {
                        let arrResponse = response as! Array<WatchModel>
                        //                        self.arrWatchModels.addObjects(from: arrResponse)
                        
                        if self.arrRolexNon_Sport.count >= 10
                        {
                            if arrResponse.count > 0
                            {
                                for i in 0 ..< arrResponse.count
                                {
                                    let obWatchModelResponse : WatchModel = arrResponse[i] as WatchModel
                                    let objWatchModelStored : WatchModel = self.arrRolexNon_Sport[i] as! WatchModel
                                    if obWatchModelResponse.ModelID !=  objWatchModelStored.ModelID {
                                        self.arrRolexNon_Sport.add(obWatchModelResponse)
                                    }
                                }
                            }
                        }
                        else
                        {
                            self.arrRolexNon_Sport.addObjects(from: arrResponse)
                        }
                        
                        
                        //                        if arrResponse.count > 0
                        //                        {
                        //                            for i in 0 ..< arrResponse.count
                        //                            {
                        //                                let objWatchModel = arrResponse[i] as WatchModel
                        //                                if !self.arrWatchModels.contains(objWatchModel){
                        //                                    self.arrWatchModels.add(objWatchModel)
                        //                                }
                        //                            }
                        //                        }
                        
                        self.isPullToRefreshCalled = true
                        self.tableViewModels.isHidden = false
                        
                        print("I finished secondly")
                        
                        self.tableViewModels.reloadData()
                    }else{
                        print("failure\(response)")
                    }
                    
                    
                    self.progressShow(false) // ProgressHUD.dismiss()
                    
                }
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    func getRolexSport()
    {
        if dictOption.count > 0
        {
            let  strCheck = dictOption["nFlag"] as! String
            let objBrand = dictOption["object"] as! Brand
            
            self.setTitleLabel(title: objBrand.BrandName + " Watches")
            self.labelSubTitle.text = "All " + objBrand.BrandName + " Models :"
            
            var tempPageCount = self.nPageCount-9 as Int
            
            if self.nPageCount == 10 {
                tempPageCount = 0
            }
            var strApiCall = ""
            if nameofTheWatch == "Used Rolex" {
                strApiCall = "brand_rolexused.php"
            }
            else
            {
                strApiCall = "brand_rolexnew.php"
            }
            let dictParams = [KConstant.kMethod : strApiCall,"id":objBrand.BrandID,"type":"sport","start":String(tempPageCount),"end":String(self.nPageCount)]
            
            if strCheck == "0"
            {
                ServerRequest.sendServerRequestWithPostMethod(dictParam: dictParams) { (response, isSuccess) in
                    
                    if isSuccess
                    {
                        let arrResponse = response as! Array<WatchModel>
                        //                        self.arrWatchModels.addObjects(from: arrResponse)
                        
                        if self.arrWatchModels.count >= 10
                        {
                            if arrResponse.count > 0
                            {
                                for i in 0 ..< arrResponse.count
                                {
                                    let obWatchModelResponse : WatchModel = arrResponse[i] as WatchModel
                                    let objWatchModelStored : WatchModel = self.arrWatchModels[i] as! WatchModel
                                    if obWatchModelResponse.ModelID !=  objWatchModelStored.ModelID {
                                        self.arrWatchModels.add(obWatchModelResponse)
                                    }
                                }
                            }
                        }
                        else
                        {
                            self.arrWatchModels.addObjects(from: arrResponse)
                        }
                        
                        
                        //                        if arrResponse.count > 0
                        //                        {
                        //                            for i in 0 ..< arrResponse.count
                        //                            {
                        //                                let objWatchModel = arrResponse[i] as WatchModel
                        //                                if !self.arrWatchModels.contains(objWatchModel){
                        //                                    self.arrWatchModels.add(objWatchModel)
                        //                                }
                        //                            }
                        //                        }
                        
                        self.isPullToRefreshCalled = true
                        self.tableViewModels.isHidden = false
                        
                        print("I finished secondly")
                        
                        self.tableViewModels.reloadData()
                    }else{
                        print("failure\(response)")
                    }
                    
                    self.progressShow(false) // ProgressHUD.dismiss()
                    
                }
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    
    // ------------------------------------------------------------------------------------------------------------------

    func method1(){
        self.getRecentModels()
        self.getModels()
//        self.method2 {
//            if numberofSection == 3
//            {
//                self.getRolexSport()
//                self.getRolexNon_sport()
//            }
//            else {
//                  self.getModels()
//            }
//
//        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func method2(completion: () -> Void) {
        completion()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    @IBAction func buttonMenuClicked(_ sender: Any) {
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------


    func buttonSelectClicked(sender:AnyObject) -> Void {
        let button = sender
        _ = button.tag
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    // ------------------------------------------------------------------------------------------------------------------

    override var prefersStatusBarHidden : Bool {
        return false
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - Custom Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func handleRefresh(_ refreshControl: UIRefreshControl)
    {
//        self.tableViewModels.isHidden = true
//
//        self.nPageCountRecent = 10
//        self.arrWatchRecent.removeAllObjects()
//       // self.getRecentModels()
//
//        self.nPageCount = 10
//        self.arrWatchModels.removeAllObjects()
////        if numberofSection == 3 {
////            self.getRolexSport()
////            self.getRolexNon_sport()
////        }
////        else
////        {
//             self.getModels()
//  //      }
//
//
//        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: - UITableView Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let  viewHeader = HeaderTitleView.instanceFromNib() as! HeaderTitleView
               let objBrand = dictOption["object"] as! WatchModel

                   if section == 1 {
                       viewHeader.labelTitle.text = "Latest " + objBrand.ModelSlug + " Watches Added to Our Site:"
                   }else if section == 0 {
                       viewHeader.labelTitle.text = "All " + objBrand.ModelSlug + " Models :"
                   }

                viewHeader.labelTitle.font = viewHeader.labelTitle.font.withSize(14)
               viewHeader.layoutConstraintLabelTitleTopSpace.constant = 11
               viewHeader.buttonShowAll.isHidden = true
               viewHeader.imageViewArrow.isHidden = true
               return viewHeader
    }
    
     // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 46
    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        else{
           return  1
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func numberOfSections(in tableView: UITableView) -> Int{
        return 2
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
       
                    if(indexPath.section == 0)
                    {
                        if self.arrWatchRecent.count > 0{
                            return 183
                        }else{
                            return 0
                        }
                    }
                    else  if(indexPath.section == 1)
                    {
                        return 183
                        
                        var temp = 0
                        if(self.arrWatchModels.count % 3 == 0)
                        {
                            temp = self.arrWatchModels.count/3;
                        }
                        else
                        {
                            temp = self.arrWatchModels.count/3;
                            temp = temp + 1;
                        }
                        return  CGFloat(195  * temp)
                    }
        //            else
        //            {
                        return 0
        //            }
        //        }
                
           
    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.00001
    }
    
    // -----------------------------------------------------------------------------------------    -------------------------

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : ModelTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ModelTableViewCell", for: indexPath ) as! ModelTableViewCell
        cell.delegate = self
        
        if indexPath.section == 0
            {
//                cell.collectionViewHome.isHidden = true
//                cell.collectionViewWatch.isHidden = false
//                if self.arrWatchRecent.count > 0{
//                    cell.setCollectionDataForLatestArrivalWatches(self.arrWatchRecent as! Array<RecentWatch>, withIndex: 0)
//                }
                cell.collectionViewHome.isHidden = false
                cell.collectionViewWatch.isHidden = true
                
                if self.arrWatchModels.count > 0{
                    cell.setCollectionDataForSubModels(self.arrWatchModels, withIndex: 2)
                }
                
            }
        else
        {
           
                           cell.collectionViewHome.isHidden = true
                           cell.collectionViewWatch.isHidden = false
                           if self.arrWatchRecent.count > 0{
                               cell.setCollectionDataForLatestArrivalWatches(self.arrWatchRecent as! Array<RecentWatch>, withIndex: 0,isRequiredLoaderLatest: 0)
                           }
                           return cell
        }
        return cell
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    @objc func handle(withNotification notification : NSNotification)
    {
        let dictObject  = notification.object as! Dictionary<String, Any>
        let  strCheck = dictObject["nFlag"] as! String
        
//        if strCheck == "0"
//        {
//            let objModelsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
//            let objRecentWatch = dictObject["object"] as! RecentWatch
//            print("All Data =",dictObject["object"] ?? "0")
//            objModelsViewController.strItemID = objRecentWatch.id
//           // objProductDetailsViewController.strItemID = objWatchList.ItemID
//             //   objModelsViewController.strBrandID = objRecentWatch.id
////            objModelsViewController.strModelSlug = strModelSlug
////            objModelsViewController.strSelectedVariation = strSelectedVariation
//             let objBrand = dictOption["object"] as! Brand
//             objModelsViewController.strBrandID = objBrand.BrandID
//              objModelsViewController.strBrandName = objBrand.BrandName
//
//
//            print("All brand Id ",objBrand)
//
//            objModelsViewController.isFromMultipleScreen = true
//            objModelsViewController.isLatestFromModel = true
//            self.navigationController?.pushViewController(objModelsViewController, animated: true)
//            return
//        }
//        if strCheck == "1"
//        {
        
        
//        let objMultiProductsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MultiProductsViewController") as! MultiProductsViewController
//        let objWatchModel = dictObject["object"] as! WatchModel
//        objMultiProductsViewController.strModelSlug = objWatchModel.ModelSlug
//        let objBrand = dictOption["object"] as! Brand
//        objMultiProductsViewController.strBrandID = objBrand.BrandID
//        objMultiProductsViewController.strBrandName = objBrand.BrandName
//        objMultiProductsViewController.isFromSubModel = false
//        //  objModelsViewController.isFromMultipleScreen = true
//        self.navigationController?.pushViewController(objMultiProductsViewController, animated: true)
//        return

        
         let objWatch1 = dictOption["object"] as! WatchModel
        
        let objMultiProductsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MultiProductsViewController") as! MultiProductsViewController
        let objWatchModel = dictObject["object"] as! WatchModel
        objMultiProductsViewController.strModelName = self.getTitle().replacingOccurrences(of: " Watches", with: "")
        if(strBrandId == "46")
        {
            objMultiProductsViewController.strSubModelSlug = objWatch1.ModelSlug;
        }
        else
        {
            objMultiProductsViewController.strSubModelSlug = "";
        }
        //  objWatchModel.ModelSlug
        //objMultiProductsViewController.strModelID = objWatchModel.ModelID
        let objBrand = dictOption["object"] as! [String : AnyObject]
        objMultiProductsViewController.strModelSlug = objBrand["ModelSlug"] as! String
        
        objMultiProductsViewController.strBrandID = strBrandId
        
          //  objMultiProductsViewController.strBrandName = objBrand.BrandName
         //   objMultiProductsViewController.isFromMultipleScreen = true
           // objMultiProductsViewController.isFromSubModel = true
            self.navigationController?.pushViewController(objMultiProductsViewController, animated: true)
            return
//        }
//        else   if strCheck == "2" // Load more section0
//        {
//            self.nPageCountRecent = self.nPageCountRecent + 10
//            //self.getRecentModels()
//        }else   if strCheck == "3"   // Load more section1
//        {
//            self.nPageCount = self.nPageCount + 10
//
////            if numberofSection == 3 {
////                self.getRolexSport()
////                self.getRolexNon_sport()
////            }
////            else
////            {
//                self.getModels()
//
////            }
//        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
//
//    func scrollViewDidScroll(_ scrollView: UIScrollView)
//    {
//        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
//        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
//        let scrollOffset: Float = Float(scrollView.contentOffset.y)
//
//        if scrollOffset == 0 {
//            // then we are at the top
//            if self.arrWatchModels.count <= 6 {
//                self.nPageCount = self.nPageCount + 11
//                self.getModels()
//            }
////            self.nPageCount = self.nPageCount + 11
////            self.getModels()
//        }
//        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
//        {
//            self.nPageCount = self.nPageCount + 11
//            self.getModels()
//        }
//    }
    // ------------------------------------------------------------------------------------------------------------------

    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func reloadLatestArrivalsSection0(){
//     self.progressShow(true) //ProgressHUD.show()
        self.nPageCountRecent = self.nPageCountRecent + 10
      //  self.getRecentModels()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func reloadModelsSection1(){}

    
    func cellSelectedUsingDict(_ dict: Dictionary<String, Any>)
    {
        let dictObject  = dict as! Dictionary<String, Any>
        print(dictObject)
        let  strCheck = dictObject["nFlag"] as! String
         let objWatch1 = dictOption["object"] as! WatchModel
         let objWatchModel = dictObject["object"] as! WatchModel
        if(objWatchModel.IsSubVariation == "1")
        {
            let dict = ["object":dictObject["object"],"nFlag":"0"] as [String : Any]
            let objVariationViewController = self.storyboard?.instantiateViewController(withIdentifier: "VariationViewController") as! VariationViewController
            objVariationViewController.dictOption = dict as [String : AnyObject]
            objVariationViewController.isFromHome =  true
            objVariationViewController.strBrandId = strBrandId
            objVariationViewController.strModelSlug = objWatch1.ModelSlug
            objVariationViewController.strSubModelSlug = objWatchModel.ModelSlug
            self.navigationController?.pushViewController(objVariationViewController, animated: true)

        }
        else
        {
            let objMultiProductsViewController = self.storyboard?.instantiateViewController(withIdentifier: "MultiProductsViewController") as! MultiProductsViewController
            let objWatchModel = dictObject["object"] as! WatchModel
            objMultiProductsViewController.strModelName = self.getTitle().replacingOccurrences(of: " Watches", with: "")
            objMultiProductsViewController.strModelSlug = objWatchModel.ModelSlug
            objMultiProductsViewController.strBrandID = strBrandId
            if(strBrandId == "46")
            {
                objMultiProductsViewController.strSubModelSlug = objWatch1.ModelSlug;
            }
            else
            {
                objMultiProductsViewController.strSubModelSlug = "";
            }
            self.navigationController?.pushViewController(objMultiProductsViewController, animated: true)
        }
        return
    }
    // ------------------------------------------------------------------------------------------------------------------

}
