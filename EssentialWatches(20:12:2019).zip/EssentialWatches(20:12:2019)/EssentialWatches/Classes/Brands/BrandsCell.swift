//
//  BrandsCell.swift
//  EssentialWatches
//
//  Created by Vikram on 13/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class BrandsCell: UICollectionViewCell {
    @IBOutlet weak var imageViewProduct: UIImageView!
    @IBOutlet weak var viewCell: UIView!
    @IBOutlet weak var labelProduct: UILabel!
    @IBOutlet weak var labelWirePrice: UILabel!
    @IBOutlet weak var labelWatchInfo: UILabel!
    @IBOutlet weak var labelNumberOfItems: UILabel!
    @IBOutlet weak var layoutImageViewHeight: NSLayoutConstraint!
   
    override func awakeFromNib()
    {
        super.awakeFromNib()
        viewCell.layer.borderColor = UIColor.lightGray.cgColor
        viewCell.layer.borderWidth = 1.0
    }
}
