//
//  NotificationViewController.swift
//  EssentialWatches
//
//  Created by MSP on 26/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import Alamofire
import Firebase

class NotificationViewController: BaseViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet var tblVNoti: UITableView!
    
     @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!
    
    var arrNotiList : NSMutableArray = []
    var isNotiListGet : Bool = false
    
    var startValue : Int = 0
    var endValue : Int = 15
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setTitleLabel(title: "Notification")
        self.setIsRequiedMenuYes()
        tblVNoti.rowHeight = UITableView.automaticDimension
        tblVNoti.estimatedRowHeight = 70
        tblVNoti.tableFooterView = UIView()
      
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }else{
            self.callNotificationListAPI()
        }
        
        var refreshControl: UIRefreshControl = {
            let refreshControl = UIRefreshControl()
            refreshControl.addTarget(self, action:
                #selector(BrandsViewController.handleRefresh(_:)),
                                     for: UIControl.Event.valueChanged)
            refreshControl.tintColor = UIColor.clear
            return refreshControl
        }()
        self.tblVNoti.addSubview(refreshControl)
        if DeviceUtility.isIphoneXType{
            layoutConstraintTopViewTopSpace.constant =  25
            }else{
            layoutConstraintTopViewTopSpace.constant =  5
            }
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        KConstant.APP.isReceivedNotification = false
        
        Analytics.logEvent("Notification_Screen", parameters: [
            "name": "Notification Screen" as NSObject,
            ])

        
        
        
//        guard let tracker = GAI.sharedInstance().defaultTracker else { return }
//        tracker.set(kGAIScreenName, value: "Notification Screen")
//
//        guard let builder = GAIDictionaryBuilder.createScreenView() else { return }
//        tracker.send(builder.build() as [NSObject : AnyObject])
    }
    

    func callNotificationListAPI()
    {
        let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
        if !(reachabilityManager?.isReachable)!
        {
            self.displayAlertForNoIntenret()
            return
        }
        
//         self.progressShow(true) //ProgressHUD.show()
        
        self.progressShow(true)
        var uniqueIdentifier = ""
        if (UserDefaults.standard.value(forKey: "deviceuid") != nil){
            uniqueIdentifier = UserDefaults.standard.value(forKey: "deviceuid") as! String
            UserDefaults.standard.synchronize()
        }
        
        ServerRequest.sendServerRequestforPostMethod(dictParam:["deviceId":uniqueIdentifier,"start":"\(startValue)","end":"\(endValue)",KConstant.kMethod : "notification_listing_api.php"]
        ){ (response, isSuccess) in
            
            if isSuccess
            {
                let dict : NSDictionary =  response as! NSDictionary
                
                if dict["result"] as! Int == 1
                {
//                    self.progressShow(false) // ProgressHUD.dismiss()

                    self.progressShow(false)
                    if (dict["list"] as! NSArray).count > 0{
                        self.isNotiListGet = true
                        self.arrNotiList.addObjects(from:(dict["list"] as! NSArray) as! [Any])
                        //print(self.arrNotiList)
                        self.tblVNoti.reloadData()
                    }else{
                        self.isNotiListGet = false
                    }
                }else{
//                    self.progressShow(false) // ProgressHUD.dismiss()

                    self.progressShow(false)
                    if self.arrNotiList.count == 0{
                        self.displayAlertWithOk(message: dict["message"] as! String)
                    }
                    self.isNotiListGet = false
                }
            }else{
            }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func handleRefresh(_ refreshControl: UIRefreshControl) {
         self.arrNotiList.removeAllObjects()
        startValue = 0
        endValue = 15
        self.callNotificationListAPI()
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    //Mark :- UITableView Delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if  self.arrNotiList.count > 0 {
            return self.arrNotiList.count
        }
        return 0
    }
    
    //------------------------------------------------------------------------------------------------------------------

    
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    //------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : notiTableVCell = tableView.dequeueReusableCell(withIdentifier: "notiTableVCell") as! notiTableVCell
        
        if  self.arrNotiList.count > 0 {
        let dict : NSDictionary? = self.arrNotiList[indexPath.row] as? NSDictionary
        cell.lblMsg.text = dict?.value(forKey: "message") as? String
        cell.lblDate.text = dict?.value(forKey: "createdate") as? String
        
        if indexPath.row == arrNotiList.count - 1 && self.isNotiListGet {
            startValue += 15
            endValue += 15
            self.callNotificationListAPI()
        }
        }
        return cell
    }
    
    //------------------------------------------------------------------------------------------------------------------

    // MARK: - Custom Action Methods
    
    //------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonMenuClicked(_ sender: Any) {
        KConstant.APP.isReceivedNotificationForSideMenu = true
        KConstant.APP.objSidePanelController.showLeftPanel(animated: true)
    }

    //------------------------------------------------------------------------------------------------------------------

}

class notiTableVCell: UITableViewCell {
    
    @IBOutlet var lblDate: UILabel!
    @IBOutlet var lblMsg: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
