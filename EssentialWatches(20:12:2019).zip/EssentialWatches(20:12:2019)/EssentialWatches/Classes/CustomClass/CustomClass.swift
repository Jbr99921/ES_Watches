//
//  CustomClass.swift
//  EssentialWatches
//
//  Created by Bhavesh on 29/11/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import Foundation
import UIKit

class ThemeBorderButton: UIButton {
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        self.layer.borderWidth = 1
        self.setTitleColor(KConstant.kColorThemeYellow, for: .normal)
        self.setTitleColor(.white, for: .selected)
        self.isSelected ? (self.backgroundColor = KConstant.kColorThemeYellow) : (self.backgroundColor = .white)
        self.titleLabel?.font = UIFont(name: KConstant.kFontOpenSenseRegular, size: 15)
        
    }
    
}


class RoundThemeLabel: UILabel {
    
    override func layoutSubviews() {
        
        self.layer.cornerRadius = self.frame.height/2
        self.clipsToBounds = true
        self.backgroundColor = KConstant.kColorThemeYellow
        self.textColor = UIColor.white
        
    }
}
