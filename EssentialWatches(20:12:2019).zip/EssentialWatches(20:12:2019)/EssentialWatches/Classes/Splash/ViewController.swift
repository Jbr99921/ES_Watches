//
//  ViewController.swift
//  SplashScreen_Animation
//
//  Created by MSP on 06/12/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import Firebase


class ViewController: UIViewController {
    @IBOutlet var imageViewDisplay:UIImageView?
    
    @IBOutlet weak var layoutConstraintTopViewTopSpace: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if DeviceUtility.isIphoneXType{
            layoutConstraintTopViewTopSpace.constant =  -40
            

            
            }else{
            layoutConstraintTopViewTopSpace.constant =  0
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0) {
            self.loadAnimation()
        }
    }
    func loadAnimation()
    {
        UIView.animate(withDuration: 1.8,animations: {
                        self.imageViewDisplay?.transform = CGAffineTransform(scaleX: 0.2, y: 0.2)
        },completion: { _ in
            self.perform(#selector(self.datacall), with: nil, afterDelay:0.5)
        })
    }
    @objc func datacall() {
        UIView.animate(withDuration: 1.8,animations: {
            self.imageViewDisplay?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        },completion: { _ in
            self.perform(#selector(self.dataNewcall), with: nil, afterDelay:2)
        })
    }
    @objc func dataNewcall() {
        
        UIView.animate(withDuration: 1.8,animations: {
                 self.imageViewDisplay?.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
             },completion: { _ in
                // self.perform(#selector(self.dataNewcall), with: nil, afterDelay:2)
                self.navigation()
        })
    }
    func navigation(){
        KConstant.APP.setTwoWaySiderAsRootController()
    }

}

