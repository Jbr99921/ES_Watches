//
//  SideMenuViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class SideMenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    var arrMenu = ["HOME","BRANDS", "FEATURED WATCH VIDEOS","INFO","FAVOURITE","SEARCH","SELL YOUR WATCH","TRADE-IN YOUR WATCH","GET YOUR WATCH AUTHENTICATED","CERTIFIED APPRIASAL","NOTIFICATION","MY INFO"]
    
    var arrMenuIcons = ["home_side_icon","brands_side_icon","youtube_side_icon","info_side_icon","wishlist","search_side_icon","sellwatch_side_icon","tradewatch_side_icon","authentication_side_icon","certified_side_icon","notification_icon","my-info"]
    
    @IBOutlet var tblSlideMenu: UITableView!
    
    var objHomeViewController = HomeViewController()
    var objInfoViewController = InfoViewController()
    var objRequestViewController = RequestViewController()
    var objAskAQuestionViewController = AskAQuestionViewController()
    var objBrandsViewController = BrandsViewController()
    var objVideosViewController = VideosViewController()
    var objSearchViewController = SearchViewController()
    var objNotificationViewController = NotificationViewController()
    var objFormsViewController = FormsViewController()

    var objStoryborad =  UIStoryboard()
    var objNavigationController =  UINavigationController()
    
    var nSelectedCell = 0
    

   override func viewDidLoad() {
        super.viewDidLoad()
        objStoryborad = UIStoryboard(name: "Main", bundle: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(SideMenuViewController.handle(withNotification:)), name: NSNotification.Name(rawValue: "RELOADNOTIFICATION"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if KConstant.APP.isReceivedNotificationForSideMenu {
            nSelectedCell = 5
        }
        tblSlideMenu.reloadData()
    }
    
    
    @objc func handle(withNotification notification : NSNotification)
    {
        
        if KConstant.APP.isReceivedNotificationForSideMenu {
            nSelectedCell = 5
        }
//         nSelectedCell = 5
            tblSlideMenu.reloadData()
//        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  arrMenu.count
    }
    
    func numberOfSections(in tableView: UITableView) -> Int{
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 60
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SideMenuCell = tblSlideMenu.dequeueReusableCell(withIdentifier: "SideMenuCell", for: indexPath ) as! SideMenuCell
        cell.labelName.text =  arrMenu[indexPath.row]
        cell.imageViewIcon.image = UIImage(named: arrMenuIcons[indexPath.row])
        
        if indexPath.row == arrMenu.count-1 {
            cell.viewBottom.isHidden = false
        }else{
            cell.viewBottom.isHidden = true
        }
        
        if nSelectedCell == indexPath.row
        {
            cell.backgroundColor = UIColor.init(red: 0.847058, green: 0.847058, blue: 0.847058, alpha: 1)
        }else{
            cell.backgroundColor = UIColor.init(red: 0.97647, green: 0.97647, blue: 0.97647, alpha: 1)
        }
        
        cell.labelName.numberOfLines = 0
        cell.labelName.adjustsFontSizeToFitWidth = true

        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        KConstant.APP.isReceivedNotificationForSideMenu = false
        nSelectedCell = indexPath.row

        if indexPath.row == 0 {
//            AppDelegate.sharedInstance().setTwoWaySiderAsRootController()
//            objHomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            let tabBar = self.storyboard?.instantiateViewController(withIdentifier: "TabBarController") as! TabBarController
            
//            objHomeViewController.tabBarController!.tabBar.isHidden = false
//            (objHomeViewController.tabBarController as? TabBarController)!.tabBar.isHidden = false
//            (objHomeViewController.tabBarController as? TabBarController)!.selectedIndex = 1
//            objHomeViewController.tabBarController?.tabBar.isHidden = false
            tabBar.selectedIndex = 1
            objNavigationController =  UINavigationController.init(rootViewController: tabBar)
        }else  if indexPath.row == 1 {
            objBrandsViewController = self.storyboard?.instantiateViewController(withIdentifier: "BrandsViewController") as! BrandsViewController
            objBrandsViewController.isFromHome = false
            objNavigationController =  UINavigationController.init(rootViewController: objBrandsViewController)
        }else  if indexPath.row == 2 {
            objVideosViewController = self.storyboard?.instantiateViewController(withIdentifier: "VideosViewController") as! VideosViewController
            objNavigationController =  UINavigationController.init(rootViewController: objVideosViewController)
        }else  if indexPath.row == 3 {
            objInfoViewController = self.storyboard?.instantiateViewController(withIdentifier: "InfoViewController") as! InfoViewController
            objNavigationController =  UINavigationController.init(rootViewController: objInfoViewController)
        }else  if indexPath.row == 4 {
            let objWishlistVC : WishlistViewController = self.storyboard?.instantiateViewController(withIdentifier: "WishlistViewController") as! WishlistViewController
            objNavigationController =  UINavigationController.init(rootViewController: objWishlistVC)
        }else  if indexPath.row == 5 {
            objSearchViewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
            objSearchViewController.isFromSideMenu = true
            objNavigationController =  UINavigationController.init(rootViewController: objSearchViewController)
        }else  if indexPath.row == 9 || indexPath.row == 6 || indexPath.row == 7 || indexPath.row == 8{
            objFormsViewController = self.storyboard?.instantiateViewController(withIdentifier: "FormsViewController") as! FormsViewController
            objFormsViewController.nIndex = indexPath.row
            objFormsViewController.isFromHome = false
            objFormsViewController.isStatusSelectionRequired = false
            objNavigationController =  UINavigationController.init(rootViewController: objFormsViewController)
//        }else  if indexPath.row == 10 {
//            let objAppoinmentViewController: AppoinmentViewController = self.storyboard?.instantiateViewController(withIdentifier: "AppoinmentViewController") as! AppoinmentViewController
//            objNavigationController =  UINavigationController.init(rootViewController: objAppoinmentViewController)
        }
        else  if indexPath.row == 10 {
            objNotificationViewController = self.storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
            objNavigationController =  UINavigationController.init(rootViewController: objNotificationViewController)
        }
        else  if indexPath.row == 11 {
            let objMyInfoVC : MyInfoViewController  = self.storyboard?.instantiateViewController(withIdentifier: "MyInfoViewController") as! MyInfoViewController
            objMyInfoVC.isWishlist = false
            objNavigationController =  UINavigationController.init(rootViewController: objMyInfoVC)
        }
        objNavigationController.isNavigationBarHidden = true
        KConstant.APP.objSidePanelController.centerPanel = objNavigationController
        KConstant.APP.objSidePanelController.showCenterPanel(animated: true)
    }
    
}
