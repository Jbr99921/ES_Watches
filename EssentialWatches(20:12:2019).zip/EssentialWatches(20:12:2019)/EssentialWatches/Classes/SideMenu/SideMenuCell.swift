//
//  SideMenuCell.swift
//  EssentialWatches
//
//  Created by Vikram on 06/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit

class SideMenuCell: UITableViewCell {
    @IBOutlet weak var imageViewIcon: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var button_menu: UIButton!

    @IBOutlet weak var viewTop: UIView!
    @IBOutlet weak var viewBottom: UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
