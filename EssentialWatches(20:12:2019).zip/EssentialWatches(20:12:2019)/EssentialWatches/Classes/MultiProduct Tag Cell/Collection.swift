//
//  Collection.swift
//  EssentialWatches
//
//  Created by Mac Mini on 06/12/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import UIKit

protocol CollectionDelegateSelected : class {
    func didSelectCollection(_ tag: Int,Index:Int)
}
class Collection: UITableViewCell , UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
 
    
    @IBOutlet weak var CollectionView: UICollectionView!
    var arrayData: NSArray!
    var strBrandID: NSString!
    var strModelName: NSString!
    var strSubModelSlag: NSString!
    var strVariation: NSString!
    var strSubVariation: NSString!
    var strDateRange: NSString!
    var collectioDelegate:CollectionDelegateSelected?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.CollectionView.register(UINib(nibName: "LabelCollectionCell", bundle: nil), forCellWithReuseIdentifier: "LabelCollectionCell")
        self.CollectionView.delegate = self;
        self.CollectionView.dataSource = self;
        self.CollectionView.backgroundColor = UIColor.clear
        self.CollectionView.allowsMultipleSelection = false

    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return  arrayData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell : LabelCollectionCell = collectionView.dequeueReusableCell(withReuseIdentifier: "LabelCollectionCell", for: indexPath) as! LabelCollectionCell
        cell.lblTitle.font = UIFont(name: KConstant.kFontOpenSenseRegular, size: 13)
    
        cell.lblTitle.tag = indexPath.row
      
        if(collectionView.tag == 0)
        {
            let ObjBrand : Brand = arrayData?[indexPath.row] as! Brand
            cell.lblTitle.text = ObjBrand.BrandName
            if ObjBrand.BrandID == self.strBrandID as String
            {
                cell.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                cell.lblTitle.textColor = KConstant.kColorThemeYellow
            }
            else
            {
                cell.layer.borderColor = UIColor.lightGray.cgColor
                cell.lblTitle.textColor = UIColor.black
            }
        }
        else if(collectionView.tag == 1)
        {
            let ObjBrand : WatchModelRow = arrayData?[indexPath.row] as! WatchModelRow
            cell.lblTitle.text = ObjBrand.ModelName
            if ObjBrand.ModelSlug == self.strModelName as String
            {
               cell.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                    cell.lblTitle.textColor = KConstant.kColorThemeYellow
            }
            else
            {
                 cell.layer.borderColor = UIColor.lightGray.cgColor
                  cell.lblTitle.textColor = UIColor.black
            }
        }
        else if(collectionView.tag == 2)
        {
                let ObjBrand : SubModel = arrayData?[indexPath.row] as! SubModel
                cell.lblTitle.text = ObjBrand.ModelSlug
                if ObjBrand.ModelSlug == self.strSubModelSlag as String
                {
                     cell.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                     cell.lblTitle.textColor = KConstant.kColorThemeYellow
                }
                else
                {
                      cell.layer.borderColor = UIColor.lightGray.cgColor
                      cell.lblTitle.textColor = UIColor.black
                }
        }
        else if(collectionView.tag == 3)
        {
                let ObjBrand : Model = arrayData?[indexPath.row] as! Model
                cell.lblTitle.text = ObjBrand.SubModelName
            
                 if ObjBrand.SubModel_Slug == self.strVariation as String
                 {
                    cell.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                    cell.lblTitle.textColor = KConstant.kColorThemeYellow
                 }
                else
                 {
                    cell.layer.borderColor = UIColor.lightGray.cgColor
                    cell.lblTitle.textColor = UIColor.black
                 }
            
               
        }
        else if(collectionView.tag == 4)
        {
                let ObjBrand : Model = arrayData?[indexPath.row] as! Model
                cell.lblTitle.text = ObjBrand.SubModelName
                cell.layer.borderColor = UIColor.lightGray.cgColor
                cell.lblTitle.textColor = UIColor.black
            
                if ObjBrand.SubModel_Slug == self.strSubVariation as String
                 {
                    cell.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                    cell.lblTitle.textColor = KConstant.kColorThemeYellow
                 }
                else
                 {
                    cell.layer.borderColor = UIColor.lightGray.cgColor
                    cell.lblTitle.textColor = UIColor.black
                 }
        }
        else if(collectionView.tag == 5)
        {
                let ObjBrand : DateRangeModel = arrayData?[indexPath.row] as! DateRangeModel
                cell.lblTitle.text = ObjBrand.YearName
                cell.layer.borderColor = UIColor.lightGray.cgColor
                cell.lblTitle.textColor = UIColor.black
            
                if ObjBrand.YearSlug == self.strDateRange as String
                     {
                        cell.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                        cell.lblTitle.textColor = KConstant.kColorThemeYellow
                     }
                    else
                     {
                        cell.layer.borderColor = UIColor.lightGray.cgColor
                        cell.lblTitle.textColor = UIColor.black
                     }
        }
      
        cell.contentView.backgroundColor = UIColor.white
        cell.layer.borderWidth = 0.5
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let label = UILabel(frame: CGRect.zero)
        if(collectionView.tag == 0)
        {
            let ObjBrand : Brand = arrayData?[indexPath.row] as! Brand
             label.text = ObjBrand.BrandName
        }
        else if(collectionView.tag == 1)
        {
            let ObjBrand : WatchModelRow = arrayData?[indexPath.row] as! WatchModelRow
             label.text = ObjBrand.ModelName
        }
        else if(collectionView.tag == 2)
        {
                let ObjBrand : SubModel = arrayData?[indexPath.row] as! SubModel
                 label.text = ObjBrand.ModelSlug
        }
        else if(collectionView.tag == 3)
        {
                let ObjBrand : Model = arrayData?[indexPath.row] as! Model
                 label.text = ObjBrand.SubModelName
        }
        else if(collectionView.tag == 4)
        {
                let ObjBrand : Model = arrayData?[indexPath.row] as! Model
                 label.text = ObjBrand.SubModelName
        }
        else if(collectionView.tag == 5)
        {
                let ObjBrand : DateRangeModel = arrayData?[indexPath.row] as! DateRangeModel
                label.text = ObjBrand.YearName
        }
     
        label.sizeToFit()
        return CGSize(width: label.frame.width+10, height: 32)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        self.collectioDelegate?.didSelectCollection(collectionView.tag, Index: indexPath.row)
    }

    func scrllSelectedValue()
    {
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
