//
//  LabelCollectionCell.swift
//  EssentialWatches
//
//  Created by Mac Mini on 06/12/19.
//  Copyright © 2019 MSP. All rights reserved.
//

import UIKit


class LabelCollectionCell: UICollectionViewCell
{
    @IBOutlet weak var lblTitle: UILabel!
    
     
    var indexes : IndexPath?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.lblTitle.sizeToFit()
     
     }
    
 
    
}
