//
//  MultiProductsViewController.swift
//  EssentialWatches
//
//  Created by Vikram on 07/09/17.
//  Copyright © 2017 MSP. All rights reserved.
//

import UIKit
import ZVProgressHUD
import HTHorizontalSelectionList

class MultiProductsViewController: BaseViewController, UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,UIScrollViewDelegate,HTHorizontalSelectionListDataSource, HTHorizontalSelectionListDelegate
{

    @IBOutlet var labelSubModul: UILabel!
    @IBOutlet var lblSubModel: UILabel!
    
    
    
    var viewHorizontalBrand = HTHorizontalSelectionList()
    var viewHorizontalModel = HTHorizontalSelectionList()
    var viewHorizontalSubModel = HTHorizontalSelectionList()
    var viewHorizontalVariation = HTHorizontalSelectionList()
   
    var selectedIndex = 0
    var dictOption  = [String : AnyObject]()
    var arrWatchList = NSMutableArray()
    
    var arrVariationList = NSMutableArray()
    var arrWatchModels = NSMutableArray ()
    var arrWatchSubModels = NSMutableArray()
    var arrBrands = NSMutableArray()
    var arrModels = NSMutableArray()
    var arrVariation = NSMutableArray()

    var strModelSlug = "" as String
    var strModelSlugTemp = "" as String
    var strModelName = "" as String
    var strModelID = "" as String
    var strBrandID = "" as String
    var strBrandName = "" as String
    var nPageCount = 11
    
    var nInitialIndexBrand = -1
    var nInitialIndexModel = -1
    var nInitialIndexSubModel = -1
    
    var strSelectedBrandID = "" as String
    var strSelectedModel = "" as String
    var strSelectedVariation = "" as String
    
    var isVariationClicked = false
    var isReceivedBrand = false
    var isReceivedModel = false
    var isSubModuleShow = false
    var isBrandTapped = false
    var isFromSubModel = false
    
    
    var strReceivedSubModels = "" as String

    var  arrFetched = NSMutableArray()
    var screenWidth = CGFloat()
    var screenHeight = CGFloat()
    
    
    @IBOutlet weak var viewBrand: HTHorizontalSelectionList!
    @IBOutlet weak var viewModel: HTHorizontalSelectionList!
    @IBOutlet weak var viewSubModel: HTHorizontalSelectionList!
    @IBOutlet weak var viewVariation: HTHorizontalSelectionList!

    @IBOutlet weak var tableViewProducts: UITableView!
    @IBOutlet weak var viewHeaderSelection: UIView!
    @IBOutlet weak var labelNotFound:  UILabel!
    @IBOutlet weak var labelVariation: UILabel!
    @IBOutlet weak var labelModel: UILabel!
    @IBOutlet weak var viewtw: UIView!

    
    @IBOutlet var layoutConstraintlabel_Sub_Hight: NSLayoutConstraint!
    
    @IBOutlet var layoutConstraint_sub_view_Hight: NSLayoutConstraint!
    
    @IBOutlet var layoutConstraint_SubView_Top_Hight: NSLayoutConstraint!
    
    @IBOutlet var layoutConstraint_SubView_Bottom_Hight: NSLayoutConstraint!
    
    @IBOutlet var labelSubModel: UILabel!
    
    
    @IBOutlet weak var layoutConstraintViewSelectionHeight: NSLayoutConstraint!

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - View LifeCycle Methods
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.textFieldSearch.delegate = self
        self.labelNotFound.isHidden = true
        
        self.labelVariation.isHidden =  true

        viewHeaderSelection.layer.borderColor = KConstant.kColorThemeYellow.cgColor
        viewHeaderSelection.layer.borderWidth = 1.0
        
        UserDefaults.standard.setValue(strBrandName, forKey: "Brand")
        UserDefaults.standard.setValue(strModelSlug, forKey: "Model")
        
        ZVProgressHUD.show()
        self.setSelectionValues()

      //viewHeaderSelection.frame  = CGRect()
        tableViewProducts.isHidden = true

//        let refreshControl: UIRefreshControl = {
//            let refreshControl = UIRefreshControl()
//            refreshControl.addTarget(self, action:
//                #selector(MultiProductsViewController.handleRefresh(_:)),
//                                     for: UIControlEvents.valueChanged)
//            refreshControl.tintColor = UIColor.clear
//            return refreshControl
//        }()
        
        self.setTitleLabel(title: strModelSlug)
        
        labelVariation.text = "Variations of the " + strModelSlug

//        self.tableViewProducts.addSubview(refreshControl)
        
        let screenSize: CGRect = UIScreen.main.bounds
         screenWidth = screenSize.width
         screenHeight = screenSize.height
        //self.viewHeaderSelection = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height:246)
    }

    // ------------------------------------------------------------------------------------------------------------------

    override func viewWillAppear(_ animated: Bool) {
         tableViewProducts.reloadData()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.setUpInitialDesignScreen()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func setUpInitialDesignScreen()
    {
//    print("arrSubModel:---\(self.arrWatchSubModels)")
        if self.arrVariationList.count > 0
        {
            viewVariation.isHidden = false
            self.labelVariation.isHidden =  false
            self.viewHorizontalVariation.reloadData()
            
           
            if(self.arrWatchSubModels.count > 0)
            {
                tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(300))
                self.showSubModul()
            }else{
                self.hideSubModul()
                tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(184))
            }
            
        }else if(self.arrWatchSubModels.count == 0)
        {
            self.hideSubModul()
        }
        else if(self.arrWatchSubModels.count > 0)
        {

            self.showSubModul()
            if self.arrVariationList.count == 0
            {
                tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(180))
            }else{
                tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(300))
            }
            self.viewSubModel.isHidden = false
            self.viewHorizontalSubModel.isHidden = false
            self.viewHorizontalSubModel.reloadData()
        }
        else if isSubModuleShow == true && self.arrWatchSubModels.count > 0
        {
            labelSubModel.isHidden = false
            tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(300))
        }
        else{
            labelSubModel.isHidden = true
            tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(180))
        }
        
        self.viewHorizontalSubModel.isHidden = false
        self.viewSubModel.isHidden = false
        
         self.viewHorizontalSubModel.reloadData()
        tableViewProducts.isHidden = false
    
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {

        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    override func viewDidLayoutSubviews()
    {

    }
    
    // ------------------------------------------------------------------------------------------------------------------

    deinit {
        print("deinint")
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func setSelectionValues()
    {
        self.viewHorizontalBrand = HTHorizontalSelectionList(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width-20, height:  self.viewBrand.frame.size.height))
        self.viewHorizontalBrand .tag = 101
        self.viewHorizontalBrand.delegate = self;
        self.viewHorizontalBrand.dataSource = self;
        self.viewBrand.addSubview(self.viewHorizontalBrand)
        self.viewHorizontalBrand.reloadData()
        
         self.viewHorizontalModel = HTHorizontalSelectionList(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width-20, height:  self.viewModel.frame.size.height))
        self.viewHorizontalModel .tag = 102
        self.viewHorizontalModel.delegate = self;
        self.viewHorizontalModel.dataSource = self;
        self.viewHorizontalBrand.reloadData()
        self.viewModel.addSubview(self.viewHorizontalModel)
        
        self.viewHorizontalVariation = HTHorizontalSelectionList(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width-20, height:  self.viewVariation.frame.size.height))
        self.viewHorizontalVariation .tag = 103
        self.viewHorizontalVariation.delegate = self;
        self.viewHorizontalVariation.dataSource = self;
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.viewHorizontalVariation.setSelectedButtonIndex(-1, animated: true)
        }
        self.viewHorizontalVariation.reloadData()
        self.viewVariation.addSubview(self.viewHorizontalVariation)

        self.viewHorizontalSubModel = HTHorizontalSelectionList(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width-20, height:  self.viewSubModel.frame.size.height))
        self.viewHorizontalSubModel .tag = 104
        self.viewHorizontalSubModel.delegate = self;
        self.viewHorizontalSubModel.dataSource = self;
        self.viewHorizontalSubModel.reloadData()
        self.viewSubModel.addSubview(self.viewHorizontalSubModel)
        
        self.getModels()
        
        if isFromSubModel == true {
            // self.showSubModul()
            strModelSlugTemp = self.strModelName
            self.getSubModels()
        }
        else
        {
            self.hideSubModul()
//            self.getVariations()
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func handleRefresh(_ refreshControl: UIRefreshControl)
    {
        nPageCount = 11
        ZVProgressHUD.show()
        self.arrWatchList.removeAllObjects()
        self.getWatchList()
        
        tableViewProducts.reloadData()
        refreshControl.endRefreshing()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func getWatchList()
    {
        if strBrandID.characters.count > 0
        {
            let dictParams = [KConstant.kMethod : "model_watches.php","BrandId":strBrandID,"ModelSlug":strModelSlug,"SubModelSlug":strSelectedVariation,"start":String(self.nPageCount-11),"end":String(self.nPageCount)]

                ServerRequest.sendServerRequestWithPostMethodForWatchList(dictParam: dictParams) { (response, isSuccess) in

                if isSuccess
                {
                    let arrResponse = response as! Array<WatchHeader>

                    if self.isVariationClicked
                    {
                        self.arrWatchList.removeAllObjects()
                        self.isVariationClicked = false
                    }
         
//                 self.arrWatchList.removeAllObjects()
                    
                    if(self.nPageCount == 11)
                    {
                        self.arrWatchList.removeAllObjects()

                    }

                    for i in 0 ..< arrResponse.count
                    {
                        let objWatchHeader = arrResponse[i] as WatchHeader
                        if !self.arrWatchList.contains(objWatchHeader){
                            self.arrWatchList.add(objWatchHeader)
                        }
                        else
                        {
                            print("dfjglfkjg")
                        }
                    }
                    
                    
                    print("count === > ", self.arrWatchList.count)
                    
              }else{
                  print("failure\(response)")
              }

                    
            if self.arrWatchList.count == 0{
                  self.labelNotFound.isHidden = false
              }else{
                  self.labelNotFound.isHidden = true
              }
                    
               if self.isBrandTapped
               {
                   self.labelNotFound.text = "Please select model"
               }

//               else{
//                self.labelNotFound.text = "No item found"
//                    }
                    
             self.tableViewProducts.reloadData()

//             self.tableViewProducts.setNeedsLayout()
 //            self.tableViewProducts.layoutIfNeeded()
                    
                    if !self.arrFetched.contains("3"){
                        self.arrFetched.add("3");
                    }
                    
                    if self.arrFetched.count == 3{
                        ZVProgressHUD.dismiss()
                    }
                    
                    //if self.isReceivedModel == true && self.isReceivedBrand == true {
//                        ZVProgressHUD.dismiss()
   //                 }
            }
        }
        
        self.setUpInitialDesignScreen()

    }

    // ------------------------------------------------------------------------------------------------------------------

    func getModels()
    {
        

        for i in 0 ..< KConstant.APP.arrBrands.count
        {
            let objBrand = KConstant.APP.arrBrands[i] as Brand
            
            if objBrand.BrandID == self.strBrandID
            {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.isReceivedBrand = true
                    self.viewHorizontalBrand.setSelectedButtonIndex(i, animated: true)
                }
                break
            }
        }
        
 
        
        
        if strBrandID.characters.count > 0
        {
             var dictParams = NSMutableDictionary()

            if strBrandID == "23" || strBrandID == "46" /// If I come from submodelview controller
            {
                dictParams = [KConstant.kMethod : "brand_model.php","id":strBrandID]
            }
            else {
                 dictParams = [KConstant.kMethod : "brand.php","id":strBrandID]
            }

                ServerRequest.sendServerRequestWithPostMethodForRowModels(dictParam: dictParams as! Dictionary<String, String>) { (response, isSuccess) in
                    if isSuccess
                    {
                        let arrResponse = response as! Array<WatchModelRow>
                        self.viewHorizontalModel.removeFromSuperview()

                        self.arrWatchSubModels.removeAllObjects()
                        self.labelSubModel.isHidden = true
                        self.isSubModuleShow = false
                        self.viewHorizontalModel = HTHorizontalSelectionList(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width-20, height:  self.viewModel.frame.size.height))
                        self.viewHorizontalModel.delegate = self;
                        self.viewHorizontalModel.dataSource = self;
                        self.viewModel.addSubview(self.viewHorizontalModel)
                        self.arrWatchModels.removeAllObjects()


                            for i in 0 ..< arrResponse.count
                            {
                                let objWatchModelRow = arrResponse[i] as WatchModelRow
                                if self.strBrandID == "23" || self.strBrandID == "46"  /// If I come from submodelview controller
                                {
                                    if objWatchModelRow.ModelName == self.strModelName
                                    {
                                        if self.nInitialIndexModel == -1
                                        {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                                self.isReceivedModel = true
                                                self.viewHorizontalModel.setSelectedButtonIndex(i, animated: true)
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if objWatchModelRow.ModelSlug == self.strModelSlug
                                    {
                                        if self.nInitialIndexModel == -1
                                        {
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                                self.isReceivedModel = true
                                                self.viewHorizontalModel.setSelectedButtonIndex(i, animated: true)
                                            }
                                        }
                                    }
                                }
                                
                                self.arrWatchModels.add(objWatchModelRow)
                                
                                if self.nInitialIndexModel != -1 && self.isBrandTapped == true
                                {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        self.viewHorizontalModel.setSelectedButtonIndex(-1, animated: true)
                                    }
                                }
                                
                            }
                    }else{
                        print("failure\(response)")
                    }
                    
                    
                    if self.isFromSubModel == true /// If I come from submodelview controller
                    {
                        self.getSubModels()
                    }
                    else
                    {
                        self.getVariations()
                    }
                    

                    
                    if !self.arrFetched.contains("1"){
                        self.arrFetched.add("1");
                    }
                    //let objModel = self.arrWatchModels[self.selectedIndex] as! WatchModelRow
                    if self.isFromSubModel == true//objModel.is_submodel == "1"
                    {
                         self.labelNotFound.text = "Please select Submodel"
                          self.labelNotFound.isHidden = false
                    }
                    else
                    {
                        if self.isBrandTapped == true
                        {
                            self.labelNotFound.text = "Please select model"
                            self.labelNotFound.isHidden = false
                            self.arrWatchList.removeAllObjects()
                            self.arrWatchSubModels.removeAllObjects()
                        }else{
                            self.labelNotFound.isHidden = true
                        }
                    }
                    self.viewHorizontalSubModel.reloadData()
                    
                    self.tableViewProducts.reloadData()
                    
                    if self.arrFetched.count == 3{
                        ZVProgressHUD.dismiss()
                    }
                }
        }
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func getVariations()
    {
        
        if strBrandID.characters.count > 0 && strModelSlug.characters.count > 0
        {
            let dictParams = [KConstant.kMethod : "submodel_list.php","BrandId":strBrandID,"ModelSlug":strModelSlug]
            
            ServerRequest.sendServerRequestWithDictForModels(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                    self.tableViewProducts.isHidden = false
                    let arrResponse = response as! Array<Model>
                    
                    self.viewHorizontalVariation.removeFromSuperview()
                    self.arrVariationList.removeAllObjects()
                    self.arrVariationList.addObjects(from: arrResponse)
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        self.viewHorizontalVariation.setSelectedButtonIndex(-1, animated: true)
                    }
                    
                    self.viewHorizontalVariation = HTHorizontalSelectionList(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width-20, height:  self.viewVariation.frame.size.height))
                    self.viewHorizontalVariation.delegate = self;
                    self.viewHorizontalVariation.dataSource = self;
                    self.viewVariation.addSubview(self.viewHorizontalVariation)
                    self.viewHorizontalVariation.reloadData()
                }else{
                    print("failure\(response)")
                }


                
                if self.arrVariationList.count == 0{
                    self.labelVariation.isHidden = true
                }else{
                    self.labelVariation.isHidden = false
                }
                
                if !self.arrFetched.contains("2"){
                    self.arrFetched.add("2");
                }
                
                if self.arrFetched.count == 3{
                    ZVProgressHUD.dismiss()
                }

                self.arrWatchList.removeAllObjects()
                self.getWatchList()

//             self.setSelectionValues()
            }
        }
    }
    

    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - Custom Action Methods
    // ------------------------------------------------------------------------------------------------------------------

    func buttonClicked(sender: UIButton) {

        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath

       let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController

        let objWatchHeader = self.arrWatchList[(indexPath.section)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        
        objAskAQuestionViewController.strOption = "AskQuestion"
        objAskAQuestionViewController.strTitle = "Ask a Question"
        objAskAQuestionViewController.dictOption =  dictOption
        objAskAQuestionViewController.strBrandName =  objWatchHeader.BrandName
        objAskAQuestionViewController.objWatchList =  objWatchList
        objAskAQuestionViewController.isFromMultiple = true
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func buttonBuyNowClicked(sender: UIButton)
    {
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let objWatchHeader = self.arrWatchList[(indexPath.section)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList

        let  objAskAQuestionViewController = self.storyboard?.instantiateViewController(withIdentifier: "AskAQuestionViewController") as! AskAQuestionViewController
        
        if objWatchList.InStock == "1"
        {
            objAskAQuestionViewController.strOption = "Purchase"
            objAskAQuestionViewController.strTitle = "Buy Now"
        }else{
            objAskAQuestionViewController.strOption = "HaveUsSearch"
            objAskAQuestionViewController.strTitle = "Have us search for it"
        }
        objAskAQuestionViewController.strBrandName =  objWatchHeader.BrandName
        objAskAQuestionViewController.objWatchList =  objWatchList
        objAskAQuestionViewController.isFromMultiple = true
        self.navigationController?.pushViewController(objAskAQuestionViewController, animated: true)
    }
    
    
//    // ------------------------------------------------------------------------------------------------------------------

    
    // ------------------------------------------------------------------------------------------------------------------
    
    @IBAction func buttonImageClicked(sender: UIButton)
    {
        let buttonPosition = sender.convert(CGPoint(x: 0, y: 0), to: tableViewProducts)
        let indexPath = self.tableViewProducts.indexPathForRow(at: buttonPosition)! as NSIndexPath
        
        let objWatchHeader = self.arrWatchList[(indexPath.section)] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[(indexPath.row)] as WatchList
        KConstant.APP.strProductName = objWatchList.Name
        
        if objWatchList.Image_full.characters.count > 0
        {
            let slider = ZoomableImageSlider(images:  [(objWatchList.Image_full)], currentIndex: 0, placeHolderImage: nil)
            self.present(slider, animated: true, completion: nil)
        }
    }

    
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - HTHorizontalSelectionList Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func numberOfItems(in selectionList: HTHorizontalSelectionList) -> Int
    {
        if selectionList ==  self.viewHorizontalBrand{
            return KConstant.APP.arrBrands.count
        }else   if selectionList ==  self.viewHorizontalModel{
            return self.arrWatchModels.count
        }else  if selectionList ==  self.viewHorizontalVariation{
            return self.arrVariationList.count
        }else  if selectionList ==  self.viewHorizontalSubModel{
            return self.arrWatchSubModels.count
        }
        return 0
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func selectionList(_ selectionList: HTHorizontalSelectionList, titleForItemWith index: Int) -> String?
    {
        if selectionList ==  self.viewHorizontalBrand{
            let objBrand = KConstant.APP.arrBrands[index]
            return objBrand.BrandName
        }else   if selectionList ==  self.viewHorizontalModel{
            let objModel = self.arrWatchModels[index] as! WatchModelRow
            return objModel.ModelName
        }else  if selectionList ==  self.viewHorizontalVariation{
            let objVariation = self.arrVariationList[index] as! Model
            return objVariation.SubModelName
        }else  if selectionList ==  self.viewHorizontalSubModel{
            let objVariation = self.arrWatchSubModels[index] as! SubModel
            return objVariation.ModelName
        }
        return ""
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func selectionList(_ selectionList: HTHorizontalSelectionList, didSelectButtonWith index: Int)
    {
        var strSelected = ""
        self.isVariationClicked = true

        if selectionList ==  self.viewHorizontalBrand
        {
            self.labelVariation.isHidden = true
            
            ZVProgressHUD.show()
            self.viewHorizontalVariation.removeFromSuperview()
            
            self.arrWatchModels.removeAllObjects()
            self.viewHorizontalModel.reloadData()
            self.arrVariationList.removeAllObjects()
            
            self.viewHorizontalSubModel.isHidden = true

            self.arrWatchSubModels.removeAllObjects()
            self.viewHorizontalSubModel.reloadData()

            isBrandTapped = true
            
            nInitialIndexBrand = index
            nInitialIndexModel = index
          
            let objBrand = KConstant.APP.arrBrands[index]
            strSelected = objBrand.BrandName
            strBrandID = objBrand.BrandID
            selectedIndex = index
            strModelSlug = ""
            strSelectedVariation = ""

            self.getModels()
            
            selectionList.reloadData()
        }
        else if selectionList ==  self.viewHorizontalModel
        {
            if self.arrWatchModels.count > 0
            {
                nPageCount = 11

                self.labelVariation.isHidden = true

                self.isBrandTapped = false
                
                strSelectedVariation = ""
                
                let objModel = self.arrWatchModels[index] as! WatchModelRow
                strSelected = objModel.ModelSlug
                strModelSlug = strSelected
                nInitialIndexModel = index
                
                self.isSubModuleShow = true
                self.nInitialIndexSubModel = index
                
                if strModelSlug.characters.count > 0
                {
                    self.tableViewProducts.isHidden =  true
                    ZVProgressHUD.show()
                    labelVariation.text = "Variations of the " + objModel.ModelName
                    
                    self.arrVariationList.removeAllObjects()
                    self.arrWatchSubModels.removeAllObjects()
                    self.viewHorizontalSubModel.reloadData()
                    
                    
                    
                    if objModel.is_submodel == "1"
                    {
                      //  self.labelNotFound.text = "Please select Submodel"
//                        self.labelNotFound.text = "Please select Submodel"
//                        self.labelNotFound.isHidden = false;
                        self.view .layoutIfNeeded()
                        strModelSlugTemp = strModelSlug
                        tableViewProducts.isHidden = true
                        self.getSubModels()
                    }else{
                        self.arrVariationList.removeAllObjects()
                        self.getVariations()
                    }
                }else{
                    self.displayAlertWithOk(message: "Model slug not found")
                }
                selectionList.reloadData()
            }
        }
        else if selectionList ==  self.viewHorizontalSubModel
        {
            if self.arrWatchModels.count > 0
            {
               // nPageCount = 11
               // self.isBrandTapped = false
                strSelectedVariation = ""
                self.labelNotFound.isHidden = true
                labelNotFound.text = ""
                let objsubModel = self.arrWatchSubModels[index] as! SubModel
                strSelected = objsubModel.ModelSlug
                strModelSlug = strSelected
                nInitialIndexModel = index
                
                if strModelSlug.characters.count > 0
                {
                    self.tableViewProducts.isHidden =  true
                    ZVProgressHUD.show()
                    labelVariation.text = "Variations of the " + objsubModel.ModelName
                    self.getVariations()
                }else{
                    self.displayAlertWithOk(message: "Model slug not found")
                }
                selectionList.reloadData()
            }
        }
        else  if selectionList ==  self.viewHorizontalVariation
        {
            ZVProgressHUD.show()
            if self.arrWatchModels.count > 0 {
                nPageCount = 11
                let objVariation = self.arrVariationList[index] as! Model
                strSelected = objVariation.SubModel_Slug
                strSelectedVariation = strSelected
                
                self.getWatchList()
                selectionList.reloadData()
            }
        }
        
        selectionList.setCustomContentOffset(index)
    }
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UITableView Deleagate Methods
    // ------------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.arrWatchList.count > 0 {
        let objWatchList = self.arrWatchList[section] as! WatchHeader
        return objWatchList.Product.count
        }
        return 0
    }

    // ------------------------------------------------------------------------------------------------------------------

    func numberOfSections(in tableView: UITableView) -> Int{
        if self.arrWatchList.count > 0 {
        return self.arrWatchList.count
        }
        return 0

    }
   
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        
        if self.arrWatchList.count > 0 {

        let objWatchHeader = self.arrWatchList[indexPath.section] as! WatchHeader
        
        let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList

        let strCondition = "\(objWatchList.condition )" as String

        var nHeight = 21 as Int

        if strCondition.characters.count > 0 {
            nHeight = 0
        }


        
        return CGFloat(232 - nHeight) // 288
        }
        return 0 // 288

    }

    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.00001
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let objProductDetailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailsViewController") as! ProductDetailsViewController
        let objWatchHeader = self.arrWatchList[indexPath.section] as! WatchHeader
        let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
         objProductDetailsViewController.strItemID = objWatchList.ItemID
         objProductDetailsViewController.strBrandID = strBrandID
         objProductDetailsViewController.strModelSlug = strModelSlug
        objProductDetailsViewController.strSubModelName = strModelSlug
        objProductDetailsViewController.strBrandName = strBrandName
         objProductDetailsViewController.isFromMultipleScreen = true

        self.navigationController?.pushViewController(objProductDetailsViewController, animated: true)

    }
    
    // ------------------------------------------------------------------------------------------------------------------
    
    // MARK: -  UITableView Delegate Methods

    // ------------------------------------------------------------------------------------------------------------------
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SearchCell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath ) as! SearchCell
        
        if self.arrWatchList.count > 0
        {

            let objWatchHeader = self.arrWatchList[indexPath.section] as! WatchHeader
            
        let objWatchList =    objWatchHeader.Product[indexPath.row] as WatchList
            
        cell.labelName.text = objWatchList.Name+" "+objWatchList.Subtext
        cell.labelName2.text  = objWatchList.ShortDesc.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
        cell.labelName2.isHidden = true;
          
        cell.labelRef.text =  "Ref - "+objWatchList.ModelNumber
        cell.labelItemID.text = "Item Id - "+objWatchList.ItemID
        cell.labelRetailPrice.text =  "\(objWatchList.Retail_Lable ?? "")"+"\(objWatchList.RetailPrice ?? "")"
        
        cell.labelCase.text =  "Case - " + objWatchList.Case
        cell.labelSize.text =  "Size - " + "\(objWatchList.CaseSize ?? "")"
        cell.labelDial.text =  "Dial - " + objWatchList.Dial
        

            
       self.setAdjustableLabel(label:  cell.labelCondition)
            
        let url = URL(string: objWatchList.Image)!
        let placeholderImage = UIImage(named: KConstant.kImagePlaceholderName)!
        
        cell.imageViewWatch.kf.setImage(with: url, placeholder: placeholderImage, options: nil, progressBlock: nil, completionHandler: nil)



            var strCondition = "\(objWatchList.condition )" as String
            
            if strCondition.characters.count > 0 {
                cell.labelCondition.text =  "CONDITION - "+strCondition
                cell.layoutConstraintConditionHeight.constant = 21
            }else{
                cell.labelCondition.text = ""
                cell.layoutConstraintConditionHeight.constant = 0
            }
            
            if (cell.labelRetailPrice.text?.characters.count)! == 0 {
                cell.labelYourPriceOnly.isHidden = false
            }else{
                cell.labelYourPriceOnly.isHidden = true
            }
            
            cell.buttonAskQuestion.tag = indexPath.row
            cell.buttonAskQuestion.addTarget(self, action: #selector(buttonClicked(sender:)), for: .touchUpInside)
            
            cell.buttonBuyNow.tag = indexPath.row
            cell.buttonBuyNow.addTarget(self, action: #selector(buttonBuyNowClicked(sender:)), for: .touchUpInside)

            cell.buttonImage.isHidden = true
            


            
            if indexPath.section == 0 && indexPath.row == 0
            {
                cell.viewTopLine.isHidden = true
            }else {
                cell.viewTopLine.isHidden = false
            }

            

            if objWatchList.InStock == "1"
            {
                cell.labelYourPrice.text = "Your Price - "+objWatchList.YourPrice
                cell.buttonBuyNow.setTitle("Buy Now", for: .normal)
                cell.buttonBuyNow.backgroundColor = KConstant.kColorThemeYellow
                cell.buttonBuyNow.setTitleColor(UIColor.white, for: .normal)
            }
            else
            {
                cell.labelYourPrice.text = ""
                cell.buttonBuyNow.setTitle("Have us find this watch", for: .normal)
                cell.buttonBuyNow.backgroundColor = UIColor.white
                cell.buttonBuyNow.layer.borderColor = KConstant.kColorThemeYellow.cgColor
                cell.buttonBuyNow.setTitleColor(UIColor.black, for: .normal)
            }

//            cell.layoputConstraintViewMainTopSpace.constant = -1
            
            cell.labelYourPriceOnly.text = cell.labelYourPrice.text
            
            cell.buttonBuyNow.layer.borderColor = KConstant.kColorThemeYellow.cgColor
            cell.buttonBuyNow.layer.borderWidth = 1.0
            cell.buttonAskQuestion.layer.borderColor = KConstant.kColorThemeYellow.cgColor
            cell.buttonAskQuestion.layer.borderWidth = 1.0
            cell.layoutConstraintViewBottomTopLineHeight.constant = 1.0
        }
        return cell
    }
   
//    // ------------------------------------------------------------------------------------------------------------------

    
    // MARK: - UITextField Delegate Methods
    
    // ------------------------------------------------------------------------------------------------------------------
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // ------------------------------------------------------------------------------------------------------------------
    // MARK: - UIScrollView Delegate Methods
    // ------------------------------------------------------------------------------------------------------------------
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let scrollViewHeight: Float = Float(scrollView.frame.size.height)
        let scrollContentSizeHeight = Float(scrollView.contentSize.height)
        let scrollOffset: Float = Float(scrollView.contentOffset.y)
        
        if scrollOffset == 0 {
  
        }
        else if scrollOffset + scrollViewHeight == scrollContentSizeHeight
        {
            if nPageCount > 11 {
                nPageCount = nPageCount + 12
                self.getWatchList()
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    func getSubModels()
    {
        
        if strBrandID.characters.count>0 &&  strModelSlugTemp.characters.count>0
        {
            let dictParams = [KConstant.kMethod : "brand_submodel.php","id":strBrandID,"slug":self.strModelSlugTemp]
            
            ServerRequest.sendServerRequestWithDictForSubModels(dictParam: dictParams) { (response, isSuccess) in
                if isSuccess
                {
                    let arrResponse = response as! Array<SubModel>


                    /////********************
                    
                    for i in 0 ..< arrResponse.count
                    {
                        let objWatchSubModel = arrResponse[i] as SubModel

                        
                        if objWatchSubModel.ModelSlug == self.strModelSlug
                            {
                                if self.nInitialIndexSubModel == -1
                                {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        self.isSubModuleShow = true
                                        self.selectionList(self.viewHorizontalSubModel, didSelectButtonWith: i)
                                        self.viewHorizontalSubModel.setSelectedButtonIndex(i, animated: true)
                                    }
                                }
                            }
                            self.arrWatchSubModels.add(objWatchSubModel)
                    }

                    //************//**/**//*/*/*/**/*/*/*/*/*/*/*//****************
                    
                    if self.nInitialIndexSubModel != -1
                    {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            self.viewHorizontalSubModel.setSelectedButtonIndex(-1, animated: true)
                        }
                    }
                    
                    self.viewHorizontalSubModel.reloadData()
                    self.showSubModul()
                    
                    self.getVariations()

                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        self.setUpInitialDesignScreen()
                    }
                }else{
                    print("failure\(response)")
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------------
    
    func showSubModul() {
        
        if(self.arrVariationList.count > 0){
            tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(246))
        }else{
            tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(236))
        }
        
        layoutConstraint_SubView_Top_Hight.constant = 4
        layoutConstraint_SubView_Bottom_Hight.constant = 4
        layoutConstraintlabel_Sub_Hight.constant = 14
        layoutConstraint_sub_view_Hight.constant = 40
        labelSubModel.isHidden = false
        isSubModuleShow = true
        self.tableViewProducts.layoutIfNeeded()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

    func hideSubModul()
    {
        
        if(self.arrVariationList.count > 0){
            tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(236))
        }else{
            tableViewProducts.tableHeaderView?.frame.size = CGSize(width: tableViewProducts.frame.width, height: CGFloat(136))
        }
        
        isSubModuleShow = false
        labelSubModel.isHidden = true
        layoutConstraint_SubView_Top_Hight.constant = 0
        layoutConstraint_SubView_Bottom_Hight.constant = 0
        layoutConstraint_sub_view_Hight.constant = 0
        layoutConstraintlabel_Sub_Hight.constant = 0
        self.tableViewProducts.layoutIfNeeded()
    }
    
    // ------------------------------------------------------------------------------------------------------------------

}
